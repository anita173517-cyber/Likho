package com.harindra.iptvpro

import android.content.Context
import android.util.JsonReader
import android.util.JsonToken
import android.util.JsonWriter
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.zip.GZIPOutputStream

data class CachedEpgData(
    val sourceUrl: String,
    val timestampMs: Long,
    val entries: Map<String, Pair<String, String>>
)

class EpgCacheStore(context: Context) {
    private val appContext = context.applicationContext
    private val mutex = Mutex()
    private val cacheFile = File(appContext.filesDir, "streamx_epg_now_next_cache.json")

    companion object {
        const val EPG_REFRESH_INTERVAL_MS = 4L * 60L * 60L * 1000L // 4 hours
        private const val MAX_EPG_ENTRIES = 25_000

        @Volatile
        private var ramCachedEpg: CachedEpgData? = null

        fun trimMemoryCache() {
            ramCachedEpg = null
        }
    }

    suspend fun saveEpg(url: String, map: Map<String, Pair<String, String>>) {
        if (map.isEmpty()) return
        val nowMs = System.currentTimeMillis()
        ramCachedEpg = CachedEpgData(url, nowMs, map)
        withContext(Dispatchers.IO) {
            mutex.withLock {
                val tmpFile = File(appContext.filesDir, "${cacheFile.name}.tmp")
                try {
                    FileOutputStream(tmpFile).use { fos ->
                        JsonWriter(BufferedWriter(OutputStreamWriter(GZIPOutputStream(fos), Charsets.UTF_8), 16384)).use { writer ->
                            writer.beginObject()
                            writer.name("url").value(url)
                            writer.name("ts").value(nowMs)
                            writer.name("items")
                            writer.beginArray()
                            var count = 0
                            for ((chId, pair) in map) {
                                if (count >= MAX_EPG_ENTRIES) break
                                writer.beginObject()
                                writer.name("id").value(chId)
                                writer.name("now").value(pair.first)
                                writer.name("next").value(pair.second)
                                writer.endObject()
                                count++
                            }
                            writer.endArray()
                            writer.endObject()
                            writer.flush()
                        }
                        runCatching { fos.fd.sync() }
                    }
                    if (tmpFile.exists() && tmpFile.length() > 10L) {
                        if (cacheFile.exists()) {
                            cacheFile.delete()
                        }
                        val renamed = tmpFile.renameTo(cacheFile)
                        if (!renamed) {
                            tmpFile.copyTo(cacheFile, overwrite = true)
                            tmpFile.delete()
                        }
                    } else {
                        tmpFile.delete()
                    }
                } catch (e: Exception) {
                    tmpFile.delete()
                    Log.w("StreamX", "EPG cache save warning: ${e.message}")
                }
                Unit
            }
        }
    }

    suspend fun loadEpg(): CachedEpgData? = withContext(Dispatchers.IO) {
        ramCachedEpg?.let { if (it.entries.isNotEmpty()) return@withContext it }
        mutex.withLock {
            if (!cacheFile.exists() || cacheFile.length() <= 10L) return@withLock null
            try {
                var url = ""
                var ts = 0L
                val entries = HashMap<String, Pair<String, String>>(1024)
                JsonReader(BufferedReader(InputStreamReader(NetworkClient.openDecompressedStream(FileInputStream(cacheFile)), Charsets.UTF_8), 16384)).use { reader ->
                    if (reader.peek() != JsonToken.BEGIN_OBJECT) {
                        cacheFile.delete()
                        return@withLock null
                    }
                    reader.beginObject()
                    while (reader.hasNext()) {
                        when (reader.nextName()) {
                            "url" -> url = if (reader.peek() == JsonToken.STRING) reader.nextString() else { reader.skipValue(); "" }
                            "ts" -> ts = if (reader.peek() == JsonToken.NUMBER) reader.nextLong() else { reader.skipValue(); 0L }
                            "items" -> {
                                if (reader.peek() == JsonToken.BEGIN_ARRAY) {
                                    reader.beginArray()
                                    while (reader.hasNext()) {
                                        if (reader.peek() != JsonToken.BEGIN_OBJECT) {
                                            reader.skipValue()
                                            continue
                                        }
                                        var id = ""
                                        var nowStr = "Live Broadcast"
                                        var nextStr = "Upcoming Show"
                                        reader.beginObject()
                                        while (reader.hasNext()) {
                                            when (reader.nextName()) {
                                                "id" -> id = if (reader.peek() == JsonToken.STRING) reader.nextString() else { reader.skipValue(); "" }
                                                "now" -> nowStr = if (reader.peek() == JsonToken.STRING) reader.nextString() else { reader.skipValue(); "" }
                                                "next" -> nextStr = if (reader.peek() == JsonToken.STRING) reader.nextString() else { reader.skipValue(); "" }
                                                else -> reader.skipValue()
                                            }
                                        }
                                        reader.endObject()
                                        if (id.isNotEmpty()) {
                                            val pair = nowStr to nextStr
                                            entries[id] = pair
                                            val norm = XmltvParser.normalizeEpgKey(id)
                                            if (norm.isNotEmpty()) entries.putIfAbsent(norm, pair)
                                        }
                                    }
                                    reader.endArray()
                                } else {
                                    reader.skipValue()
                                }
                            }
                            else -> reader.skipValue()
                        }
                    }
                    reader.endObject()
                }
                if (entries.isEmpty()) {
                    null
                } else {
                    val data = CachedEpgData(url, ts, entries)
                    ramCachedEpg = data
                    data
                }
            } catch (e: Exception) {
                Log.w("StreamX", "Corrupted EPG cache deleted: ${e.message}")
                runCatching { cacheFile.delete() }
                null
            }
        }
    }

    fun cacheSizeBytes(): Long = if (cacheFile.exists()) cacheFile.length() else 0L

    suspend fun clear() {
        ramCachedEpg = null
        XmltvParser.trimProgrammeDetailsCache()
        withContext(Dispatchers.IO) {
            mutex.withLock {
                runCatching { if (cacheFile.exists()) cacheFile.delete() }
                Unit
            }
        }
    }
}
