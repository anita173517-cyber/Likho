package com.harindra.iptvpro

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.ActivityManager
import android.app.PictureInPictureParams
import android.content.ComponentCallbacks2
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.media.audiofx.LoudnessEnhancer
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Debug
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.util.Log
import android.util.Rational
import android.util.SparseIntArray
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.HorizontalScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowCompat
import com.harindra.iptvpro.vod.VodContentType
import com.harindra.iptvpro.vod.VodEpisodeNavItem
import com.harindra.iptvpro.vod.VodLaunchPayload
import com.harindra.iptvpro.vod.VodPlayerLauncher
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.AudioAttributes
import android.speech.RecognizerIntent
import android.view.Display
import androidx.media3.common.C
import android.media.AudioFormat
import android.media.AudioManager
import androidx.media3.common.TrackSelectionParameters
import androidx.media3.common.text.CueGroup
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.common.MimeTypes
import androidx.media3.exoplayer.dash.DashMediaSource
import androidx.media3.exoplayer.drm.DefaultDrmSessionManager
import androidx.media3.exoplayer.drm.DrmSessionManager
import androidx.media3.exoplayer.drm.FrameworkMediaDrm
import androidx.media3.exoplayer.drm.HttpMediaDrmCallback
import androidx.media3.exoplayer.drm.LocalMediaDrmCallback
import androidx.media3.exoplayer.hls.DefaultHlsExtractorFactory
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.exoplayer.upstream.DefaultAllocator
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.MemoryCategory
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Arrays
import java.util.Date
import java.util.Locale

data class TvThemePalette(
    val name: String,
    val subtitle: String,
    val accentHex: String,
    val badgeTextHex: String,
    val statusHex: String,
    val activeRowDrawableRes: Int
)

data class GlassModalOption(
    val iconRes: Int,
    val title: String,
    val subtitle: String,
    val badgeText: String = "",
    val isHighlighted: Boolean = false,
    val onClick: () -> Unit
)

data class GlassFormFieldSpec(
    val label: String,
    val hint: String,
    val iconRes: Int,
    val initialValue: String = "",
    val inputType: Int = InputType.TYPE_CLASS_TEXT
)

data class PosterCardBindItem(
    val key: String,
    val title: String,
    val subtitle: String,
    val posterUrl: String,
    val yearBadge: String,
    val qualityBadge: String,
    val progressPercent: Int,
    val isFavorite: Boolean,
    val vodMovieIndex: Int = -1,
    val seriesSummary: SeriesGroupSummary? = null
)

enum class BufferProfile(
    val id: String,
    val label: String,
    val subtitle: String,
    val minBufferMs: Int,
    val maxBufferMs: Int,
    val playBufferMs: Int,
    val rebufferMs: Int,
    val targetBytes: Int,
    val prioritizeTimeOverSize: Boolean
) {
    LOW_MEMORY_512MB(
        "LOW_MEM",
        "Hyper-Glass 512MB Turbo (110ms Start • 3.5MB Cap)",
        "Default for 512MB RAM Smart TVs • Faster zapping with anti-stall guard",
        1800, 6000, 110, 350, 3584 * 1024, false
    ),
    ULTRA_FAST_ZAP(
        "ULTRA_ZAP",
        "Turbo Zap Extreme (65ms Start • 3.2MB Cap)",
        "Hyper-instant channel switching on broadband Wi-Fi / Ethernet",
        1500, 5000, 65, 240, 3276 * 1024, false
    ),
    LOW_LATENCY(
        "LOW_LATENCY",
        "Extreme Sports Zap (50ms Start • 3MB Cap)",
        "Minimum live broadcast edge delay for live cricket & football",
        1400, 4600, 50, 200, 3 * 1024 * 1024, false
    ),
    BALANCED(
        "BALANCED",
        "Balanced HD (120ms Start • 8MB Cap)",
        "Ideal for Android phones & 1GB+ RAM TVs",
        3800, 11000, 120, 450, 8 * 1024 * 1024, false
    ),
    STABLE(
        "STABLE",
        "Stable Shield (320ms Start • 12MB Cap)",
        "Maximum cushion against fluctuating mobile hotspot / slow Wi-Fi",
        6000, 18000, 320, 950, 12 * 1024 * 1024, true
    ),
    ULTRA_40S(
        "ULTRA_40S",
        "Ultra Anti-Buffer 40s (40s Cushion • 32MB Cap)",
        "Pre-buffers up to 40s ahead for zero-drop playback on 2GB+ TV & Phone",
        15000, 42000, 500, 1500, 32 * 1024 * 1024, true
    );

    companion object {
        fun fromId(id: String?, isLowRamDevice: Boolean): BufferProfile {
            return values().firstOrNull { it.id == id }
                ?: if (isLowRamDevice) LOW_MEMORY_512MB else ULTRA_FAST_ZAP
        }
    }
}

@OptIn(UnstableApi::class)
class PlayerActivity : AppCompatActivity() {

    private var exoPlayer: ExoPlayer? = null
    private var trackSelector: DefaultTrackSelector? = null
    private var sharedAllocator: DefaultAllocator? = null
    private var hlsChunklessFactory: HlsMediaSource.Factory? = null
    private var defaultMediaSourceFactory: DefaultMediaSourceFactory? = null
    private var lastSwitchUsedPreload: Boolean = false
    private var activePlaybackToken: Long = 0L

    private lateinit var playerView: PlayerView
    private lateinit var liveTvVlcLayout: org.videolan.libvlc.util.VLCVideoLayout
    private var liveTvVlcEngine: LiveTvLibVlcEngine? = null
    private var isLiveTvUsingLibVlc: Boolean = false
    private var currentLiveHealStage: LiveTvHealStage = LiveTvHealStage.EXO_PRIMARY
    private var liveHealGeneration: Int = 0
    private var liveVlcAudioSummary: String = ""
    private lateinit var topControlBar: View
    private lateinit var leftChannelDrawer: View
    private lateinit var channelListRecycler: RecyclerView
    private lateinit var tvEmptyDrawer: TextView
    private lateinit var osdBanner: View
    private lateinit var tvChannelNumber: TextView
    private lateinit var tvChannelName: TextView
    private lateinit var tvChannelCategory: TextView
    private lateinit var tvOsdStreamBadge: TextView
    private lateinit var tvEpgNow: TextView
    private lateinit var osdLiveProgressBar: ProgressBar
    private lateinit var tvActiveSectionBadge: TextView
    private lateinit var btnToggleFavorite: Button
    private lateinit var btnRecallChannel: Button
    private lateinit var btnHomeHub: Button
    private lateinit var btnToggleDrawer: Button
    private lateinit var btnSectionLiveTv: Button
    private lateinit var btnSectionMovies: Button
    private lateinit var btnSectionSeries: Button
    private lateinit var btnUnifiedSearch: Button
    private lateinit var tabAllChannels: Button
    private lateinit var tabFavorites: Button
    private lateinit var tabRecent: Button
    private lateinit var channelSearch: EditText
    private lateinit var categoryFilter: Spinner
    private lateinit var channelLogo: ImageView

    // v18.1 4D Movies & Series Poster Grid Hub Views (Left Category Sidebar + Right Poster Grid)
    private lateinit var vodPosterGridPanel: View
    private lateinit var tvVodLiveClockDate: TextView
    private lateinit var tvVodGridHeaderTitle: TextView
    private lateinit var btnVodContinueWatching: Button
    private lateinit var btnVodFavoritesFilter: Button
    private lateinit var btnVodSortOrder: Button
    private lateinit var btnVodFetchProvider: Button
    private var btnVodSmartFilter: Button? = null
    private var vodSpotlightBanner: View? = null
    private var ivVodSpotlightPoster: ImageView? = null
    private var tvVodSpotlightTitle: TextView? = null
    private var tvVodSpotlightMeta: TextView? = null
    private var tvVodSpotlightHint: TextView? = null
    private var btnCinemaSwitchMovies: Button? = null
    private var btnCinemaSwitchSeries: Button? = null
    private var vodEmptyHeroContainer: View? = null
    private var btnVodEmptyXtreamLogin: Button? = null
    private var btnVodEmptySync: Button? = null
    private var btnVodEmptyBackLive: Button? = null
    private var btnVodRandomPick: Button? = null

    private val dedicatedVodPlayerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (vodPosterGridPanel.visibility == View.VISIBLE) {
            val sidebarItems = buildVodSidebarCategories(activeEntertainmentSection)
            vodSidebarAdapter.submitCategories(sidebarItems, selectedVodCategory)
            renderVodPosterGrid(requestFocusPosterIndex = lastFocusedPosterIndex)
        }
        val data = result.data
        val returnAction = data?.getStringExtra(VodPlayerLauncher.RESULT_RETURN_ACTION)
        if (returnAction == VodPlayerLauncher.ACTION_EXIT_TO_LIVE_TV) {
            closeVodGridAndReturnToLiveTv()
        }
    }
    private lateinit var btnCloseVodGrid: Button
    private lateinit var vodPosterSearch: EditText
    private lateinit var vodCategorySpinner: Spinner
    private lateinit var vodCategorySidebarRecycler: RecyclerView
    private lateinit var tvVodEmptyState: TextView
    private lateinit var vodPosterRecycler: RecyclerView
    private lateinit var posterGridAdapter: VodPosterGridAdapter
    private lateinit var vodSidebarAdapter: VodCategorySidebarAdapter

    // DTH Set-Top-Box Startup Overlay Views
    private lateinit var dthBootOverlay: View
    private lateinit var vSignalWaveOuter: View
    private lateinit var vSignalWaveInner: View
    private lateinit var tvBootHeadline: TextView
    private lateinit var tvBootStageStatus: TextView
    private lateinit var tvBootSubDetail: TextView
    private lateinit var bootProgressBar: ProgressBar
    private var outerWaveAnimator: ObjectAnimator? = null
    private var innerWaveAnimator: ObjectAnimator? = null
    private var satellitePulseAnimator: ObjectAnimator? = null
    private var isBootOverlayVisible: Boolean = true
    private var hasRenderedVideoFrame: Boolean = false

    // Real Startup, Zapping & Buffering Benchmark Timings
    private var processStartElapsedMs: Long = 0L
    private var firstUiFrameMs: Long = 0L
    private var bootReadyElapsedMs: Long = 0L
    private var firstVideoFrameMs: Long = 0L
    private var lastPlaylistLoadDurationMs: Long = 0L
    private var lastRemoteKeyPressElapsedMs: Long = 0L
    private var lastKeyPressToSelectionMs: Long = 0L
    private var lastSwitchStartElapsedMs: Long = 0L
    private var lastSelectionToPrepareMs: Long = 0L
    private var lastChannelSwitchMs: Long = 0L
    private var bufferingStartElapsedMs: Long = 0L
    private var lastBufferingDurationMs: Long = 0L
    private var lastZapForward: Boolean = true
    private var isLowRamTvDevice: Boolean = true
    private var totalDeviceRamMb: Long = 512L
    private var maxPlaylistLimit: Int = 60_000

    private lateinit var channelAdapter: ChannelDrawerAdapter
    private var searchQuery: String = ""
    private var selectedCategory: String = "All categories"
    private var suppressCategoryCallback: Boolean = false
    private var epgMap: Map<String, Pair<String, String>> = emptyMap()

    // =========================================================================
    // v18.1 STRICTLY SEPARATED LIVE TV, VOD MOVIES & SERIES CATALOGS
    // =========================================================================
    private var activeEntertainmentSection: EntertainmentSection = EntertainmentSection.LIVE_TV
    private var vodSearchQuery: String = ""
    private var selectedVodCategory: String = "RECENTLY ADDED"
    private var suppressVodCategoryCallback: Boolean = false
    private var vodSpecialFilterMode: String = "ALL" // ALL, CONTINUE, FAV, RECENT_ADDED
    private var activeVodSortOrder: VodSortOrder = VodSortOrder.RECENTLY_ADDED
    private var activeLiveChannelSortOrder: LiveChannelSortOrder = LiveChannelSortOrder.CHANNEL_NUMBER
    private var filterUnwatchedEpisodesOnly: Boolean = false
    private var vodSmartQualityFilter: String = "ALL" // ALL, 4K, 1080P, UNWATCHED
    private var loudnessEnhancer: LoudnessEnhancer? = null
    private var lastUserInteractionElapsedMs: Long = SystemClock.elapsedRealtime()
    private var isScreensaverShowing: Boolean = false
    private var recentPlaybackErrorSummary: String = "None" 

    // Separate, strictly typed VOD Movies & Series Catalogs (NEVER mixed into allChannels!)
    private var vodMoviesCatalog: List<Channel> = emptyList()
    private var vodMovieIndexById: Map<String, Int> = emptyMap()
    private var seriesCatalogRaw: List<Channel> = emptyList()
    private var seriesCatalogGroups: List<SeriesGroupSummary> = emptyList()
    private val loadedSeriesEpisodesCache = HashMap<String, Map<Int, List<SeriesEpisodeItem>>>(32)
    private var vodPosterFilterJob: Job? = null
    private var vodCatalogLoadJob: Job? = null
    private var seriesCatalogLoadJob: Job? = null

    // Predictable Navigation & Back-Stack Restoration State (Requirement 5, 6, 7)
    private enum class ActivePlaybackMode {
        LIVE_TV,
        VOD_MOVIE,
        VOD_TRAILER,
        SERIES_EPISODE
    }
    private var activePlaybackMode: ActivePlaybackMode = ActivePlaybackMode.LIVE_TV
    private var activeVodMovieItem: Channel? = null
    private var activeVodMovieIndex: Int = -1
    private var activeVodMovieDetailInfo: VodMovieDetailInfo? = null
    private var activeSeriesGroup: SeriesGroupSummary? = null
    private var activeSeriesSeasonNum: Int = 1
    private var activeSeriesEpisodeItem: SeriesEpisodeItem? = null
    private var lastFocusedPosterIndex: Int = 0
    private var autoNextPromptShownForEpisodeId: String = ""
    private var autoNextCountdownDialog: AlertDialog? = null
    private var autoNextCountdownJob: Job? = null

    // Primitive IntArray Windowed Pagination for Live TV
    private var fullFilteredIndices: IntArray = IntArray(0)
    private var currentPagedLimit: Int = 1200
    private val pageStepSize: Int = 1200

    private var filterJob: Job? = null
    private var loadChannelsJob: Job? = null
    private var epgLoadJob: Job? = null
    private var bgSyncJob: Job? = null

    private val xtreamRepo = XtreamRepository()
    private lateinit var profileStore: ProfileStore
    private lateinit var channelCache: ChannelCacheStore
    private lateinit var epgCache: EpgCacheStore
    private var connectivityManager: ConnectivityManager? = null
    private var networkCallbackRegistered: Boolean = false

    private var activeSourceType: ProfileType? = null
    private var activeXtreamCreds: XtreamCredentials? = null
    private var activeM3uInput: String = ""
    private var activeM3uLabel: String = "M3U"
    private var activeAccountScope: String = "default"

    private var liveResolutionLabel: String = "Auto HD"
    private var liveTelemetryDetail: String = ""
    private var liveStatusLabel: String = "🟢 Live"
    private var subtitlesEnabled: Boolean = false
    private var selectedQualityLabel: String = "Auto"
    private var selectedQualityMaxSize: Pair<Int, Int>? = null
    private var lastAutoQualityAppliedStreamUrl: String = ""
    private var activeBufferProfile: BufferProfile = BufferProfile.LOW_MEMORY_512MB
    private var activePerformanceMode: PerformanceMode = PerformanceMode.SMART_BALANCED
    private var autoBootEnabled: Boolean = true
    private var autoResumeEnabled: Boolean = true
    private var currentPlayingStreamUrl: String = ""
    private var currentPlayingSeriesKey: String = ""
    private var currentPlayingSeasonNum: Int = 0
    private var currentPlayingEpisodeNum: Int = 0
    private var pendingResumeSeekPositionMs: Long = 0L
    private var usingBackupStream: Boolean = false
    private var unlockedSessionCategories: MutableSet<String> = HashSet()

    // Ultra-Compact RGB_565 80x80 Glide options with 3D Live TV vector placeholder
    private val logoRequestOptions by lazy {
        RequestOptions()
            .format(DecodeFormat.PREFER_RGB_565)
            .override(80, 80)
            .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
            .dontAnimate()
            .dontTransform()
            .placeholder(R.drawable.ic_3d_live_tv)
            .error(R.drawable.ic_3d_live_tv)
    }

    // Bounded RGB_565 Poster Thumbnail options for 512MB RAM TVs (prevents full-res bitmap OOM)
    private fun currentPosterRequestOptions(): RequestOptions {
        val w = if (activePerformanceMode == PerformanceMode.LOW_MEMORY) 144 else 180
        val h = if (activePerformanceMode == PerformanceMode.LOW_MEMORY) 210 else 260
        return RequestOptions()
            .format(DecodeFormat.PREFER_RGB_565)
            .override(w, h)
            .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
            .dontAnimate()
            .centerCrop()
            .placeholder(R.drawable.ic_3d_movies)
            .error(R.drawable.ic_3d_movies)
    }

    private val themes = listOf(
        TvThemePalette("Cyan 4D Cyber Crystal", "Electric Sapphire Glow • Ultra Extreme Default", "#0284C7", "#38BDF8", "#34D399", R.drawable.bg_btn_3d_cyan),
        TvThemePalette("Royal Gold 4D VIP", "Luxury Amber-Gold Bevel & Warm Highlights", "#D97706", "#FBBF24", "#FDE047", R.drawable.bg_btn_3d_gold),
        TvThemePalette("Emerald 4D Matrix", "Bio-Neon Emerald Glass & Mint Status", "#059669", "#34D399", "#6EE7B7", R.drawable.bg_btn_3d_emerald),
        TvThemePalette("Purple 4D Synthwave", "Deep Amethyst Neon & Cyber Violet Rim", "#7C3AED", "#C084FC", "#38BDF8", R.drawable.bg_btn_3d_purple),
        TvThemePalette("Crimson 4D Cinema", "Ruby Velvet Broadcast & Rose-Gold Sheen", "#E11D48", "#FB7185", "#FBBF24", R.drawable.bg_btn_3d_crimson)
    )
    private var currentThemeIndex: Int = 0

    private val playlistPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
                Log.w("StreamX", "Persistable URI permission note: ${e.message}")
            }
            importLocalM3uUri(uri)
        }
    }

    private val uiHandler = Handler(Looper.getMainLooper())

    // Track stacked glass dialogs so a Live TV session suspended by Settings/Search
    // resumes only after the last overlay is dismissed (not between nested dialogs).
    private var activeGlassDialogCount: Int = 0


    private val hideOsdRunnable: Runnable = Runnable {
        osdBanner.animate()
            .alpha(0f)
            .setDuration(if (activePerformanceMode.reducedAnimations) 60L else 140L)
            .withLayer()
            .withEndAction {
                osdBanner.visibility = View.GONE
                osdBanner.alpha = 1f
            }
            .start()
        if (leftChannelDrawer.visibility != View.VISIBLE && vodPosterGridPanel.visibility != View.VISIBLE) {
            topControlBar.visibility = View.GONE
        }
    }

    // 25ms ultra-fast debounce during rapid TV remote key-repeat zapping
    private var pendingCommitToken: Long = 0L
    private val commitPlaybackRunnable: Runnable = Runnable {
        if (pendingCommitToken == activePlaybackToken) {
            startPlaybackForCurrentChannel(forceReload = false)
        }
    }

    private val retryPlaybackRunnable: Runnable = Runnable {
        val player = exoPlayer ?: return@Runnable
        if (allChannels.isNotEmpty() || activePlaybackMode != ActivePlaybackMode.LIVE_TV) {
            if (activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
                player.seekToDefaultPosition()
            }
            player.prepare()
            player.playWhenReady = true
        }
    }

    // Periodic VOD/Series playback progress saver + Auto-Next Episode near-end detector + Live Clock updater
    private val vodProgressTrackerRunnable: Runnable = object : Runnable {
        override fun run() {
            recordCurrentVodOrSeriesProgress()
            checkSmartAutoNextEpisodeNearEnd()
            if (vodPosterGridPanel.visibility == View.VISIBLE) {
                updateVodHeaderClockText()
            }
            checkIdleScreensaverTrigger()
            uiHandler.postDelayed(this, 4000L)
        }
    }

    // Live Heap Guard (<16MB free + unallocated JVM heap check)
    private val heapGuardRunnable: Runnable = object : Runnable {
        override fun run() {
            val rt = Runtime.getRuntime()
            val freeAndUnallocated = rt.maxMemory() - (rt.totalMemory() - rt.freeMemory())
            if (freeAndUnallocated < 16L * 1024L * 1024L) {
                StreamPreFetcher.trimIdleCacheOnLowMemory()
                ChannelCacheStore.trimMemoryCache()
                sharedAllocator?.trim()
                runCatching { Glide.get(this@PlayerActivity).clearMemory() }
            }
            uiHandler.postDelayed(this, 5000L)
        }
    }

    // Fast 2.5s Playback Stall Watchdog + Smart Auto-Failover to backupUrl
    private var stallRecoveryCount: Int = 0
    private val stallWatchdogRunnable: Runnable = object : Runnable {
        override fun run() {
            val player = exoPlayer ?: return
            if (player.playbackState == Player.STATE_BUFFERING) {
                if (activePlaybackMode == ActivePlaybackMode.LIVE_TV && allChannels.isNotEmpty()) {
                    val ch = allChannels.getOrNull(currentChannelIndex)
                    if (ch != null && !usingBackupStream && ch.backupUrl.isNotBlank()) {
                        usingBackupStream = true
                        stallRecoveryCount = 0
                        Log.w("StreamX", "2.5s Watchdog failover to backupUrl for ${ch.name}")
                        liveStatusLabel = "⚡ Backup Stream"
                        updateOsdForCurrentChannel()
                        playSpecificStreamUrl(ch.backupUrl)
                        return
                    }
                }
                if (activePlaybackMode == ActivePlaybackMode.LIVE_TV && !isLiveTvUsingLibVlc && stallRecoveryCount >= 1) {
                    stallRecoveryCount = 0
                    if (advanceLiveTvHealStage("Stream stalled / failed to start on Media3")) {
                        return
                    }
                }
                if (stallRecoveryCount < 3) {
                    StreamPreFetcher.updateNetworkState(connected = true, degraded = true)
                    stallRecoveryCount++
                    Log.w("StreamX", "2.5s Stall Watchdog triggered (${stallRecoveryCount}/3): recovering stream")
                    liveStatusLabel = "🔄 Fast Recovery ${stallRecoveryCount}/3..."
                    updateOsdForCurrentChannel()
                    if (activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
                        player.seekToDefaultPosition()
                    }
                    player.prepare()
                    player.playWhenReady = true
                    uiHandler.postDelayed(this, 3000L)
                } else if (activePlaybackMode == ActivePlaybackMode.LIVE_TV && allChannels.isNotEmpty()) {
                    stallRecoveryCount = 0
                    if (!advanceLiveTvHealStage("Max Media3 stall retries reached")) {
                        liveStatusLabel = "🔄 Auto-Reconnecting Stream..."
                        updateOsdForCurrentChannel()
                        startPlaybackForCurrentChannel(forceReload = true)
                    }
                } else {
                    liveStatusLabel = "⚠️ Slow Server / Stream Stalled"
                    updateOsdForCurrentChannel()
                }
            }
        }
    }

    // OTT Navigator-Grade 4.5s Black-Screen Video-Frame Watchdog:
    // Triggers even when Media3 reports STATE_READY if onRenderedFirstFrame() never fires (e.g. AC3 6ch / 1080i50 black screen).
    private val blackScreenWatchdogRunnable: Runnable = Runnable {
        if (isFinishing || isDestroyed) return@Runnable
        if (activePlaybackMode != ActivePlaybackMode.LIVE_TV || allChannels.isEmpty()) return@Runnable
        if (hasRenderedVideoFrame) return@Runnable
        advanceLiveTvHealStage("No video frame rendered (black screen)")
    }

    // Safety guard so user is never permanently stuck on the DTH startup overlay
    private val dismissBootSafetyRunnable: Runnable = Runnable {
        if (hasRenderedVideoFrame) return@Runnable
        if (allChannels.isNotEmpty()) {
            liveStatusLabel = "⏳ Connecting..."
            updateOsdForCurrentChannel()
            showZappingOsd()
            dismissDthBootOverlay("PLAYER READY • CONNECTING")
        } else {
            dismissDthBootOverlay("READY TO ADD PLAYLIST")
        }
    }

    private val persistStateRunnable: Runnable = Runnable {
        if (allChannels.isEmpty() || currentChannelIndex !in allChannels.indices) return@Runnable
        val ch = allChannels[currentChannelIndex]
        getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE).edit()
            .putString("recent_ids", recentIds.joinToString("\n"))
            .putString("last_channel_id", ch.id)
            .putInt("last_channel_index", currentChannelIndex)
            .apply()
        recordCurrentVodOrSeriesProgress()
    }

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            StreamPreFetcher.updateNetworkState(connected = true, degraded = false)
            uiHandler.post {
                val player = exoPlayer ?: return@post
                if ((allChannels.isNotEmpty() || activePlaybackMode != ActivePlaybackMode.LIVE_TV) &&
                    (player.playbackState == Player.STATE_IDLE || liveStatusLabel.startsWith("⚠️") || liveStatusLabel.startsWith("🔄"))
                ) {
                    playbackRetryCount = 0
                    stallRecoveryCount = 0
                    liveStatusLabel = "🔄 Network Restored..."
                    updateOsdForCurrentChannel()
                    if (activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
                        player.seekToDefaultPosition()
                    }
                    player.prepare()
                    player.playWhenReady = true
                }
            }
        }

        override fun onLost(network: Network) {
            StreamPreFetcher.updateNetworkState(connected = false)
            uiHandler.post {
                liveStatusLabel = "⚠️ Waiting for Network..."
                updateOsdForCurrentChannel()
            }
        }
    }

    // Default Built-in Live TV Test Streams (ALL strictly M3U_LIVE — never pollute Movies or Series!)
    private var allChannels: List<Channel> = listOf(
        Channel("1", 1, "Sports 18 HD (Test Stream)", "Sports", "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8", sourceType = ContentSourceType.M3U_LIVE),
        Channel("2", 2, "Cinema Gold 24x7 HD (Live TV)", "Movies", "https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8", sourceType = ContentSourceType.M3U_LIVE),
        Channel("3", 3, "Bharat News 24x7 HD", "News", "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8", sourceType = ContentSourceType.M3U_LIVE),
        Channel("4", 4, "Music Beats Dolby HD", "Music", "https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8", sourceType = ContentSourceType.M3U_LIVE)
    )
    private var allSequentialIndices: IntArray = IntArray(4) { it }
    private var channelsByCategory: Map<String, IntArray> = emptyMap()
    private var channelIndexById: Map<String, Int> = emptyMap()
    private var nonSequentialNumberMap: SparseIntArray = SparseIntArray(0)
    private var knownEpgAndChannelIds: Set<String> = emptySet()

    private var favoriteIds: MutableSet<String> = mutableSetOf("1")
    private var recentIds: MutableList<String> = mutableListOf()
    private var activeTab: String = "ALL"

    private var currentChannelIndex: Int = 0
    private var previousChannelIndex: Int = 0
    private var playbackRetryCount: Int = 0
    private var resizeModes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_FILL,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM
    )
    private var currentResizeIndex = 0
    private var sleepMinutes = 0
    @Volatile private var isPlayerLocked = false
    private var isAutoRefreshRunning = false
    private var tvDelayedSubtitleOverlay: TextView? = null
    private val audioDelayProcessor = AudioDelayProcessor()
    private val okHoldDeleteController = OkLongHoldDeleteController(thresholdMs = 2_000L)
    private var rawLoadedLiveChannels: List<Channel> = emptyList()
    private var rawLoadedVodMovies: List<Channel> = emptyList()
    private var rawLoadedSeries: List<Channel> = emptyList()
    private var formatFallbackUrl: String = ""
    private var formatFallbackStage: Int = 0
    private var lastAudioDiagnostics: AudioDiagnosticsSnapshot? = null
    private var audioRecoveryAttemptsForChannel: Int = 0
    private var lastAudioRecoveryElapsedMs: Long = 0L
    private var lastAudioDecoderError: String? = null
    private var lastAudioOutputError: String? = null
    private var audioRecoveryStatusLabel: String = "Idle"
    private var lastUndoDeletedCategory: String? = null
    private var okHoldDeleteDialogShowing: Boolean = false
    private var okHoldDeleteOverlay: LinearLayout? = null
    private var tvOkHoldDeleteTitle: TextView? = null
    private var tvOkHoldDeleteCountdown: TextView? = null
    private var pbOkHoldDeleteProgress: ProgressBar? = null
    private val recycleBinSelectedIds = LinkedHashSet<String>()
    private var recycleBinSearchQuery: String = ""

    private val okHoldPollRunnable = object : Runnable {
        override fun run() {
            if (!okHoldDeleteController.isHolding() || isFinishing || isDestroyed) {
                okHoldDeleteOverlay?.visibility = View.GONE
                return
            }
            val progress = okHoldDeleteController.pollProgress(SystemClock.elapsedRealtime())
            if (progress.showCountdownOverlay) {
                okHoldDeleteOverlay?.visibility = View.VISIBLE
                tvOkHoldDeleteTitle?.text = "Hold OK to Delete: #${progress.channelNumber} ${progress.channelName}"
                tvOkHoldDeleteCountdown?.text = "Keep holding ${progress.remainingSeconds}s... (Release to cancel)"
                pbOkHoldDeleteProgress?.progress = progress.progressPercent
            }
            if (progress.justReachedThreshold) {
                okHoldDeleteOverlay?.visibility = View.GONE
                val targetCh = allChannels.firstOrNull { it.id == progress.channelId }
                    ?: allChannels.getOrNull(currentChannelIndex)
                if (targetCh != null) {
                    showDeleteCurrentChannelConfirmationDialog(targetCh)
                }
                return
            }
            uiHandler.postDelayed(this, 80L)
        }
    }
    private var subtitleCueGeneration: Long = 0L
    private val autoRefreshRunnable = Runnable {
        if (!isFinishing && !isDestroyed) {
            triggerPlaylistRefreshNow(isScheduled = true)
        }
    }
    private val voiceSearchLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val matches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spoken = ProfileStore.sanitizeExternalInput(matches?.firstOrNull().orEmpty())
            if (spoken.isNotBlank()) {
                profileStore.addSearchHistoryQuery(spoken)
                showUnifiedSearchResultsModal(spoken)
            }
        }
    }
    private val sleepRunnable: Runnable = Runnable {
        exoPlayer?.pause()
        Toast.makeText(this, "Sleep Timer: Playback Paused", Toast.LENGTH_LONG).show()
    }

    // Direct O(1) Channel Number Entry with 0.75s (750ms) Auto-Tune Timer
    private var numberInputBuffer: String = ""
    private val numberJumpRunnable: Runnable = Runnable {
        val targetNum = numberInputBuffer.toIntOrNull()
        numberInputBuffer = ""
        if (targetNum != null) {
            val idx = findChannelIndexByNumberFast(targetNum)
            if (idx != -1) {
                switchChannel(idx, immediatePlayback = true)
            } else {
                Toast.makeText(this, "Channel #$targetNum not found", Toast.LENGTH_SHORT).show()
                updateOsdForCurrentChannel()
            }
        }
    }

    private fun dp(value: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value.toFloat(), resources.displayMetrics).toInt()

    private fun attach4dFocusMicroInteraction(view: View, focusedScale: Float = 1.035f) {
        view.onFocusChangeListener = View.OnFocusChangeListener { v, hasFocus ->
            if (activePerformanceMode.reducedAnimations) {
                v.scaleX = if (hasFocus) 1.015f else 1.0f
                v.scaleY = if (hasFocus) 1.015f else 1.0f
            } else {
                val target = if (hasFocus) focusedScale else 1.0f
                v.animate()
                    .scaleX(target)
                    .scaleY(target)
                    .setDuration(105L)
                    .start()
            }
        }
    }

    private fun findChannelIndexByNumberFast(targetNum: Int): Int {
        val directIdx = targetNum - 1
        if (directIdx in allChannels.indices && allChannels[directIdx].number == targetNum) {
            return directIdx
        }
        val mapped = nonSequentialNumberMap.get(targetNum, -1)
        if (mapped != -1 && mapped in allChannels.indices) return mapped
        return allChannels.indexOfFirst { it.number == targetNum }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        processStartElapsedMs = SystemClock.elapsedRealtime()
        hasRenderedVideoFrame = false
        super.onCreate(savedInstanceState)
        applyTrueEdgeToEdgeFullscreen()
        setContentView(R.layout.activity_player)
        applyTrueEdgeToEdgeFullscreen()

        dthBootOverlay = findViewById(R.id.dthBootOverlay)
        vSignalWaveOuter = findViewById(R.id.vSignalWaveOuter)
        vSignalWaveInner = findViewById(R.id.vSignalWaveInner)
        tvBootHeadline = findViewById(R.id.tvBootHeadline)
        tvBootStageStatus = findViewById(R.id.tvBootStageStatus)
        tvBootSubDetail = findViewById(R.id.tvBootSubDetail)
        bootProgressBar = findViewById(R.id.bootProgressBar)

        detectDeviceMemoryProfile()
        profileStore = ProfileStore(this)
        NetworkClient.setPreferredUserAgentProfile(profileStore.getPlayerUserAgentProfile())
        NetworkClient.loadStreamMetadataCache(cacheDir)
        selectedQualityLabel = profileStore.getPreferredVideoQuality()
        selectedQualityMaxSize = when (selectedQualityLabel) {
            "1080p" -> 1920 to 1080
            "720p" -> 1280 to 720
            "480p" -> 854 to 480
            "360p" -> 640 to 360
            else -> null
        }
        runCatching { Glide.get(this).setMemoryCategory(MemoryCategory.LOW) }

        startDthBootSignalAnimation()
        updateBootStage(8, "Starting RAM PLAYER v21.0 AMOLED 3D...", "Fast SXB2 Cache • 512MB Low-RAM Guard")

        findViewById<Button>(R.id.btnProfiles).setOnClickListener { showProfilesDialog() }
        playerView = findViewById(R.id.media3PlayerView)
        liveTvVlcLayout = findViewById(R.id.liveTvVlcVideoLayout)
        playerView.keepScreenOn = true
        playerView.subtitleView?.let { subView ->
            subView.setStyle(
                CaptionStyleCompat(
                    Color.WHITE,
                    Color.parseColor("#B8040B18"),
                    Color.TRANSPARENT,
                    CaptionStyleCompat.EDGE_TYPE_DROP_SHADOW,
                    Color.parseColor("#FF0284C7"),
                    Typeface.DEFAULT_BOLD
                )
            )
            subView.setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
        }
        topControlBar = findViewById(R.id.topControlBar)
        leftChannelDrawer = findViewById(R.id.leftChannelDrawer)
        channelListRecycler = findViewById(R.id.channelListRecycler)
        tvEmptyDrawer = findViewById(R.id.tvEmptyDrawer)
        osdBanner = findViewById(R.id.zappingOsdContainer)
        tvChannelNumber = findViewById(R.id.tvChannelNumber)
        okHoldDeleteOverlay = findViewById(R.id.okHoldDeleteOverlay)
        tvOkHoldDeleteTitle = findViewById(R.id.tvOkHoldDeleteTitle)
        tvOkHoldDeleteCountdown = findViewById(R.id.tvOkHoldDeleteCountdown)
        pbOkHoldDeleteProgress = findViewById(R.id.pbOkHoldDeleteProgress)
        tvChannelName = findViewById(R.id.tvChannelName)
        tvChannelCategory = findViewById(R.id.tvChannelCategory)
        tvOsdStreamBadge = findViewById(R.id.tvOsdStreamBadge)
        tvEpgNow = findViewById(R.id.tvEpgNow)
        osdLiveProgressBar = findViewById(R.id.osdLiveProgressBar)
        tvActiveSectionBadge = findViewById(R.id.tvActiveSectionBadge)
        btnToggleFavorite = findViewById(R.id.btnToggleFavorite)
        btnRecallChannel = findViewById(R.id.btnRecallChannel)
        btnHomeHub = findViewById(R.id.btnHomeHub)
        btnToggleDrawer = findViewById(R.id.btnToggleDrawer)
        btnSectionLiveTv = findViewById(R.id.btnSectionLiveTv)
        btnSectionMovies = findViewById(R.id.btnSectionMovies)
        btnSectionSeries = findViewById(R.id.btnSectionSeries)
        btnUnifiedSearch = findViewById(R.id.btnUnifiedSearch)
        tabAllChannels = findViewById(R.id.tabAllChannels)
        tabFavorites = findViewById(R.id.tabFavorites)
        tabRecent = findViewById(R.id.tabRecent)
        channelSearch = findViewById(R.id.channelSearch)
        categoryFilter = findViewById(R.id.categoryFilter)
        channelLogo = findViewById(R.id.channelLogo)

        // Bind v18.1 4D Movies & Series Hub views
        vodPosterGridPanel = findViewById(R.id.vodPosterGridPanel)
        tvVodLiveClockDate = findViewById(R.id.tvVodLiveClockDate)
        tvVodGridHeaderTitle = findViewById(R.id.tvVodGridHeaderTitle)
        btnVodContinueWatching = findViewById(R.id.btnVodContinueWatching)
        btnVodFavoritesFilter = findViewById(R.id.btnVodFavoritesFilter)
        btnVodSortOrder = findViewById(R.id.btnVodSortOrder)
        btnVodFetchProvider = findViewById(R.id.btnVodFetchProvider)
        btnVodSmartFilter = findViewById(R.id.btnVodSmartFilter)
        vodSpotlightBanner = findViewById(R.id.vodSpotlightBanner)
        ivVodSpotlightPoster = findViewById(R.id.ivVodSpotlightPoster)
        tvVodSpotlightTitle = findViewById(R.id.tvVodSpotlightTitle)
        tvVodSpotlightMeta = findViewById(R.id.tvVodSpotlightMeta)
        tvVodSpotlightHint = findViewById(R.id.tvVodSpotlightHint)
        btnVodSmartFilter?.setOnClickListener { showVodSmartFilterDialog() }
        btnCinemaSwitchMovies = findViewById(R.id.btnCinemaSwitchMovies)
        btnCinemaSwitchSeries = findViewById(R.id.btnCinemaSwitchSeries)
        vodEmptyHeroContainer = findViewById(R.id.vodEmptyHeroContainer)
        btnVodEmptyXtreamLogin = findViewById(R.id.btnVodEmptyXtreamLogin)
        btnVodEmptySync = findViewById(R.id.btnVodEmptySync)
        btnVodEmptyBackLive = findViewById(R.id.btnVodEmptyBackLive)
        btnCinemaSwitchMovies?.setOnClickListener {
            if (activeEntertainmentSection != EntertainmentSection.MOVIES) {
                switchToEntertainmentSection(EntertainmentSection.MOVIES)
            }
        }
        btnCinemaSwitchSeries?.setOnClickListener {
            if (activeEntertainmentSection != EntertainmentSection.SERIES) {
                switchToEntertainmentSection(EntertainmentSection.SERIES)
            }
        }
        btnVodEmptyXtreamLogin?.setOnClickListener { showXtreamLoginDialog() }
        btnVodEmptySync?.setOnClickListener { btnVodFetchProvider.performClick() }
        btnVodEmptyBackLive?.setOnClickListener { closeVodGridAndReturnToLiveTv() }
        btnVodRandomPick = findViewById(R.id.btnVodRandomPick)
        btnVodRandomPick?.setOnClickListener {
            if (activeEntertainmentSection == EntertainmentSection.MOVIES && vodMoviesCatalog.isNotEmpty()) {
                val randomIdx = java.util.Random().nextInt(vodMoviesCatalog.size)
                showMovieDetailModal(randomIdx)
            } else if (activeEntertainmentSection == EntertainmentSection.SERIES && seriesCatalogGroups.isNotEmpty()) {
                val randomGroup = seriesCatalogGroups[java.util.Random().nextInt(seriesCatalogGroups.size)]
                showSeriesDetailModal(randomGroup)
            } else {
                Toast.makeText(this, "Connect Xtream VIP & Sync VOD first to use Surprise Me!", Toast.LENGTH_SHORT).show()
            }
        }
        btnCloseVodGrid = findViewById(R.id.btnCloseVodGrid)
        vodPosterSearch = findViewById(R.id.vodPosterSearch)
        vodCategorySpinner = findViewById(R.id.vodCategorySpinner)
        vodCategorySidebarRecycler = findViewById(R.id.vodCategorySidebarRecycler)
        tvVodEmptyState = findViewById(R.id.tvVodEmptyState)
        vodPosterRecycler = findViewById(R.id.vodPosterRecycler)

        // Live TV Channel Drawer Adapter — strictly switches Live TV channels
        channelAdapter = ChannelDrawerAdapter(
            channelProvider = { idx -> allChannels.getOrNull(idx) },
            isFavorite = { id -> favoriteIds.contains(id) },
            epgProvider = { ch -> lookupEpgForChannel(ch)?.first },
            logoOptions = logoRequestOptions,
            onChannelClick = { globalIdx ->
                activePlaybackMode = ActivePlaybackMode.LIVE_TV
                switchChannel(globalIdx, immediatePlayback = true)
            },
            onChannelFocused = { globalIdx ->
                val focusedCh = allChannels.getOrNull(globalIdx)
                if (focusedCh != null && focusedCh.streamUrl != currentPlayingStreamUrl) {
                    StreamPreFetcher.scheduleFocusPrefetch(
                        this@PlayerActivity,
                        focusedCh.streamUrl,
                        hlsChunklessFactory,
                        defaultMediaSourceFactory
                    )
                }
            }
        )
        val linearLm = LinearLayoutManager(this)
        channelListRecycler.layoutManager = linearLm
        channelListRecycler.setHasFixedSize(true)
        val cacheViews = if (isLowRamTvDevice) 5 else 8
        val poolViews = if (isLowRamTvDevice) 10 else 14
        channelListRecycler.setItemViewCacheSize(cacheViews)
        channelListRecycler.recycledViewPool.setMaxRecycledViews(0, poolViews)
        channelListRecycler.itemAnimator = null
        channelListRecycler.adapter = channelAdapter

        // Left VOD Category Sidebar Adapter (matches reference screenshots: FAVORITES, RECENTLY ADDED, CONTINUE WATCHING, BOLLYWOOD (297), etc.)
        vodSidebarAdapter = VodCategorySidebarAdapter(
            reducedAnimations = { activePerformanceMode.reducedAnimations },
            onCategorySelected = { catItem ->
                selectedVodCategory = catItem.categoryName
                vodSpecialFilterMode = when (catItem.categoryName) {
                    "CONTINUE WATCHING" -> "CONTINUE"
                    "FAVORITES / WATCHLIST" -> "FAV"
                    "RECENTLY ADDED" -> "RECENT_ADDED"
                    else -> "ALL"
                }
                vodSidebarAdapter.setSelectedCategory(catItem.categoryName)
                renderVodPosterGrid()
            }
        )
        vodCategorySidebarRecycler.layoutManager = LinearLayoutManager(this)
        vodCategorySidebarRecycler.setHasFixedSize(true)
        vodCategorySidebarRecycler.itemAnimator = null
        vodCategorySidebarRecycler.adapter = vodSidebarAdapter

        // Right 5-Column Responsive TV Poster Grid for Movies & Series (matches reference screenshots with left sidebar)
        val posterColumns = computeResponsivePosterSpanCount()
        val gridLm = GridLayoutManager(this, posterColumns)
        vodPosterRecycler.layoutManager = gridLm
        vodPosterRecycler.setHasFixedSize(true)
        vodPosterRecycler.setItemViewCacheSize(if (isLowRamTvDevice) 5 else 10)
        vodPosterRecycler.recycledViewPool.setMaxRecycledViews(0, if (isLowRamTvDevice) 10 else 16)
        vodPosterRecycler.itemAnimator = null
        posterGridAdapter = VodPosterGridAdapter(
            posterOptionsProvider = { currentPosterRequestOptions() },
            reducedAnimations = { activePerformanceMode.reducedAnimations },
            onPosterFocused = { pos ->
                lastFocusedPosterIndex = pos
                posterGridAdapter.getItemOrNull(pos)?.let { updateVodSpotlightBanner(it) }
            },
            onPosterClicked = { item ->
                if (item.seriesSummary != null) {
                    showSeriesDetailModal(item.seriesSummary)
                } else if (item.vodMovieIndex in vodMoviesCatalog.indices) {
                    showMovieDetailModal(item.vodMovieIndex)
                }
            }
        )
        vodPosterRecycler.adapter = posterGridAdapter

        channelListRecycler.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                runCatching {
                    if (newState == RecyclerView.SCROLL_STATE_SETTLING) {
                        Glide.with(this@PlayerActivity).pauseRequests()
                    } else {
                        Glide.with(this@PlayerActivity).resumeRequests()
                    }
                }
            }

            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                if (dy <= 0) return
                val totalLoadedInAdapter = channelAdapter.itemCount
                if (totalLoadedInAdapter < fullFilteredIndices.size) {
                    val lastVisible = linearLm.findLastVisibleItemPosition()
                    if (lastVisible >= totalLoadedInAdapter - 25) {
                        currentPagedLimit = (currentPagedLimit + pageStepSize).coerceAtMost(fullFilteredIndices.size)
                        channelAdapter.submitIndices(
                            fullFilteredIndices.copyOfRange(0, currentPagedLimit),
                            currentChannelIndex,
                            null
                        )
                    }
                }
            }
        })

        vodPosterRecycler.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                runCatching {
                    if (newState == RecyclerView.SCROLL_STATE_SETTLING) {
                        Glide.with(this@PlayerActivity).pauseRequests()
                    } else {
                        Glide.with(this@PlayerActivity).resumeRequests()
                    }
                }
            }
        })

        setupUiListeners()

        window.decorView.post {
            firstUiFrameMs = SystemClock.elapsedRealtime() - processStartElapsedMs
            startStagedBootSequence()
        }
    }

    private fun computeResponsivePosterSpanCount(): Int {
        val dm = resources.displayMetrics
        val screenWidthDp = (dm.widthPixels / dm.density).toInt()
        val preferredCols = if (::profileStore.isInitialized) {
            profileStore.getUiDensityMode().tvPosterColumns
        } else 5
        return when {
            screenWidthDp >= 900 -> preferredCols
            screenWidthDp >= 720 -> (preferredCols - 1).coerceAtLeast(4)
            else -> 3
        }
    }

    private fun updateVodHeaderClockText() {
        runCatching {
            val use24h = ::profileStore.isInitialized && profileStore.is24HourClockEnabled()
            val pattern = if (use24h) "HH:mm:ss • EEE, dd MMM yyyy" else "hh:mm:ss a • EEE, dd MMM yyyy"
            val sdf = SimpleDateFormat(pattern, Locale.US)
            tvVodLiveClockDate.text = sdf.format(Date())
        }
    }

    private fun applyOverscanMarginFromSettings() {
        if (!::profileStore.isInitialized) return
        val marginDp = profileStore.getOverscanMarginDp()
        val px = dp(marginDp)
        topControlBar.setPadding(px, px / 2, px, 0)
        vodPosterGridPanel.setPadding(px, px / 2, px, px / 2)
    }

    private fun checkIdleScreensaverTrigger() {
        if (!::profileStore.isInitialized || isScreensaverShowing) return
        val idleMins = profileStore.getIdleScreensaverMinutes()
        if (idleMins <= 0) return
        val playerPlaying = exoPlayer?.isPlaying == true
        if (playerPlaying) {
            lastUserInteractionElapsedMs = SystemClock.elapsedRealtime()
            return
        }
        val elapsedMs = SystemClock.elapsedRealtime() - lastUserInteractionElapsedMs
        if (elapsedMs >= idleMins * 60_000L) {
            showAmbientScreensaverModal()
        }
    }

    private fun detectDeviceMemoryProfile() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        if (am != null) {
            val memInfo = ActivityManager.MemoryInfo()
            am.getMemoryInfo(memInfo)
            totalDeviceRamMb = (memInfo.totalMem / (1024L * 1024L)).coerceAtLeast(256L)
            isLowRamTvDevice = am.isLowRamDevice || totalDeviceRamMb <= 850L
        } else {
            isLowRamTvDevice = true
        }
        maxPlaylistLimit = 60_000
    }

    private fun startDthBootSignalAnimation() {
        val satellite = findViewById<View>(R.id.ivBootSatellite)
        satellite.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        satellitePulseAnimator = ObjectAnimator.ofPropertyValuesHolder(
            satellite,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 0.97f, 1.03f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 0.97f, 1.03f),
            PropertyValuesHolder.ofFloat(View.ALPHA, 0.88f, 1.0f)
        ).apply {
            duration = 2200L
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            start()
        }
        if (isLowRamTvDevice) return
        val scaleXOuter = PropertyValuesHolder.ofFloat(View.SCALE_X, 0.90f, 1.10f)
        val scaleYOuter = PropertyValuesHolder.ofFloat(View.SCALE_Y, 0.90f, 1.10f)
        val alphaOuter = PropertyValuesHolder.ofFloat(View.ALPHA, 0.70f, 0.20f)
        outerWaveAnimator = ObjectAnimator.ofPropertyValuesHolder(
            vSignalWaveOuter,
            scaleXOuter,
            scaleYOuter,
            alphaOuter
        ).apply {
            duration = 1500L
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.RESTART
            start()
        }

        val alphaInner = PropertyValuesHolder.ofFloat(View.ALPHA, 0.40f, 0.85f)
        innerWaveAnimator = ObjectAnimator.ofPropertyValuesHolder(
            vSignalWaveInner,
            alphaInner
        ).apply {
            duration = 1100L
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            start()
        }
    }

    private fun cancelBootAnimators() {
        outerWaveAnimator?.cancel()
        innerWaveAnimator?.cancel()
        satellitePulseAnimator?.cancel()
        outerWaveAnimator = null
        innerWaveAnimator = null
        satellitePulseAnimator = null
    }

    private fun updateBootStage(progress: Int, stageText: String, subDetail: String? = null) {
        if (!isBootOverlayVisible) return
        bootProgressBar.progress = progress.coerceIn(0, 100)
        tvBootStageStatus.text = stageText
        if (subDetail != null) {
            tvBootSubDetail.text = subDetail
        }
    }

    private fun dismissDthBootOverlay(finalMessage: String = "READY TO WATCH") {
        if (!isBootOverlayVisible) return
        isBootOverlayVisible = false
        uiHandler.removeCallbacks(dismissBootSafetyRunnable)
        bootReadyElapsedMs = SystemClock.elapsedRealtime() - processStartElapsedMs
        bootProgressBar.progress = 100
        tvBootHeadline.text = finalMessage
        tvBootStageStatus.text = "RAM PLAYER v21.0 Ready • ${bootReadyElapsedMs}ms"
        cancelBootAnimators()
        dthBootOverlay.animate()
            .alpha(0f)
            .setDuration(150L)
            .withLayer()
            .withEndAction {
                dthBootOverlay.visibility = View.GONE
                dthBootOverlay.alpha = 1f
            }
            .start()
    }

    private fun isNetworkConnectedNow(): Boolean {
        val cm = connectivityManager ?: return true
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val net = cm.activeNetwork ?: return false
                val caps = cm.getNetworkCapabilities(net) ?: return false
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            } else {
                @Suppress("DEPRECATION")
                cm.activeNetworkInfo?.isConnected == true
            }
        } catch (_: Exception) {
            true
        }
    }

    private fun startStagedBootSequence() {
        uiHandler.postDelayed(dismissBootSafetyRunnable, 20_000L)
        uiHandler.postDelayed(heapGuardRunnable, 5000L)
        uiHandler.postDelayed(vodProgressTrackerRunnable, 4000L)

        lifecycleScope.launch {
            updateBootStage(
                20,
                "Loading saved settings...",
                "RAM Profile: ${totalDeviceRamMb}MB (${if (isLowRamTvDevice) "512MB Ultra Extreme" else "Standard"})"
            )
            val prefs = getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
            val bootSettings = withContext(Dispatchers.IO) {
                if (!::profileStore.isInitialized) profileStore = ProfileStore(this@PlayerActivity)
                channelCache = ChannelCacheStore(this@PlayerActivity)
                epgCache = EpgCacheStore(this@PlayerActivity)

                val favs = prefs.getStringSet("fav_ids", null)?.toHashSet() ?: hashSetOf("1")
                val recents = prefs.getString("recent_ids", "")
                    ?.lines()
                    ?.filter { it.isNotBlank() }
                    ?.take(20) ?: emptyList()
                val themeIdx = prefs.getInt("theme_index", 0)
                val perfMode = profileStore.getPerformanceMode(isLowRamTvDevice)
                val bufId = prefs.getString("buffer_profile_id", null) ?: perfMode.recommendedBufferProfileId
                val autoBoot = prefs.getBoolean("auto_boot_enabled", true)
                val autoResume = prefs.getBoolean("auto_resume_enabled", true)
                val savedEpgUrl = prefs.getString("last_epg_url", "") ?: ""
                val cachedEpg = epgCache.loadEpg()

                BootSettingsBundle(
                    favs = favs,
                    recents = recents,
                    themeIndex = themeIdx,
                    performanceMode = perfMode,
                    bufferProfile = BufferProfile.fromId(bufId, isLowRamTvDevice),
                    autoBoot = autoBoot,
                    autoResume = autoResume,
                    savedEpgUrl = savedEpgUrl,
                    cachedEpg = cachedEpg
                )
            }

            favoriteIds.clear()
            favoriteIds.addAll(bootSettings.favs)
            recentIds.clear()
            recentIds.addAll(bootSettings.recents)
            activePerformanceMode = bootSettings.performanceMode
            StreamPreFetcher.setPerformanceMode(activePerformanceMode)
            activeBufferProfile = bootSettings.bufferProfile
            autoBootEnabled = bootSettings.autoBoot
            autoResumeEnabled = bootSettings.autoResume
            applyTheme(bootSettings.themeIndex)
            updateSectionButtonsUi(EntertainmentSection.LIVE_TV)

            if (bootSettings.cachedEpg != null) {
                epgMap = bootSettings.cachedEpg.entries
            }

            updateBootStage(
                45,
                "Initializing Direct-RAM Media Engine...",
                "Mode: ${activePerformanceMode.title} • ${activeBufferProfile.label}"
            )
            initializeMedia3ProEngine()
            rebuildChannelIndicesSync(allChannels)

            val hasNet = isNetworkConnectedNow()
            val epgUrlToRefresh = bootSettings.savedEpgUrl.ifBlank { bootSettings.cachedEpg?.sourceUrl.orEmpty() }
            if (hasNet && epgUrlToRefresh.isNotBlank()) {
                val epgAge = System.currentTimeMillis() - (bootSettings.cachedEpg?.timestampMs ?: 0L)
                if (epgAge > EpgCacheStore.EPG_REFRESH_INTERVAL_MS) {
                    loadXmltvEpg(epgUrlToRefresh, silentBackground = true)
                }
            }

            updateBootStage(65, "Restoring Channels from Fast SXB2 Cache...", "Instant Direct-RAM Boot")
            restoreSavedDataFromBoot(prefs, hasNet)
        }
    }

    private data class BootSettingsBundle(
        val favs: Set<String>,
        val recents: List<String>,
        val themeIndex: Int,
        val performanceMode: PerformanceMode,
        val bufferProfile: BufferProfile,
        val autoBoot: Boolean,
        val autoResume: Boolean,
        val savedEpgUrl: String,
        val cachedEpg: CachedEpgData?
    )

    private fun updateTabButton3dSelection(selectedTab: String) {
        val activeRes = themes[currentThemeIndex].activeRowDrawableRes
        tabAllChannels.isSelected = selectedTab == "ALL"
        tabFavorites.isSelected = selectedTab == "FAV"
        tabRecent.isSelected = selectedTab == "RECENT"
        tabAllChannels.setBackgroundResource(if (selectedTab == "ALL") activeRes else R.drawable.bg_btn_3d_slate)
        tabFavorites.setBackgroundResource(if (selectedTab == "FAV") R.drawable.bg_btn_3d_gold else R.drawable.bg_btn_3d_slate)
        tabRecent.setBackgroundResource(if (selectedTab == "RECENT") activeRes else R.drawable.bg_btn_3d_slate)
    }

    private fun updateSectionButtonsUi(section: EntertainmentSection) {
        activeEntertainmentSection = section
        btnSectionLiveTv.isSelected = section == EntertainmentSection.LIVE_TV
        btnSectionMovies.isSelected = section == EntertainmentSection.MOVIES
        btnSectionSeries.isSelected = section == EntertainmentSection.SERIES
        btnSectionLiveTv.setBackgroundResource(
            if (section == EntertainmentSection.LIVE_TV) R.drawable.bg_btn_3d_cyan else R.drawable.bg_btn_3d_slate
        )
        btnSectionMovies.setBackgroundResource(
            if (section == EntertainmentSection.MOVIES) R.drawable.bg_btn_3d_crimson else R.drawable.bg_btn_3d_slate
        )
        btnSectionSeries.setBackgroundResource(
            if (section == EntertainmentSection.SERIES) R.drawable.bg_btn_3d_purple else R.drawable.bg_btn_3d_slate
        )
    }

    private fun createGlassCategoryAdapter(categories: List<String>, prefixLabel: String = "Category"): ArrayAdapter<String> {
        return object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val tv = (convertView as? TextView) ?: TextView(this@PlayerActivity).apply {
                    setSingleLine(true)
                    ellipsize = TextUtils.TruncateAt.END
                    gravity = Gravity.CENTER_VERTICAL
                    textSize = 12f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(Color.parseColor("#E0F2FE"))
                    setPadding(dp(10), dp(6), dp(10), dp(6))
                    setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_3d_category, 0, 0, 0)
                    compoundDrawablePadding = dp(8)
                }
                val item = getItem(position) ?: "All categories"
                tv.text = "$prefixLabel: $item"
                return tv
            }

            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
                val tv = (convertView as? TextView) ?: TextView(this@PlayerActivity).apply {
                    setSingleLine(true)
                    ellipsize = TextUtils.TruncateAt.END
                    gravity = Gravity.CENTER_VERTICAL
                    textSize = 13f
                    setTypeface(typeface, Typeface.BOLD)
                    setPadding(dp(14), dp(11), dp(14), dp(11))
                    setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_3d_category, 0, 0, 0)
                    compoundDrawablePadding = dp(10)
                }
                val item = getItem(position) ?: "All categories"
                val activeSel = if (prefixLabel == "Category") selectedCategory else selectedVodCategory
                val isSelected = item == activeSel
                tv.text = if (isSelected) "● $item  ✓" else item
                tv.setTextColor(if (isSelected) Color.parseColor("#38BDF8") else Color.parseColor("#F8FAFC"))
                tv.setBackgroundColor(if (isSelected) Color.parseColor("#FF0D213F") else Color.parseColor("#FF071022"))
                return tv
            }
        }
    }

    private fun setupUiListeners() {
        channelSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                searchQuery = s?.toString().orEmpty()
                renderDrawerList(debounceMs = 110L)
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        categoryFilter.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (suppressCategoryCallback) return
                selectedCategory = parent?.getItemAtPosition(position)?.toString() ?: "All categories"
                renderDrawerList()
            }
        }

        vodPosterSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                vodSearchQuery = s?.toString().orEmpty()
                renderVodPosterGrid(debounceMs = 110L)
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        vodCategorySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (suppressVodCategoryCallback) return
                val rawLabel = parent?.getItemAtPosition(position)?.toString() ?: "RECENTLY ADDED"
                val cleanCat = rawLabel.substringBeforeLast(" (").trim()
                selectedVodCategory = cleanCat
                vodSpecialFilterMode = when (cleanCat) {
                    "CONTINUE WATCHING" -> "CONTINUE"
                    "FAVORITES / WATCHLIST" -> "FAV"
                    "RECENTLY ADDED" -> "RECENT_ADDED"
                    else -> "ALL"
                }
                vodSidebarAdapter.setSelectedCategory(cleanCat)
                renderVodPosterGrid()
            }
        }

        runCatching { applyOverscanMarginFromSettings() }
        runCatching { applySidebarCustomization() }
        runCatching { scheduleAutoRefreshIfConfigured() }
        if (::profileStore.isInitialized) {
            runCatching { profileStore.purgeExpiredRecycleBinEntries(30) }
        }
        runCatching {
            applyPictureBrightnessMode(if (::profileStore.isInitialized) profileStore.getPictureMode() else "STANDARD")
        }

        btnHomeHub.setOnClickListener {
            showCinematicHomeHubDialog()
        }
        btnHomeHub.setOnLongClickListener {
            showGlobalQuickMenuDialog()
            true
        }

        btnToggleDrawer.setOnClickListener {
            if (leftChannelDrawer.visibility == View.VISIBLE) {
                closeDrawerAndRestoreFocus()
            } else {
                vodPosterGridPanel.visibility = View.GONE
                updateSectionButtonsUi(EntertainmentSection.LIVE_TV)
                openDrawerAndRequestFocus()
            }
        }
        btnToggleDrawer.setOnLongClickListener {
            showLiveChannelManagementModal()
            true
        }

        // Primary Entertainment Section 1: LIVE TV
        btnSectionLiveTv.setOnClickListener {
            switchToEntertainmentSection(EntertainmentSection.LIVE_TV)
        }

        // Primary Entertainment Section 2: MOVIES (Left Category Sidebar + Poster Grid Hub)
        btnSectionMovies.setOnClickListener {
            switchToEntertainmentSection(EntertainmentSection.MOVIES)
        }

        // Primary Entertainment Section 3: SERIES (Left Category Sidebar + Poster Grid Hub)
        btnSectionSeries.setOnClickListener {
            switchToEntertainmentSection(EntertainmentSection.SERIES)
        }

        // Universal Smart Search Hub Button
        btnUnifiedSearch.setOnClickListener {
            showUnifiedSearchDialog()
        }

        btnVodContinueWatching.setOnClickListener {
            selectedVodCategory = "CONTINUE WATCHING"
            vodSpecialFilterMode = "CONTINUE"
            vodSidebarAdapter.setSelectedCategory("CONTINUE WATCHING")
            renderVodPosterGrid()
        }

        btnVodFavoritesFilter.setOnClickListener {
            selectedVodCategory = "FAVORITES / WATCHLIST"
            vodSpecialFilterMode = "FAV"
            vodSidebarAdapter.setSelectedCategory("FAVORITES / WATCHLIST")
            renderVodPosterGrid()
        }

        btnVodSortOrder.setOnClickListener {
            activeVodSortOrder = activeVodSortOrder.nextOrder()
            btnVodSortOrder.text = "↓ ${activeVodSortOrder.badgeLabel}"
            Toast.makeText(this, "Sort: ${activeVodSortOrder.fullTitle}", Toast.LENGTH_SHORT).show()
            renderVodPosterGrid()
        }
        btnVodSortOrder.setOnLongClickListener {
            showVodSmartFilterDialog()
            true
        }

        btnVodFetchProvider.setOnClickListener {
            val creds = activeXtreamCreds
            if (activeSourceType == ProfileType.XTREAM && creds != null) {
                if (activeEntertainmentSection == EntertainmentSection.SERIES) {
                    loadXtreamSeriesCatalog(creds, forceNetworkRefresh = true)
                } else {
                    loadXtreamVodMovies(creds, forceNetworkRefresh = true)
                }
            } else {
                showXtreamLoginDialog()
            }
        }

        btnCloseVodGrid.setOnClickListener {
            closeVodGridAndReturnToLiveTv()
        }

        tabAllChannels.setOnClickListener {
            activeTab = "ALL"
            updateTabButton3dSelection("ALL")
            tvActiveSectionBadge.text = "RAM PLAYER v21.0 • All Live TV (${allChannels.size})"
            renderDrawerList()
        }
        tabFavorites.setOnClickListener {
            activeTab = "FAV"
            updateTabButton3dSelection("FAV")
            tvActiveSectionBadge.text = "RAM PLAYER v21.0 • ★ Favorites (${favoriteIds.size})"
            renderDrawerList()
        }
        tabRecent.setOnClickListener {
            activeTab = "RECENT"
            updateTabButton3dSelection("RECENT")
            tvActiveSectionBadge.text = "RAM PLAYER v21.0 • Recent Watched"
            renderDrawerList()
        }

        val btnProfiles = findViewById<Button>(R.id.btnProfiles)
        val btnXtream = findViewById<Button>(R.id.btnXtreamLogin)
        val btnM3u = findViewById<Button>(R.id.btnM3uLoad)
        val btnRefresh = findViewById<Button>(R.id.btnRefreshChannels)
        val btnAudio = findViewById<Button>(R.id.btnAudioQuality)
        val btnTheme = findViewById<Button>(R.id.btnThemeToggle)
        val btnEpg = findViewById<Button>(R.id.btnEpg)
        val btnSleep = findViewById<Button>(R.id.btnSleepTimer)
        val btnAspect = findViewById<Button>(R.id.btnAspectToggle)
        val btnSettings = findViewById<Button>(R.id.btnSettings)
        val btnZapUp = findViewById<Button>(R.id.btnZapUp)
        val btnZapDown = findViewById<Button>(R.id.btnZapDown)

        for (btn in listOf(
            btnHomeHub, btnToggleDrawer, btnSectionLiveTv, btnSectionMovies, btnSectionSeries, btnUnifiedSearch,
            btnProfiles, btnXtream, btnM3u, btnRefresh,
            btnAudio, btnTheme, btnEpg, btnSleep, btnAspect, btnSettings,
            tabAllChannels, tabFavorites, tabRecent,
            btnVodContinueWatching, btnVodFavoritesFilter, btnVodSortOrder, btnVodFetchProvider, btnCloseVodGrid,
            btnRecallChannel, btnToggleFavorite, btnZapDown, btnZapUp
        )) {
            attach4dFocusMicroInteraction(btn)
        }

        btnXtream.setOnClickListener { showXtreamLoginDialog() }
        btnM3u.setOnClickListener { showM3uLoadDialog() }
        btnRefresh.setOnClickListener { forceRefreshActivePlaylist() }
        btnAudio.setOnClickListener { showAudioAndQualityDialog() }
        btnTheme.setOnClickListener { showThemeAndPipDialog() }
        btnSettings.setOnClickListener { showCategorizedSettingsCenterDialog() }

        btnZapUp.setOnClickListener {
            if (activePlaybackMode != ActivePlaybackMode.LIVE_TV) {
                activePlaybackMode = ActivePlaybackMode.LIVE_TV
            }
            lastRemoteKeyPressElapsedMs = SystemClock.elapsedRealtime()
            lastZapForward = true
            switchChannel(currentChannelIndex + 1, immediatePlayback = true)
        }
        btnZapDown.setOnClickListener {
            if (activePlaybackMode != ActivePlaybackMode.LIVE_TV) {
                activePlaybackMode = ActivePlaybackMode.LIVE_TV
            }
            lastRemoteKeyPressElapsedMs = SystemClock.elapsedRealtime()
            lastZapForward = false
            switchChannel(currentChannelIndex - 1, immediatePlayback = true)
        }
        btnRecallChannel.setOnClickListener { recallPreviousChannel() }
        btnToggleFavorite.setOnClickListener { toggleCurrentChannelFavorite() }

        btnEpg.setOnClickListener { showEpgGuideHubDialog() }
        btnEpg.setOnLongClickListener { showEpgUrlDialog(); true }

        btnSleep.setOnLongClickListener { showSleepTimerCustomDialog(); true }
        btnSleep.setOnClickListener {
            sleepMinutes = when (sleepMinutes) {
                0 -> 15
                15 -> 30
                30 -> 45
                45 -> 60
                60 -> 90
                else -> 0
            }
            uiHandler.removeCallbacks(sleepRunnable)
            if (sleepMinutes > 0) {
                uiHandler.postDelayed(sleepRunnable, sleepMinutes * 60 * 1000L)
                btnSleep.text = "Sleep: ${sleepMinutes}m"
                Toast.makeText(this, "Sleep Timer set for $sleepMinutes mins", Toast.LENGTH_SHORT).show()
            } else {
                btnSleep.text = "Sleep: OFF"
            }
        }

        btnAspect.setOnClickListener {
            currentResizeIndex = (currentResizeIndex + 1) % resizeModes.size
            playerView.resizeMode = resizeModes[currentResizeIndex]
        liveTvVlcEngine?.setAspectRatioByResizeIndex(currentResizeIndex)
            btnAspect.text = when (currentResizeIndex) {
                0 -> "16:9 Fit"
                1 -> "Full Stretch"
                else -> "Cinema Zoom"
            }
        }

        playerView.setOnClickListener {
            when {
                vodPosterGridPanel.visibility == View.VISIBLE -> closeVodGridAndReturnToLiveTv()
                leftChannelDrawer.visibility == View.VISIBLE -> closeDrawerAndRestoreFocus()
                else -> showZappingOsd()
            }
        }
    }

    // =========================================================================
    // v18.1 THREE PRIMARY ENTERTAINMENT SECTIONS: LIVE TV | MOVIES | SERIES
    // =========================================================================

    /**
     * Live TV Background Playback Management:
     * Immediately stops Live TV audio/video and releases player/decoder/prefetch buffers when the user
     * navigates away from Live TV into Movies, Series, Home, Search, Settings, or other non-live sections
     * (unless Picture-in-Picture mode is active). Never stops active VOD Movie or Series Episode playback.
     */
    private fun suspendLiveTvForNonLiveSection(targetSectionName: String) {
        val inPip = Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && isInPictureInPictureMode
        val stopSetting = !::profileStore.isInitialized || profileStore.isStopLiveTvInBackgroundEnabled()
        if (!LiveTvBackgroundPlaybackController.shouldSuspendLiveTvForSection(
                isLiveTvPlaybackMode = (activePlaybackMode == ActivePlaybackMode.LIVE_TV),
                isInPictureInPictureMode = inPip,
                stopInBackgroundSettingEnabled = stopSetting
            )
        ) {
            return
        }
        val ch = allChannels.getOrNull(currentChannelIndex)
        LiveTvBackgroundPlaybackController.recordLiveTvSuspended(
            channelIndex = currentChannelIndex,
            channelId = ch?.id.orEmpty(),
            channelName = ch?.name ?: "Live TV",
            targetSectionName = targetSectionName
        )
        StreamPreFetcher.cancelAllPrefetches()
        uiHandler.removeCallbacks(stallWatchdogRunnable)
        uiHandler.removeCallbacks(retryPlaybackRunnable)
        uiHandler.removeCallbacks(blackScreenWatchdogRunnable)
        stopLiveTvLibVlcIfActive()
        exoPlayer?.let { player ->
            if (player.isPlaying || player.playbackState == Player.STATE_BUFFERING || player.playbackState == Player.STATE_READY) {
                player.playWhenReady = false
                player.stop()
                player.clearMediaItems()
            }
        }
        currentPlayingStreamUrl = ""
        liveStatusLabel = "⏸ Live TV Stopped ($targetSectionName)"
    }

    /**
     * Restores the previously selected Live TV channel when returning from Movies, Series, Search, Settings, or Home.
     * Respects `profileStore.isAutoReconnectLiveTvOnReturnEnabled()` — remembers and highlights the channel
     * without auto-streaming unless the user's setting requires automatic reconnection or they press OK/Play.
     */
    private fun restoreLiveTvOnReturnFromNonLiveSection() {
        val suspended = LiveTvBackgroundPlaybackController.consumeSuspendedState()
        if (allChannels.isNotEmpty() && suspended.wasSuspended) {
            val restoredIdx = if (suspended.channelId.isNotBlank()) {
                channelIndexById[suspended.channelId] ?: suspended.channelIndex.coerceIn(0, allChannels.lastIndex)
            } else {
                suspended.channelIndex.coerceIn(0, allChannels.lastIndex)
            }
            currentChannelIndex = restoredIdx
            channelAdapter.updateActiveChannel(currentChannelIndex)
        }
        val autoReconnect = !::profileStore.isInitialized || profileStore.isAutoReconnectLiveTvOnReturnEnabled()
        val playerIdle = exoPlayer == null || exoPlayer?.playbackState == Player.STATE_IDLE || currentPlayingStreamUrl.isEmpty()
        if (autoReconnect && playerIdle && allChannels.isNotEmpty()) {
            startPlaybackForCurrentChannel(forceReload = true)
        } else if (playerIdle && allChannels.isNotEmpty()) {
            val ch = allChannels.getOrNull(currentChannelIndex)
            liveStatusLabel = "⏸ ${ch?.name ?: "Live TV"} Ready • Press OK / Play to Watch"
            updateOsdForCurrentChannel()
            showZappingOsd()
        }
    }

    private fun switchToEntertainmentSection(section: EntertainmentSection) {
        updateSectionButtonsUi(section)
        when (section) {
            EntertainmentSection.LIVE_TV -> {
                vodPosterGridPanel.visibility = View.GONE
                topControlBar.visibility = View.VISIBLE
                if (activePlaybackMode != ActivePlaybackMode.LIVE_TV) {
                    exoPlayer?.let { p ->
                        p.playWhenReady = false
                        p.stop()
                        p.clearMediaItems()
                    }
                    currentPlayingStreamUrl = ""
                    activePlaybackMode = ActivePlaybackMode.LIVE_TV
                }
                restoreLiveTvOnReturnFromNonLiveSection()
                tvActiveSectionBadge.text = "RAM PLAYER v21.0 • LIVE TV (${allChannels.size})"
                openDrawerAndRequestFocus()
            }
            EntertainmentSection.MOVIES -> {
                suspendLiveTvForNonLiveSection("Movies")
                leftChannelDrawer.visibility = View.GONE
                topControlBar.visibility = View.GONE
                osdBanner.visibility = View.GONE
                vodSpecialFilterMode = "RECENT_ADDED"
                selectedVodCategory = "RECENTLY ADDED"
                vodPosterSearch.setText("")
                vodSearchQuery = ""
                openVodPosterHub(EntertainmentSection.MOVIES)
            }
            EntertainmentSection.SERIES -> {
                suspendLiveTvForNonLiveSection("Series")
                leftChannelDrawer.visibility = View.GONE
                topControlBar.visibility = View.GONE
                osdBanner.visibility = View.GONE
                vodSpecialFilterMode = "RECENT_ADDED"
                selectedVodCategory = "RECENTLY ADDED"
                vodPosterSearch.setText("")
                vodSearchQuery = ""
                openVodPosterHub(EntertainmentSection.SERIES)
            }
        }
    }

    private fun openVodPosterHub(section: EntertainmentSection, restoreFocusIndex: Int = 0) {
        suspendLiveTvForNonLiveSection(section.displayTitle)
        val desiredSpan = computeResponsivePosterSpanCount()
        (vodPosterRecycler.layoutManager as? GridLayoutManager)?.spanCount = desiredSpan
        updateVodHeaderClockText()
        vodPosterGridPanel.alpha = 0f
        vodPosterGridPanel.visibility = View.VISIBLE
        vodPosterGridPanel.animate()
            .alpha(1f)
            .setDuration(if (activePerformanceMode.reducedAnimations) 60L else 130L)
            .withLayer()
            .start()

        topControlBar.visibility = View.GONE
        osdBanner.visibility = View.GONE
        val isMovies = section == EntertainmentSection.MOVIES
        btnCinemaSwitchMovies?.isSelected = isMovies
        btnCinemaSwitchSeries?.isSelected = !isMovies
        btnCinemaSwitchMovies?.setTextColor(if (isMovies) Color.parseColor("#F4F5F7") else Color.parseColor("#9CA3AF"))
        btnCinemaSwitchSeries?.setTextColor(if (!isMovies) Color.parseColor("#F4F5F7") else Color.parseColor("#9CA3AF"))
        tvVodGridHeaderTitle.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0)
        attachObsidianTopBarFocusContrast()

        val sidebarItems = buildVodSidebarCategories(section)
        vodSidebarAdapter.submitCategories(sidebarItems, selectedVodCategory)

        val spinnerLabels = sidebarItems.map { item ->
            if (item.isSpecialSection) item.categoryName else "${item.categoryName} (${item.count})"
        }
        suppressVodCategoryCallback = true
        vodCategorySpinner.adapter = createGlassCategoryAdapter(
            spinnerLabels,
            prefixLabel = if (isMovies) "Movies" else "Series"
        )
        val selPos = sidebarItems.indexOfFirst { it.categoryName == selectedVodCategory }.coerceAtLeast(0)
        vodCategorySpinner.setSelection(selPos, false)
        suppressVodCategoryCallback = false

        renderVodPosterGrid(requestFocusPosterIndex = restoreFocusIndex)

        // If connected to an Xtream account and the requested VOD catalog hasn't been fetched yet, fetch it now
        val creds = activeXtreamCreds
        if (activeSourceType == ProfileType.XTREAM && creds != null) {
            if (isMovies && vodMoviesCatalog.isEmpty()) {
                loadXtreamVodMovies(creds, forceNetworkRefresh = false)
            } else if (!isMovies && seriesCatalogGroups.isEmpty()) {
                loadXtreamSeriesCatalog(creds, forceNetworkRefresh = false)
            }
        }
    }

    private fun buildVodSidebarCategories(section: EntertainmentSection): List<VodCategorySidebarItem> {
        // Strict M3U rule: M3U-only accounts have NO VOD Movies or Series categories
        if (activeSourceType != ProfileType.XTREAM) {
            return listOf(
                VodCategorySidebarItem("FAVORITES / WATCHLIST", 0, isSpecialSection = true),
                VodCategorySidebarItem("RECENTLY ADDED", 0, isSpecialSection = true),
                VodCategorySidebarItem("CONTINUE WATCHING", 0, isSpecialSection = true)
            )
        }

        val continueEntries = if (::profileStore.isInitialized) {
            profileStore.getContinueWatchingEntries(activeAccountScope)
        } else emptyList()

        return if (section == EntertainmentSection.MOVIES) {
            val watchlistIds = if (::profileStore.isInitialized) {
                profileStore.getMovieWatchlistIds(activeAccountScope)
            } else emptySet()
            val favMovieCount = vodMoviesCatalog.count { watchlistIds.contains(it.id) || favoriteIds.contains(it.id) }
            val contMovieCount = continueEntries.count { it.contentType == ContentSourceType.XTREAM_VOD_MOVIE && vodMovieIndexById.containsKey(it.contentId) }
            val countByCat = LinkedHashMap<String, Int>(64)
            for (movie in vodMoviesCatalog) {
                if (movie.sourceType != ContentSourceType.XTREAM_VOD_MOVIE) continue
                val cat = movie.category.trim().ifBlank { "Movies" }
                countByCat[cat] = (countByCat[cat] ?: 0) + 1
            }
            val list = ArrayList<VodCategorySidebarItem>(countByCat.size + 4)
            list.add(VodCategorySidebarItem("FAVORITES / WATCHLIST", favMovieCount, isSpecialSection = true))
            list.add(VodCategorySidebarItem("RECENTLY ADDED", vodMoviesCatalog.size, isSpecialSection = true))
            list.add(VodCategorySidebarItem("CONTINUE WATCHING", contMovieCount, isSpecialSection = true))
            list.add(VodCategorySidebarItem("ALL MOVIES", vodMoviesCatalog.size, isSpecialSection = true))
            for ((catName, count) in countByCat) {
                list.add(VodCategorySidebarItem(catName, count, isSpecialSection = false))
            }
            list
        } else {
            val watchlistSeriesIds = if (::profileStore.isInitialized) {
                profileStore.getSeriesWatchlistIds(activeAccountScope)
            } else emptySet()
            val favSeriesCount = seriesCatalogGroups.count { grp ->
                watchlistSeriesIds.contains(grp.seriesKey) || watchlistSeriesIds.contains(grp.seriesId)
            }
            val activeSeriesKeys = continueEntries
                .filter { it.contentType == ContentSourceType.XTREAM_SERIES_EPISODE }
                .mapNotNull { it.seriesKey.takeIf { k -> k.isNotBlank() } }
                .toSet()
            val contSeriesCount = seriesCatalogGroups.count { it.seriesKey in activeSeriesKeys }
            val countByCat = LinkedHashMap<String, Int>(64)
            for (grp in seriesCatalogGroups) {
                val cat = grp.category.trim().ifBlank { "Series" }
                countByCat[cat] = (countByCat[cat] ?: 0) + 1
            }
            val list = ArrayList<VodCategorySidebarItem>(countByCat.size + 4)
            list.add(VodCategorySidebarItem("FAVORITES / WATCHLIST", favSeriesCount, isSpecialSection = true))
            list.add(VodCategorySidebarItem("RECENTLY ADDED", seriesCatalogGroups.size, isSpecialSection = true))
            list.add(VodCategorySidebarItem("CONTINUE WATCHING", contSeriesCount, isSpecialSection = true))
            list.add(VodCategorySidebarItem("ALL SERIES", seriesCatalogGroups.size, isSpecialSection = true))
            for ((catName, count) in countByCat) {
                list.add(VodCategorySidebarItem(catName, count, isSpecialSection = false))
            }
            list
        }
    }

    private fun renderVodPosterGrid(debounceMs: Long = 0L, requestFocusPosterIndex: Int = -1) {
        vodPosterFilterJob?.cancel()
        vodPosterFilterJob = lifecycleScope.launch {
            if (debounceMs > 0L) delay(debounceMs)
            val section = activeEntertainmentSection
            val isMovies = section == EntertainmentSection.MOVIES

            // Requirement 2A: M3U-only accounts MUST show a clean empty state in Movies and Series!
            if (activeSourceType != ProfileType.XTREAM) {
                val heading = if (isMovies) "No Movies Available" else "No Series Available"
                tvVodGridHeaderTitle.text = "$heading • M3U Live TV Active"
                tvVodEmptyState.text = "$heading\n\nMovies and Series are available when you connect an Xtream Codes account containing VOD content."
                tvVodEmptyState.visibility = View.VISIBLE
                vodEmptyHeroContainer?.visibility = View.VISIBLE
                vodSpotlightBanner?.visibility = View.GONE
                vodPosterRecycler.visibility = View.GONE
                posterGridAdapter.submitItems(emptyList())
                return@launch
            }

            val query = vodSearchQuery.trim()
            val selectedCat = selectedVodCategory
            val specialMode = vodSpecialFilterMode
            val sortOrder = activeVodSortOrder
            val scope = activeAccountScope
            val continueEntries = if (::profileStore.isInitialized) {
                profileStore.getContinueWatchingEntries(scope)
            } else emptyList()
            val continueById = continueEntries.associateBy { it.contentId }
            val movieWatchlist = if (::profileStore.isInitialized) {
                profileStore.getMovieWatchlistIds(scope)
            } else emptySet()
            val seriesWatchlist = if (::profileStore.isInitialized) {
                profileStore.getSeriesWatchlistIds(scope)
            } else emptySet()
            val favSnapshot = HashSet(favoriteIds)

            val items = withContext(Dispatchers.Default) {
                val result = ArrayList<PosterCardBindItem>(256)
                if (isMovies) {
                    val baseIndices: List<Int> = when {
                        specialMode == "CONTINUE" || selectedCat == "CONTINUE WATCHING" -> {
                            continueEntries
                                .filter { it.contentType == ContentSourceType.XTREAM_VOD_MOVIE }
                                .mapNotNull { vodMovieIndexById[it.contentId] }
                        }
                        specialMode == "FAV" || selectedCat == "FAVORITES / WATCHLIST" -> {
                            vodMoviesCatalog.indices.filter { idx ->
                                val m = vodMoviesCatalog[idx]
                                movieWatchlist.contains(m.id) || favSnapshot.contains(m.id)
                            }
                        }
                        else -> vodMoviesCatalog.indices.toList()
                    }

                    val matchedMovies = ArrayList<Pair<Int, Channel>>(baseIndices.size.coerceAtMost(1200))
                    for (idx in baseIndices) {
                        val movie = vodMoviesCatalog.getOrNull(idx) ?: continue
                        if (movie.sourceType != ContentSourceType.XTREAM_VOD_MOVIE) continue
                        val catMatches = selectedCat in setOf(
                            "ALL MOVIES", "RECENTLY ADDED", "CONTINUE WATCHING", "FAVORITES / WATCHLIST"
                        ) || movie.category.equals(selectedCat, ignoreCase = true)
                        val queryMatches = query.isEmpty() ||
                            movie.name.contains(query, ignoreCase = true) ||
                            movie.category.contains(query, ignoreCase = true)
                        val smartFilterMatches = when (vodSmartQualityFilter) {
                            "4K" -> movie.extractQualityBadge().contains("4K", ignoreCase = true)
                            "1080P" -> movie.extractQualityBadge().contains("1080", ignoreCase = true) || movie.extractQualityBadge().contains("4K", ignoreCase = true)
                            "UNWATCHED" -> !profileStore.isContentWatched(movie.id, activeAccountScope)
                            else -> true
                        }
                        if (catMatches && queryMatches && smartFilterMatches) {
                            matchedMovies.add(idx to movie)
                        }
                    }

                    val sortedMovies = when {
                        specialMode == "CONTINUE" || selectedCat == "CONTINUE WATCHING" -> matchedMovies
                        sortOrder == VodSortOrder.RECENTLY_ADDED || selectedCat == "RECENTLY ADDED" && sortOrder == VodSortOrder.RECENTLY_ADDED ->
                            matchedMovies.sortedByDescending { it.second.addedTimestamp }
                        sortOrder == VodSortOrder.NEW_TO_OLD ->
                            matchedMovies.sortedWith(
                                compareByDescending<Pair<Int, Channel>> { it.second.extractReleaseYear().toIntOrNull() ?: 0 }
                                    .thenByDescending { it.second.addedTimestamp }
                            )
                        sortOrder == VodSortOrder.OLD_TO_NEW ->
                            matchedMovies.sortedWith(
                                compareBy<Pair<Int, Channel>> { it.second.extractReleaseYear().toIntOrNull() ?: 9999 }
                                    .thenBy { it.second.addedTimestamp }
                            )
                        sortOrder == VodSortOrder.A_TO_Z ->
                            matchedMovies.sortedBy { it.second.cleanMovieDisplayTitle().lowercase(Locale.ROOT) }
                        sortOrder == VodSortOrder.Z_TO_A ->
                            matchedMovies.sortedByDescending { it.second.cleanMovieDisplayTitle().lowercase(Locale.ROOT) }
                        else -> matchedMovies
                    }

                    for ((idx, movie) in sortedMovies) {
                        val prog = continueById[movie.id]?.progressPercent() ?: 0
                        val year = movie.extractReleaseYear()
                        val qual = movie.extractQualityBadge()
                        val inWl = movieWatchlist.contains(movie.id) || favSnapshot.contains(movie.id)
                        result.add(
                            PosterCardBindItem(
                                key = movie.id,
                                title = movie.cleanMovieDisplayTitle(),
                                subtitle = if (year.isNotBlank()) "${movie.category} • $year" else movie.category,
                                posterUrl = movie.logoUrl,
                                yearBadge = year,
                                qualityBadge = qual,
                                progressPercent = prog,
                                isFavorite = inWl,
                                vodMovieIndex = idx,
                                seriesSummary = null
                            )
                        )
                        if (result.size >= 800) break
                    }
                } else {
                    val activeSeriesProgressByKey = continueEntries
                        .filter { it.contentType == ContentSourceType.XTREAM_SERIES_EPISODE && it.seriesKey.isNotBlank() }
                        .groupBy { it.seriesKey }
                    val sourceGroups: List<SeriesGroupSummary> = when {
                        specialMode == "CONTINUE" || selectedCat == "CONTINUE WATCHING" -> {
                            seriesCatalogGroups.filter { grp -> activeSeriesProgressByKey.containsKey(grp.seriesKey) }
                        }
                        specialMode == "FAV" || selectedCat == "FAVORITES / WATCHLIST" -> {
                            seriesCatalogGroups.filter { grp ->
                                seriesWatchlist.contains(grp.seriesKey) || seriesWatchlist.contains(grp.seriesId)
                            }
                        }
                        else -> seriesCatalogGroups
                    }

                    val matchedGroups = ArrayList<SeriesGroupSummary>(sourceGroups.size)
                    for (grp in sourceGroups) {
                        val catMatches = selectedCat in setOf(
                            "ALL SERIES", "RECENTLY ADDED", "CONTINUE WATCHING", "FAVORITES / WATCHLIST"
                        ) || grp.category.equals(selectedCat, ignoreCase = true)
                        val queryMatches = query.isEmpty() ||
                            grp.title.contains(query, ignoreCase = true) ||
                            grp.category.contains(query, ignoreCase = true)
                        if (catMatches && queryMatches) {
                            matchedGroups.add(grp)
                        }
                    }

                    val sortedGroups = when {
                        specialMode == "CONTINUE" || selectedCat == "CONTINUE WATCHING" -> matchedGroups
                        sortOrder == VodSortOrder.RECENTLY_ADDED ->
                            matchedGroups.sortedByDescending { it.addedTimestamp }
                        sortOrder == VodSortOrder.NEW_TO_OLD ->
                            matchedGroups.sortedWith(
                                compareByDescending<SeriesGroupSummary> { it.releaseYear.toIntOrNull() ?: 0 }
                                    .thenByDescending { it.addedTimestamp }
                            )
                        sortOrder == VodSortOrder.OLD_TO_NEW ->
                            matchedGroups.sortedWith(
                                compareBy<SeriesGroupSummary> { it.releaseYear.toIntOrNull() ?: 9999 }
                                    .thenBy { it.addedTimestamp }
                            )
                        sortOrder == VodSortOrder.A_TO_Z ->
                            matchedGroups.sortedBy { it.title.lowercase(Locale.ROOT) }
                        sortOrder == VodSortOrder.Z_TO_A ->
                            matchedGroups.sortedByDescending { it.title.lowercase(Locale.ROOT) }
                        else -> matchedGroups
                    }

                    for (grp in sortedGroups) {
                        val isFav = seriesWatchlist.contains(grp.seriesKey) || seriesWatchlist.contains(grp.seriesId)
                        val latestEpProg = activeSeriesProgressByKey[grp.seriesKey]
                            ?.maxByOrNull { it.updatedAtMs }
                            ?.progressPercent() ?: 0
                        result.add(
                            PosterCardBindItem(
                                key = "series_${grp.seriesKey}",
                                title = grp.title,
                                subtitle = if (grp.releaseYear.isNotBlank()) "${grp.category} • ${grp.releaseYear}" else grp.category,
                                posterUrl = grp.posterUrl,
                                yearBadge = grp.releaseYear,
                                qualityBadge = when {
                                    grp.seasonCount > 0 && grp.totalEpisodes > 0 -> "${grp.seasonCount}S • ${grp.totalEpisodes}E"
                                    grp.seasonCount > 0 -> "${grp.seasonCount} Seasons"
                                    else -> grp.qualityBadge.ifBlank { "SERIES" }
                                },
                                progressPercent = latestEpProg,
                                isFavorite = isFav,
                                vodMovieIndex = -1,
                                seriesSummary = grp
                            )
                        )
                        if (result.size >= 800) break
                    }
                }
                result
            }

            tvVodGridHeaderTitle.text = if (isMovies) {
                "$selectedVodCategory • MOVIES (${items.size})"
            } else {
                "$selectedVodCategory • SERIES (${items.size})"
            }
            tvActiveSectionBadge.text = if (isMovies) {
                "RAM PLAYER v23.1 • MOVIES (${vodMoviesCatalog.size})"
            } else {
                "RAM PLAYER v23.1 • SERIES (${seriesCatalogGroups.size})"
            }

            if (items.isEmpty()) {
                val emptyHeadline = if (isMovies) "No Movies Available" else "No Series Available"
                val emptyBody = when {
                    isMovies && vodMoviesCatalog.isEmpty() ->
                        "$emptyHeadline\n\nTap 'Sync VOD' to load Movies from your Xtream Codes account, or check if your provider includes VOD Movies."
                    !isMovies && seriesCatalogGroups.isEmpty() ->
                        "$emptyHeadline\n\nTap 'Sync VOD' to load Series from your Xtream Codes account, or check if your provider includes VOD Series."
                    else ->
                        "No entries found in '$selectedVodCategory'${if (query.isNotBlank()) " matching \"$query\"" else ""}."
                }
                tvVodEmptyState.text = emptyBody
                tvVodEmptyState.visibility = View.VISIBLE
                vodEmptyHeroContainer?.visibility = View.VISIBLE
                vodSpotlightBanner?.visibility = View.GONE
                vodPosterRecycler.visibility = View.GONE
                posterGridAdapter.submitItems(emptyList())
            } else {
                tvVodEmptyState.visibility = View.GONE
                vodEmptyHeroContainer?.visibility = View.GONE
                vodPosterRecycler.visibility = View.VISIBLE
                posterGridAdapter.submitItems(items)
                items.firstOrNull()?.let { updateVodSpotlightBanner(it) }
                if (requestFocusPosterIndex >= 0) {
                    val targetPos = requestFocusPosterIndex.coerceIn(0, items.lastIndex)
                    vodPosterRecycler.post {
                        vodPosterRecycler.scrollToPosition(targetPos)
                        vodPosterRecycler.post {
                            vodPosterRecycler.findViewHolderForAdapterPosition(targetPos)?.itemView?.requestFocus()
                                ?: vodPosterRecycler.requestFocus()
                        }
                    }
                }
            }
        }
    }

    private fun closeVodGridAndReturnToLiveTv() {
        vodPosterGridPanel.visibility = View.GONE
        topControlBar.visibility = View.VISIBLE
        updateSectionButtonsUi(EntertainmentSection.LIVE_TV)
        tvActiveSectionBadge.text = "RAM PLAYER v21.0 • LIVE TV (${allChannels.size})"
        if (activePlaybackMode != ActivePlaybackMode.LIVE_TV) {
            exoPlayer?.let { p ->
                p.playWhenReady = false
                p.stop()
                p.clearMediaItems()
            }
            currentPlayingStreamUrl = ""
            activePlaybackMode = ActivePlaybackMode.LIVE_TV
        }
        restoreLiveTvOnReturnFromNonLiveSection()
        playerView.requestFocus()
    }

    // =========================================================================
    // v18.1 PREMIUM MOVIE DETAILS SCREEN (Matches Reference Screenshot 25371.jpg:
    // Poster, Title (Year), Rating Stars, Release Date, Genre, Cast, Plot, Director,
    // TRAILER + PLAY Buttons, Resume Watching & Personal Watchlist)
    // =========================================================================

    private fun showMovieDetailModal(vodMovieIndex: Int, preloadedDetail: VodMovieDetailInfo? = null) {
        val movie = vodMoviesCatalog.getOrNull(vodMovieIndex) ?: return
        if (movie.sourceType != ContentSourceType.XTREAM_VOD_MOVIE) return

        activeVodMovieIndex = vodMovieIndex
        activeVodMovieItem = movie
        val creds = activeXtreamCreds

        // If `get_vod_info` metadata hasn't been fetched yet for this movie and we have Xtream credentials,
        // fetch real movie metadata (plot, cast, director, rating, genuine trailer URL) asynchronously
        if (preloadedDetail == null && creds != null) {
            lifecycleScope.launch {
                val infoRes = xtreamRepo.fetchVodMovieInfo(creds, movie)
                val resolvedDetail = infoRes.getOrElse {
                    VodMovieDetailInfo(
                        streamId = movie.id.removePrefix("vod_"),
                        title = movie.cleanMovieDisplayTitle(),
                        posterUrl = movie.logoUrl,
                        releaseDate = movie.releaseDate.ifBlank { movie.extractReleaseYear() },
                        rating = movie.rating,
                        genre = movie.category,
                        plot = movie.plot,
                        cast = movie.cast,
                        director = movie.director,
                        durationLabel = movie.durationLabel,
                        containerExtension = movie.containerExtension.ifBlank { "mp4" },
                        trailerUrl = movie.trailerUrl
                    )
                }
                activeVodMovieDetailInfo = resolvedDetail
                presentMovieDetailOverlayDialog(vodMovieIndex, movie, resolvedDetail)
            }
            return
        }

        val detail = preloadedDetail ?: VodMovieDetailInfo(
            streamId = movie.id.removePrefix("vod_"),
            title = movie.cleanMovieDisplayTitle(),
            posterUrl = movie.logoUrl,
            releaseDate = movie.releaseDate.ifBlank { movie.extractReleaseYear() },
            rating = movie.rating,
            genre = movie.category,
            plot = movie.plot,
            cast = movie.cast,
            director = movie.director,
            durationLabel = movie.durationLabel,
            containerExtension = movie.containerExtension.ifBlank { "mp4" },
            trailerUrl = movie.trailerUrl
        )
        activeVodMovieDetailInfo = detail
        presentMovieDetailOverlayDialog(vodMovieIndex, movie, detail)
    }

    // =========================================================================
    // V23.1 OBSIDIAN CINEMA DESIGN SYSTEM HELPERS (FULL-SCREEN DETAILS & SHEETS)
    // =========================================================================

    private var obsidianTopBarWired: Boolean = false

    private fun attachObsidianTopBarFocusContrast() {
        if (obsidianTopBarWired) return
        obsidianTopBarWired = true
        val navButtons = listOfNotNull(
            btnCinemaSwitchMovies,
            btnCinemaSwitchSeries,
            btnVodContinueWatching,
            btnVodFavoritesFilter,
            btnVodSortOrder,
            btnVodSmartFilter,
            btnVodRandomPick,
            btnVodFetchProvider,
            btnCloseVodGrid
        )
        for (btn in navButtons) {
            btn.setOnFocusChangeListener { v, hasFocus ->
                val b = v as? Button ?: return@setOnFocusChangeListener
                val defaultColor = when {
                    b === btnCloseVodGrid -> Color.parseColor("#E5A93B")
                    b.isSelected -> Color.parseColor("#F4F5F7")
                    else -> Color.parseColor("#D1D5DB")
                }
                b.setTextColor(if (hasFocus) Color.parseColor("#090A0D") else defaultColor)
                if (!activePerformanceMode.reducedAnimations) {
                    val s = if (hasFocus) 1.03f else 1.0f
                    b.animate().scaleX(s).scaleY(s).setDuration(90L).start()
                }
            }
        }
    }

    private fun applyRoundedOutline(view: View, radiusDp: Int) {
        val radiusPx = dp(radiusDp).toFloat()
        view.outlineProvider = object : android.view.ViewOutlineProvider() {
            override fun getOutline(v: View, outline: android.graphics.Outline) {
                outline.setRoundRect(0, 0, v.width, v.height, radiusPx)
            }
        }
        view.clipToOutline = true
    }

    private fun createObsidianPrimaryButton(label: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 13.5f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#090A0D"))
            setBackgroundResource(R.drawable.bg_obsidian_primary_cta)
            backgroundTintList = null
            isFocusable = true
            setPadding(dp(22), 0, dp(22), 0)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                dp(44)
            ).apply { marginEnd = dp(10) }
            setOnFocusChangeListener { v, hasFocus ->
                if (!activePerformanceMode.reducedAnimations) {
                    val s = if (hasFocus) 1.04f else 1.0f
                    v.animate().scaleX(s).scaleY(s).setDuration(90L).start()
                }
            }
            setOnClickListener { onClick() }
        }
    }

    private fun createObsidianSecondaryButton(
        label: String,
        isSelectedState: Boolean = false,
        heightDp: Int = 38,
        onClick: () -> Unit
    ): Button {
        val restColor = if (isSelectedState) Color.parseColor("#E5A93B") else Color.parseColor("#E5E7EB")
        return Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            isSelected = isSelectedState
            setTextColor(restColor)
            setBackgroundResource(R.drawable.bg_obsidian_secondary_btn)
            backgroundTintList = null
            isFocusable = true
            setPadding(dp(15), 0, dp(15), 0)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                dp(heightDp)
            ).apply { marginEnd = dp(8) }
            setOnFocusChangeListener { v, hasFocus ->
                (v as? Button)?.setTextColor(if (hasFocus) Color.parseColor("#090A0D") else restColor)
                if (!activePerformanceMode.reducedAnimations) {
                    val s = if (hasFocus) 1.03f else 1.0f
                    v.animate().scaleX(s).scaleY(s).setDuration(90L).start()
                }
            }
            setOnClickListener { onClick() }
        }
    }

    private fun presentObsidianFullscreenDialog(rootView: View): AlertDialog {
        val dlg = AlertDialog.Builder(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
            .setView(rootView)
            .setCancelable(true)
            .create()
        dlg.show()
        dlg.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.parseColor("#FF090A0D")))
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                attributes = attributes.apply {
                    layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                }
            }
        }
        return dlg
    }

    private fun presentObsidianSheetDialog(
        title: String,
        subtitle: String,
        badgeText: String,
        options: List<GlassModalOption>,
        closeLabel: String = "Back"
    ): AlertDialog {
        var dlgRef: AlertDialog? = null
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_obsidian_sheet_panel)
            setPadding(dp(22), dp(20), dp(22), dp(18))
        }

        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        titleCol.addView(TextView(this).apply {
            text = title
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#F4F5F7"))
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        })
        if (subtitle.isNotBlank()) {
            titleCol.addView(TextView(this).apply {
                text = subtitle
                textSize = 12f
                setTextColor(Color.parseColor("#9CA3AF"))
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(2) }
            })
        }
        headerRow.addView(titleCol)
        if (badgeText.isNotBlank()) {
            headerRow.addView(TextView(this).apply {
                text = badgeText
                textSize = 10.5f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#E5A93B"))
                setBackgroundResource(R.drawable.bg_obsidian_badge_gold)
                setPadding(dp(10), dp(4), dp(10), dp(4))
            })
        }
        root.addView(headerRow)

        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(14) }
        }
        val listContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        var firstFocus: View? = null

        for (opt in options) {
            val tvOptTitle = TextView(this).apply {
                text = opt.title
                textSize = 13.5f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#F4F5F7"))
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }
            val tvOptSub = if (opt.subtitle.isNotBlank()) {
                TextView(this).apply {
                    text = opt.subtitle
                    textSize = 11.5f
                    setTextColor(Color.parseColor("#9CA3AF"))
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply { topMargin = dp(2) }
                }
            } else null
            val tvOptBadge = if (opt.badgeText.isNotBlank()) {
                TextView(this).apply {
                    text = opt.badgeText
                    textSize = 10.5f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(if (opt.isHighlighted) Color.parseColor("#E5A93B") else Color.parseColor("#D1D5DB"))
                    setPadding(dp(10), dp(3), dp(10), dp(3))
                }
            } else null

            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                isFocusable = true
                isClickable = true
                isSelected = opt.isHighlighted
                setBackgroundResource(R.drawable.bg_obsidian_nav_btn)
                setPadding(dp(14), dp(11), dp(14), dp(11))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(6) }
                setOnFocusChangeListener { _, hasFocus ->
                    tvOptTitle.setTextColor(if (hasFocus) Color.parseColor("#090A0D") else Color.parseColor("#F4F5F7"))
                    tvOptSub?.setTextColor(if (hasFocus) Color.parseColor("#374151") else Color.parseColor("#9CA3AF"))
                    tvOptBadge?.setTextColor(
                        if (hasFocus) Color.parseColor("#090A0D")
                        else if (opt.isHighlighted) Color.parseColor("#E5A93B")
                        else Color.parseColor("#D1D5DB")
                    )
                }
                setOnClickListener {
                    dlgRef?.dismiss()
                    opt.onClick()
                }
            }

            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            col.addView(tvOptTitle)
            if (tvOptSub != null) col.addView(tvOptSub)
            row.addView(col)
            if (tvOptBadge != null) row.addView(tvOptBadge)

            if (firstFocus == null || opt.isHighlighted) firstFocus = row
            listContainer.addView(row)
        }
        scroll.addView(listContainer)
        root.addView(scroll)

        val maxH = (resources.displayMetrics.heightPixels * 0.52f).toInt().coerceAtLeast(dp(180))
        scroll.post {
            if (scroll.height > maxH) {
                scroll.layoutParams = (scroll.layoutParams as LinearLayout.LayoutParams).apply { height = maxH }
            }
        }

        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(12) }
        }
        footer.addView(createObsidianSecondaryButton(closeLabel) { dlgRef?.dismiss() }.apply {
            (layoutParams as LinearLayout.LayoutParams).marginEnd = 0
        })
        root.addView(footer)

        val dlg = AlertDialog.Builder(this, R.style.Theme_StreamX_GlassDialog)
            .setView(root)
            .setCancelable(true)
            .create()
        dlg.show()
        dlg.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(
                dp(560).coerceAtMost((resources.displayMetrics.widthPixels * 0.86f).toInt()),
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        dlgRef = dlg
        firstFocus?.post { firstFocus?.requestFocus() }
        return dlg
    }

    // =========================================================================
    // V23.1 FULL-SCREEN CINEMATIC MOVIE DETAILS (OBSIDIAN CINEMA REBIRTH)
    // =========================================================================

    private fun presentMovieDetailOverlayDialog(
        vodMovieIndex: Int,
        movie: Channel,
        detail: VodMovieDetailInfo
    ) {
        var dialogRef: AlertDialog? = null
        val savedProg = if (::profileStore.isInitialized) {
            profileStore.getPlaybackProgress(movie.id, activeAccountScope)
        } else null
        val isWatchlisted = if (::profileStore.isInitialized) {
            profileStore.isMovieInWatchlist(movie.id, activeAccountScope)
        } else false
        val isMovieWatched = if (::profileStore.isInitialized) {
            profileStore.isContentWatched(movie.id, activeAccountScope)
        } else false

        val rootFrame = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#FF090A0D"))
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        // Full-bleed subtle backdrop artwork behind dark obsidian vignette (when genuinely available)
        val backdropCandidate = detail.backdropUrl.ifBlank { detail.posterUrl }
        if (backdropCandidate.isNotBlank()) {
            val ivBackdrop = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                alpha = 0.24f
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            }
            Glide.with(this)
                .load(backdropCandidate)
                .apply(currentPosterRequestOptions())
                .into(ivBackdrop)
            rootFrame.addView(ivBackdrop)
        }

        val scrim = View(this).apply {
            setBackgroundResource(R.drawable.bg_obsidian_detail_scrim)
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        rootFrame.addView(scrim)

        val contentScroll = ScrollView(this).apply {
            isFillViewport = true
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        val stage = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(44), dp(32), dp(44), dp(32))
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        // Left: Crisp 2:3 Cinema Poster
        val ivPoster = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundResource(R.drawable.bg_obsidian_poster_frame)
            layoutParams = LinearLayout.LayoutParams(dp(186), dp(278)).apply {
                marginEnd = dp(34)
            }
        }
        applyRoundedOutline(ivPoster, 10)
        if (detail.posterUrl.isNotBlank()) {
            Glide.with(this)
                .load(detail.posterUrl)
                .apply(currentPosterRequestOptions())
                .into(ivPoster)
        } else {
            ivPoster.scaleType = ImageView.ScaleType.CENTER_INSIDE
            ivPoster.setImageResource(R.drawable.ic_3d_movies)
        }
        stage.addView(ivPoster)

        // Right: Editorial Details Column
        val metaCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        val yearStr = movie.extractReleaseYear().ifBlank {
            detail.releaseDate.take(4).takeIf { it.length == 4 && it.all { c -> c.isDigit() } }.orEmpty()
        }
        val eyebrowParts = listOfNotNull(
            detail.genre.ifBlank { movie.category }.takeIf { it.isNotBlank() }?.uppercase(Locale.ROOT),
            yearStr.takeIf { it.isNotBlank() },
            detail.durationLabel.takeIf { it.isNotBlank() },
            detail.containerExtension.uppercase(Locale.ROOT).takeIf { it.isNotBlank() }
        ).joinToString("  •  ")

        if (eyebrowParts.isNotBlank()) {
            metaCol.addView(TextView(this).apply {
                text = eyebrowParts
                textSize = 11.5f
                letterSpacing = 0.08f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#E5A93B"))
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            })
        }

        metaCol.addView(TextView(this).apply {
            text = detail.title
            textSize = 28f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#F4F5F7"))
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(6) }
        })

        // Genuine metadata badges row (Real rating only, release date, watched status)
        val badgeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8) }
        }
        if (detail.rating.isNotBlank()) {
            badgeRow.addView(TextView(this).apply {
                text = "★ ${detail.rating}"
                textSize = 12f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#E5A93B"))
                setBackgroundResource(R.drawable.bg_obsidian_badge_gold)
                setPadding(dp(10), dp(3), dp(10), dp(3))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = dp(8) }
            })
        }
        if (detail.releaseDate.isNotBlank() && detail.releaseDate != yearStr) {
            badgeRow.addView(TextView(this).apply {
                text = detail.releaseDate
                textSize = 11.5f
                setTextColor(Color.parseColor("#9CA3AF"))
                setBackgroundResource(R.drawable.bg_obsidian_badge_dark)
                setPadding(dp(10), dp(3), dp(10), dp(3))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = dp(8) }
            })
        }
        if (isMovieWatched) {
            badgeRow.addView(TextView(this).apply {
                text = "WATCHED"
                textSize = 10.5f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#34D399"))
                setBackgroundResource(R.drawable.bg_obsidian_badge_dark)
                setPadding(dp(10), dp(3), dp(10), dp(3))
            })
        }
        if (badgeRow.childCount > 0) metaCol.addView(badgeRow)

        if (detail.plot.isNotBlank()) {
            metaCol.addView(TextView(this).apply {
                text = detail.plot
                textSize = 13.5f
                setLineSpacing(dp(3).toFloat(), 1.0f)
                setTextColor(Color.parseColor("#D1D5DB"))
                maxLines = 4
                ellipsize = TextUtils.TruncateAt.END
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(12) }
            })
        }

        if (detail.director.isNotBlank()) {
            metaCol.addView(TextView(this).apply {
                text = "Director:  ${detail.director}"
                textSize = 12f
                setTextColor(Color.parseColor("#9CA3AF"))
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(10) }
            })
        }

        if (detail.cast.isNotBlank()) {
            metaCol.addView(TextView(this).apply {
                text = "Cast:  ${detail.cast}"
                textSize = 12f
                setTextColor(Color.parseColor("#9CA3AF"))
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(4) }
            })
        }

        // Primary Action Row (Prominent Play / Resume + Optional Restart & Genuine Trailer)
        val primaryRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(22) }
        }

        val hasResumable = savedProg != null && savedProg.isResumable()
        val btnPlayMovie = createObsidianPrimaryButton(
            if (hasResumable) "▶  Resume (${savedProg!!.progressPercent()}%)" else "▶  Play Movie"
        ) {
            dialogRef?.dismiss()
            startFullScreenVodMoviePlayback(
                vodIndex = vodMovieIndex,
                movie = movie,
                detail = detail,
                resumePositionMs = if (hasResumable) savedProg!!.positionMs else 0L
            )
        }
        primaryRow.addView(btnPlayMovie)

        if (hasResumable) {
            primaryRow.addView(createObsidianSecondaryButton("Start from Beginning", heightDp = 44) {
                dialogRef?.dismiss()
                profileStore.clearPlaybackProgress(movie.id, activeAccountScope)
                startFullScreenVodMoviePlayback(
                    vodIndex = vodMovieIndex,
                    movie = movie,
                    detail = detail,
                    resumePositionMs = 0L
                )
            })
        }

        if (detail.hasGenuineTrailer()) {
            primaryRow.addView(createObsidianSecondaryButton("Watch Trailer", heightDp = 44) {
                dialogRef?.dismiss()
                launchGenuineMovieTrailer(detail)
            })
        }
        metaCol.addView(primaryRow)

        // Secondary Actions Row (Clean, Visually Smaller & Organized)
        val secondaryScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(12) }
        }
        val secondaryRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        secondaryRow.addView(createObsidianSecondaryButton(
            label = if (isWatchlisted) "★ In Watchlist" else "+ Watchlist",
            isSelectedState = isWatchlisted
        ) {
            val nowAdded = profileStore.toggleMovieWatchlist(movie.id, movie.sourceType, activeAccountScope)
            Toast.makeText(
                this,
                if (nowAdded) "Added '${detail.title}' to Watchlist" else "Removed from Watchlist",
                Toast.LENGTH_SHORT
            ).show()
            dialogRef?.dismiss()
            if (vodPosterGridPanel.visibility == View.VISIBLE) {
                val sidebarItems = buildVodSidebarCategories(EntertainmentSection.MOVIES)
                vodSidebarAdapter.submitCategories(sidebarItems, selectedVodCategory)
                renderVodPosterGrid()
            }
            presentMovieDetailOverlayDialog(vodMovieIndex, movie, detail)
        })

        secondaryRow.addView(createObsidianSecondaryButton(
            label = if (isMovieWatched) "✓ Watched" else "Mark Watched",
            isSelectedState = isMovieWatched
        ) {
            if (isMovieWatched) {
                profileStore.markContentUnwatched(movie.id, activeAccountScope)
                Toast.makeText(this, "Marked '${detail.title}' as Unwatched", Toast.LENGTH_SHORT).show()
            } else {
                profileStore.markContentWatched(movie.id, activeAccountScope)
                Toast.makeText(this, "Marked '${detail.title}' as Watched", Toast.LENGTH_SHORT).show()
            }
            dialogRef?.dismiss()
            if (vodPosterGridPanel.visibility == View.VISIBLE) renderVodPosterGrid()
            presentMovieDetailOverlayDialog(vodMovieIndex, movie, detail)
        })

        secondaryRow.addView(createObsidianSecondaryButton("Similar Movies") {
            dialogRef?.dismiss()
            showSimilarMoviesModal(movie, detail)
        })

        secondaryRow.addView(createObsidianSecondaryButton("Back") {
            dialogRef?.dismiss()
        })

        secondaryScroll.addView(secondaryRow)
        metaCol.addView(secondaryScroll)

        stage.addView(metaCol)
        contentScroll.addView(stage)
        rootFrame.addView(contentScroll)

        dialogRef = presentObsidianFullscreenDialog(rootFrame)
        btnPlayMovie.post { btnPlayMovie.requestFocus() }
    }

    private fun launchGenuineMovieTrailer(detail: VodMovieDetailInfo) {
        val rawUrl = detail.trailerUrl.trim()
        if (rawUrl.isEmpty()) {
            Toast.makeText(this, "Trailer unavailable", Toast.LENGTH_SHORT).show()
            return
        }
        val lower = rawUrl.lowercase(Locale.ROOT)
        if (lower.contains("youtube.com/") || lower.contains("youtu.be/")) {
            runCatching {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(rawUrl)))
            }.onFailure {
                Toast.makeText(this, "No YouTube app available to open trailer", Toast.LENGTH_LONG).show()
            }
            return
        }
        vodPosterGridPanel.visibility = View.GONE
        leftChannelDrawer.visibility = View.GONE
        activePlaybackMode = ActivePlaybackMode.VOD_TRAILER
        currentPlayingSeriesKey = ""
        currentPlayingSeasonNum = 0
        currentPlayingEpisodeNum = 0
        pendingResumeSeekPositionMs = 0L
        tvChannelNumber.text = "TRL"
        tvChannelName.text = "Trailer: ${detail.title}"
        tvChannelCategory.text = "${detail.genre} • Trailer"
        tvEpgNow.text = "Press BACK to return to ${detail.title} Details"
        playSpecificStreamUrl(rawUrl, forceReload = true)
        showZappingOsd()
    }

    private fun updateVodSpotlightBanner(item: PosterCardBindItem) {
        val banner = vodSpotlightBanner ?: return
        banner.visibility = View.VISIBLE
        tvVodSpotlightTitle?.text = item.title
        val metaParts = listOfNotNull(
            item.subtitle.takeIf { it.isNotBlank() },
            item.qualityBadge.takeIf { it.isNotBlank() },
            if (item.progressPercent > 0) "Resume ${item.progressPercent}%" else null,
            if (item.isFavorite) "★ Watchlist" else null
        ).joinToString("  •  ")
        tvVodSpotlightMeta?.text = metaParts.ifBlank { "RAM CINEMA" }
        tvVodSpotlightHint?.text = if (item.seriesSummary != null) "OK  •  Seasons & Episodes" else "OK  •  Details & Play"
        ivVodSpotlightPoster?.let { iv ->
            applyRoundedOutline(iv, 8)
            val fallbackIcon = if (item.seriesSummary != null) R.drawable.ic_3d_series else R.drawable.ic_3d_movies
            if (item.posterUrl.isNotBlank()) {
                iv.scaleType = ImageView.ScaleType.CENTER_CROP
                Glide.with(this)
                    .load(item.posterUrl)
                    .apply(currentPosterRequestOptions().placeholder(fallbackIcon).error(fallbackIcon))
                    .into(iv)
            } else {
                iv.scaleType = ImageView.ScaleType.CENTER_INSIDE
                iv.setImageResource(fallbackIcon)
            }
        }
    }

    private fun startFullScreenVodMoviePlayback(
        vodIndex: Int,
        movie: Channel,
        detail: VodMovieDetailInfo,
        resumePositionMs: Long
    ) {
        suspendLiveTvForNonLiveSection("Movies")
        activeVodMovieIndex = vodIndex
        activeVodMovieItem = movie
        activeVodMovieDetailInfo = detail
        cancelOkHoldDelete()

        val payload = VodLaunchPayload(
            contentType = VodContentType.MOVIE,
            contentId = movie.id,
            streamUrl = movie.streamUrl,
            title = detail.title.ifBlank { movie.cleanMovieDisplayTitle() },
            subtitleLine = listOfNotNull(
                detail.genre.ifBlank { movie.category }.takeIf { it.isNotBlank() },
                movie.extractReleaseYear().takeIf { it.isNotBlank() },
                detail.durationLabel.takeIf { it.isNotBlank() },
                detail.containerExtension.uppercase(Locale.ROOT).takeIf { it.isNotBlank() }
            ).joinToString(" • "),
            category = detail.genre.ifBlank { movie.category },
            posterUrl = detail.posterUrl.ifBlank { movie.logoUrl },
            backdropUrl = detail.backdropUrl.ifBlank { detail.posterUrl.ifBlank { movie.logoUrl } },
            rating = detail.rating.ifBlank { movie.rating },
            releaseYear = movie.extractReleaseYear(),
            durationLabel = detail.durationLabel.ifBlank { movie.durationLabel },
            containerExtension = detail.containerExtension.ifBlank { movie.containerExtension },
            resumePositionMs = resumePositionMs.coerceAtLeast(0L),
            accountScope = activeAccountScope
        )
        dedicatedVodPlayerLauncher.launch(VodPlayerLauncher.createIntent(this, payload))
    }

    private fun showSimilarMoviesModal(movie: Channel, detail: VodMovieDetailInfo) {
        val similarIndices = vodMoviesCatalog.indices
            .filter { idx ->
                val cand = vodMoviesCatalog[idx]
                cand.id != movie.id && cand.category.equals(movie.category, ignoreCase = true)
            }
            .take(12)

        if (similarIndices.isEmpty()) {
            Toast.makeText(this, "No other movies found in '${movie.category}'", Toast.LENGTH_SHORT).show()
            presentMovieDetailOverlayDialog(activeVodMovieIndex, movie, detail)
            return
        }

        val options = similarIndices.map { idx ->
            val cand = vodMoviesCatalog[idx]
            val yr = cand.extractReleaseYear()
            GlassModalOption(
                iconRes = R.drawable.ic_3d_movies,
                title = cand.cleanMovieDisplayTitle(),
                subtitle = "${cand.category}${if (yr.isNotBlank()) " • $yr" else ""}",
                badgeText = cand.extractQualityBadge().ifBlank { "MOVIE" }
            ) {
                showMovieDetailModal(idx)
            }
        }

        presentObsidianSheetDialog(
            title = "Similar Movies",
            subtitle = "More in ${movie.category} like ${detail.title}",
            badgeText = "${options.size} TITLES",
            options = options,
            closeLabel = "Back"
        )
    }

    // =========================================================================
    // V23.1 FULL-SCREEN CINEMATIC SERIES DETAILS, SEASONS & EPISODES
    // =========================================================================

    private fun showSeriesDetailModal(group: SeriesGroupSummary, selectedSeasonNumber: Int? = null) {
        val creds = activeXtreamCreds
        val cachedSeasons = loadedSeriesEpisodesCache[group.seriesKey]
        val resolvedGroup = if (group.seasons.isEmpty() && cachedSeasons != null) {
            group.copy(seasons = cachedSeasons)
        } else {
            group
        }

        if (resolvedGroup.seasons.isEmpty() && creds != null) {
            lifecycleScope.launch {
                Toast.makeText(this@PlayerActivity, "Loading seasons & episodes for ${resolvedGroup.title}...", Toast.LENGTH_SHORT).show()
                val res = xtreamRepo.fetchSeriesEpisodes(
                    creds = creds,
                    seriesId = resolvedGroup.seriesId,
                    seriesTitle = resolvedGroup.title,
                    seriesCategory = resolvedGroup.category,
                    fallbackCover = resolvedGroup.posterUrl
                )
                res.onSuccess { fetchedEps ->
                    if (fetchedEps.isNotEmpty()) {
                        val seasonMap = LinkedHashMap<Int, List<SeriesEpisodeItem>>()
                        fetchedEps.groupBy { it.seasonNumber }.toSortedMap().forEach { (sNum, list) ->
                            seasonMap[sNum] = list.sortedBy { it.episodeNumber }
                        }
                        loadedSeriesEpisodesCache[resolvedGroup.seriesKey] = seasonMap
                        val enrichedGroup = resolvedGroup.copy(seasons = seasonMap)
                        activeSeriesGroup = enrichedGroup
                        presentSeriesDetailOverlayDialog(enrichedGroup, selectedSeasonNumber ?: seasonMap.keys.firstOrNull() ?: 1)
                    } else {
                        Toast.makeText(this@PlayerActivity, "No episodes available from provider for ${resolvedGroup.title}", Toast.LENGTH_LONG).show()
                    }
                }.onFailure { err ->
                    Toast.makeText(this@PlayerActivity, "Series info error: ${err.message}", Toast.LENGTH_LONG).show()
                }
            }
            return
        }

        activeSeriesGroup = resolvedGroup
        val firstSeason = selectedSeasonNumber ?: resolvedGroup.seasons.keys.sorted().firstOrNull() ?: 1
        presentSeriesDetailOverlayDialog(resolvedGroup, firstSeason)
    }

    private fun presentSeriesDetailOverlayDialog(
        group: SeriesGroupSummary,
        selectedSeasonNumber: Int
    ) {
        var dialogRef: AlertDialog? = null
        val availableSeasons = group.seasons.keys.sorted()
        val activeSeason = if (selectedSeasonNumber in group.seasons) {
            selectedSeasonNumber
        } else {
            availableSeasons.firstOrNull() ?: 1
        }
        activeSeriesSeasonNum = activeSeason
        val episodesInSeason = group.seasons[activeSeason].orEmpty()
        val allEpisodesFlat = availableSeasons.flatMap { group.seasons[it].orEmpty() }

        val continueEntries = if (::profileStore.isInitialized) {
            profileStore.getContinueWatchingEntries(activeAccountScope)
        } else emptyList()
        val continueById = continueEntries.associateBy { it.contentId }
        val isWatchlisted = if (::profileStore.isInitialized) {
            profileStore.isSeriesInWatchlist(group.seriesKey, activeAccountScope)
        } else false
        val watchedSet = if (::profileStore.isInitialized) {
            profileStore.getWatchedContentIds(activeAccountScope)
        } else emptySet()

        val lastWatchedEp = allEpisodesFlat
            .mapNotNull { ep -> continueById[ep.channel.id]?.let { ep to it } }
            .maxByOrNull { it.second.updatedAtMs }
        val firstEpOfSeason = episodesInSeason.firstOrNull()

        val rootFrame = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#FF090A0D"))
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        if (group.posterUrl.isNotBlank()) {
            val ivBackdrop = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                alpha = 0.18f
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            }
            Glide.with(this)
                .load(group.posterUrl)
                .apply(currentPosterRequestOptions())
                .into(ivBackdrop)
            rootFrame.addView(ivBackdrop)
        }

        rootFrame.addView(View(this).apply {
            setBackgroundResource(R.drawable.bg_obsidian_detail_scrim)
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        })

        val mainCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(34), dp(22), dp(34), dp(18))
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        // Top Series Editorial Header
        val topHeaderRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        val ivPoster = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundResource(R.drawable.bg_obsidian_poster_frame)
            layoutParams = LinearLayout.LayoutParams(dp(106), dp(156)).apply {
                marginEnd = dp(22)
            }
        }
        applyRoundedOutline(ivPoster, 9)
        if (group.posterUrl.isNotBlank()) {
            Glide.with(this)
                .load(group.posterUrl)
                .apply(currentPosterRequestOptions().placeholder(R.drawable.ic_3d_series).error(R.drawable.ic_3d_series))
                .into(ivPoster)
        } else {
            ivPoster.scaleType = ImageView.ScaleType.CENTER_INSIDE
            ivPoster.setImageResource(R.drawable.ic_3d_series)
        }
        topHeaderRow.addView(ivPoster)

        val metaCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        val eyebrow = listOfNotNull(
            group.genre.ifBlank { group.category }.takeIf { it.isNotBlank() }?.uppercase(Locale.ROOT),
            (group.releaseYear.ifBlank { group.releaseDate.take(4) }).takeIf { it.isNotBlank() },
            "${group.seasonCount} Seasons • ${group.totalEpisodes} Episodes",
            group.rating.takeIf { it.isNotBlank() }?.let { "★ $it" }
        ).joinToString("  •  ")

        metaCol.addView(TextView(this).apply {
            text = eyebrow
            textSize = 11f
            letterSpacing = 0.06f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#E5A93B"))
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        })

        metaCol.addView(TextView(this).apply {
            text = group.title
            textSize = 23f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#F4F5F7"))
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(4) }
        })

        if (group.plot.isNotBlank()) {
            metaCol.addView(TextView(this).apply {
                text = group.plot
                textSize = 12.5f
                setTextColor(Color.parseColor("#D1D5DB"))
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(5) }
            })
        }

        val creditsLine = listOfNotNull(
            group.director.takeIf { it.isNotBlank() }?.let { "Director: $it" },
            group.cast.takeIf { it.isNotBlank() }?.let { "Cast: $it" }
        ).joinToString("   •   ")
        if (creditsLine.isNotBlank()) {
            metaCol.addView(TextView(this).apply {
                text = creditsLine
                textSize = 11.5f
                setTextColor(Color.parseColor("#9CA3AF"))
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(4) }
            })
        }

        // Primary Series Action Strip
        val actionsScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(12) }
        }
        val actionsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        if (lastWatchedEp != null) {
            val (epItem, progEntry) = lastWatchedEp
            actionsRow.addView(createObsidianPrimaryButton(
                "▶  Resume S${epItem.seasonNumber}E${epItem.episodeNumber} (${progEntry.progressPercent()}%)"
            ) {
                dialogRef?.dismiss()
                playSeriesEpisodeItem(group, epItem, resumePositionMs = progEntry.positionMs)
            })
        } else if (firstEpOfSeason != null) {
            actionsRow.addView(createObsidianPrimaryButton(
                "▶  Play S${firstEpOfSeason.seasonNumber}E${firstEpOfSeason.episodeNumber}"
            ) {
                dialogRef?.dismiss()
                playSeriesEpisodeItem(group, firstEpOfSeason, resumePositionMs = 0L)
            })
        }

        actionsRow.addView(createObsidianSecondaryButton(
            label = if (isWatchlisted) "★ Watchlisted" else "+ Watchlist",
            isSelectedState = isWatchlisted
        ) {
            val added = profileStore.toggleSeriesWatchlist(group.seriesKey, ContentSourceType.XTREAM_SERIES, activeAccountScope)
            Toast.makeText(
                this,
                if (added) "Added '${group.title}' to Watchlist" else "Removed from Watchlist",
                Toast.LENGTH_SHORT
            ).show()
            dialogRef?.dismiss()
            if (vodPosterGridPanel.visibility == View.VISIBLE) {
                val sidebarItems = buildVodSidebarCategories(EntertainmentSection.SERIES)
                vodSidebarAdapter.submitCategories(sidebarItems, selectedVodCategory)
                renderVodPosterGrid()
            }
            presentSeriesDetailOverlayDialog(group, activeSeason)
        })

        val watchedInSeasonCount = episodesInSeason.count { watchedSet.contains(it.channel.id) }
        val allSeasonWatched = episodesInSeason.isNotEmpty() && watchedInSeasonCount == episodesInSeason.size
        actionsRow.addView(createObsidianSecondaryButton(
            label = if (allSeasonWatched) "✓ S$activeSeason Watched" else "Mark S$activeSeason Watched",
            isSelectedState = allSeasonWatched
        ) {
            val epIds = episodesInSeason.map { it.channel.id }
            if (allSeasonWatched) {
                profileStore.markSeasonUnwatched(epIds, activeAccountScope)
                Toast.makeText(this, "Marked Season $activeSeason as Unwatched", Toast.LENGTH_SHORT).show()
            } else {
                profileStore.markSeasonWatched(epIds, activeAccountScope)
                Toast.makeText(this, "Marked Season $activeSeason (${epIds.size} episodes) as Watched", Toast.LENGTH_SHORT).show()
            }
            dialogRef?.dismiss()
            presentSeriesDetailOverlayDialog(group, activeSeason)
        })

        actionsRow.addView(createObsidianSecondaryButton(
            label = if (filterUnwatchedEpisodesOnly) "Unwatched Only" else "All Episodes",
            isSelectedState = filterUnwatchedEpisodesOnly
        ) {
            filterUnwatchedEpisodesOnly = !filterUnwatchedEpisodesOnly
            dialogRef?.dismiss()
            presentSeriesDetailOverlayDialog(group, activeSeason)
        })

        actionsRow.addView(createObsidianSecondaryButton("Back") {
            dialogRef?.dismiss()
        })

        actionsScroll.addView(actionsRow)
        metaCol.addView(actionsScroll)
        topHeaderRow.addView(metaCol)
        mainCol.addView(topHeaderRow)

        // Horizontal Season Selector Strip (Clean Matte Tabs, Smooth D-pad Left/Right)
        val seasonScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(16)
                bottomMargin = dp(12)
            }
        }
        val seasonBarRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        for (sNum in availableSeasons) {
            val isCurrentSeason = sNum == activeSeason
            val epCount = group.seasons[sNum]?.size ?: 0
            val seasonTab = createObsidianSecondaryButton(
                label = "Season $sNum ($epCount)",
                isSelectedState = isCurrentSeason,
                heightDp = 36
            ) {
                if (sNum != activeSeason) {
                    dialogRef?.dismiss()
                    presentSeriesDetailOverlayDialog(group, sNum)
                }
            }
            seasonBarRow.addView(seasonTab)
        }
        seasonScroll.addView(seasonBarRow)
        mainCol.addView(seasonScroll)

        // Spacious Scrollable Episode List (Takes full remaining height of TV screen)
        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        }
        val epContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(2), 0, dp(16))
        }

        var firstEpisodeFocusView: View? = null
        val targetEpisodeIdToFocus = activeSeriesEpisodeItem?.channel?.id
        val visibleEpisodes = if (filterUnwatchedEpisodesOnly) {
            episodesInSeason.filterNot { watchedSet.contains(it.channel.id) }.ifEmpty { episodesInSeason }
        } else {
            episodesInSeason
        }

        for (ep in visibleEpisodes) {
            val epProg = continueById[ep.channel.id]
            val isEpWatched = watchedSet.contains(ep.channel.id)
            val isHighlighted = (targetEpisodeIdToFocus != null && ep.channel.id == targetEpisodeIdToFocus) || epProg != null

            val epRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                isFocusable = true
                isClickable = true
                isSelected = isHighlighted
                setBackgroundResource(R.drawable.bg_obsidian_episode_row)
                setPadding(dp(12), dp(10), dp(16), dp(10))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(8) }
                setOnFocusChangeListener { v, hasFocus ->
                    if (!activePerformanceMode.reducedAnimations) {
                        val s = if (hasFocus) 1.012f else 1.0f
                        v.animate().scaleX(s).scaleY(s).setDuration(90L).start()
                    }
                }
                setOnClickListener {
                    dialogRef?.dismiss()
                    if (epProg != null && epProg.isResumable()) {
                        showEpisodeResumeOrRestartChoice(group, ep, epProg)
                    } else {
                        playSeriesEpisodeItem(group, ep, resumePositionMs = 0L)
                    }
                }
                setOnLongClickListener {
                    dialogRef?.dismiss()
                    showEpisodeResumeOrRestartChoice(group, ep, epProg)
                    true
                }
            }

            // 16:9 Episode Thumbnail with optional bottom gold progress bar
            val thumbFrame = FrameLayout(this).apply {
                setBackgroundResource(R.drawable.bg_obsidian_poster_frame)
                layoutParams = LinearLayout.LayoutParams(dp(124), dp(70)).apply {
                    marginEnd = dp(14)
                }
            }
            applyRoundedOutline(thumbFrame, 7)

            val ivThumb = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            }
            val epThumbUrl = ep.channel.logoUrl.ifBlank { group.posterUrl }
            if (epThumbUrl.isNotBlank()) {
                Glide.with(this)
                    .load(epThumbUrl)
                    .apply(currentPosterRequestOptions().placeholder(R.drawable.ic_3d_series).error(R.drawable.ic_3d_series))
                    .into(ivThumb)
            } else {
                ivThumb.scaleType = ImageView.ScaleType.CENTER_INSIDE
                ivThumb.setImageResource(R.drawable.ic_3d_series)
            }
            thumbFrame.addView(ivThumb)

            if (epProg != null && epProg.progressPercent() > 0) {
                val epBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                    max = 100
                    progress = epProg.progressPercent()
                    progressTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#E5A93B"))
                    progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#66000000"))
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        dp(3),
                        Gravity.BOTTOM
                    )
                }
                thumbFrame.addView(epBar)
            }
            epRow.addView(thumbFrame)

            // Episode Text Column
            val textCol = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginEnd = dp(12)
                }
            }
            val sPad = ep.seasonNumber.toString().padStart(2, '0')
            val ePad = ep.episodeNumber.toString().padStart(2, '0')
            val cleanEpTitle = if (ep.episodeTitle.contains("S$sPad", ignoreCase = true)) {
                ep.episodeTitle
            } else {
                "S${sPad}E${ePad}  •  ${ep.episodeTitle}"
            }

            textCol.addView(TextView(this).apply {
                text = cleanEpTitle
                textSize = 14f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#F4F5F7"))
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            })

            val epMeta = listOfNotNull(
                "Season ${ep.seasonNumber} • Episode ${ep.episodeNumber}",
                ep.durationLabel.takeIf { it.isNotBlank() },
                if (epProg != null) "Resume ${epProg.progressPercent()}%" else null
            ).joinToString("  •  ")
            textCol.addView(TextView(this).apply {
                text = epMeta
                textSize = 11.5f
                setTextColor(if (epProg != null) Color.parseColor("#E5A93B") else Color.parseColor("#9CA3AF"))
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(3) }
            })

            if (ep.plot.isNotBlank()) {
                textCol.addView(TextView(this).apply {
                    text = ep.plot
                    textSize = 11f
                    setTextColor(Color.parseColor("#6B7280"))
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply { topMargin = dp(2) }
                })
            }
            epRow.addView(textCol)

            // Right Status Badge
            val statusText = when {
                epProg != null -> "▶ ${epProg.progressPercent()}%"
                isEpWatched -> "✓ WATCHED"
                else -> "▶ PLAY"
            }
            val statusColor = when {
                epProg != null -> Color.parseColor("#E5A93B")
                isEpWatched -> Color.parseColor("#34D399")
                else -> Color.parseColor("#F4F5F7")
            }
            epRow.addView(TextView(this).apply {
                text = statusText
                textSize = 11f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(statusColor)
                setBackgroundResource(if (epProg != null) R.drawable.bg_obsidian_badge_gold else R.drawable.bg_obsidian_badge_dark)
                setPadding(dp(11), dp(5), dp(11), dp(5))
            })

            if (firstEpisodeFocusView == null || (targetEpisodeIdToFocus != null && ep.channel.id == targetEpisodeIdToFocus)) {
                firstEpisodeFocusView = epRow
            }
            epContainer.addView(epRow)
        }

        scroll.addView(epContainer)
        mainCol.addView(scroll)
        rootFrame.addView(mainCol)

        dialogRef = presentObsidianFullscreenDialog(rootFrame)
        firstEpisodeFocusView?.post { firstEpisodeFocusView?.requestFocus() }
    }

    private fun showEpisodeResumeOrRestartChoice(
        group: SeriesGroupSummary,
        ep: SeriesEpisodeItem,
        progEntry: PlaybackProgressEntry?
    ) {
        val options = ArrayList<GlassModalOption>(6)
        if (progEntry != null && progEntry.isResumable()) {
            val mins = (progEntry.positionMs / 60_000L).coerceAtLeast(1L)
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_play,
                    title = "Resume Episode ($mins min • ${progEntry.progressPercent()}%)",
                    subtitle = "Continue watching ${ep.episodeTitle} from saved position",
                    badgeText = "RESUME ${progEntry.progressPercent()}%",
                    isHighlighted = true
                ) {
                    playSeriesEpisodeItem(group, ep, resumePositionMs = progEntry.positionMs)
                }
            )
        }
        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_play,
                title = if (progEntry != null) "Start Episode from Beginning" else "Play Episode Now",
                subtitle = "Play Season ${ep.seasonNumber}, Episode ${ep.episodeNumber} from 00:00",
                badgeText = "PLAY",
                isHighlighted = progEntry == null
            ) {
                profileStore.clearPlaybackProgress(ep.channel.id, activeAccountScope)
                playSeriesEpisodeItem(group, ep, resumePositionMs = 0L)
            }
        )

        val nextEp = MediaCatalogEngine.findNextEpisodeInSeries(group, ep.seasonNumber, ep.episodeNumber, ep.channel.id)
        if (nextEp != null) {
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_play,
                    title = "Play Next Episode (S${nextEp.seasonNumber}E${nextEp.episodeNumber})",
                    subtitle = nextEp.episodeTitle,
                    badgeText = "NEXT"
                ) {
                    playSeriesEpisodeItem(group, nextEp, resumePositionMs = 0L)
                }
            )
        }

        val prevEp = MediaCatalogEngine.findPreviousEpisodeInSeries(group, ep.seasonNumber, ep.episodeNumber, ep.channel.id)
        if (prevEp != null) {
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_play,
                    title = "Play Previous Episode (S${prevEp.seasonNumber}E${prevEp.episodeNumber})",
                    subtitle = prevEp.episodeTitle,
                    badgeText = "PREV"
                ) {
                    playSeriesEpisodeItem(group, prevEp, resumePositionMs = 0L)
                }
            )
        }

        val isWatched = profileStore.isContentWatched(ep.channel.id, activeAccountScope)
        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_series,
                title = if (isWatched) "Mark Episode as Unwatched" else "Mark Episode as Watched",
                subtitle = "Update watched history for Season ${ep.seasonNumber}, Episode ${ep.episodeNumber}",
                badgeText = if (isWatched) "WATCHED" else "MARK"
            ) {
                if (isWatched) {
                    profileStore.markContentUnwatched(ep.channel.id, activeAccountScope)
                } else {
                    profileStore.markContentWatched(ep.channel.id, activeAccountScope)
                }
                presentSeriesDetailOverlayDialog(group, ep.seasonNumber)
            }
        )

        presentObsidianSheetDialog(
            title = ep.episodeTitle,
            subtitle = "${group.title} • Season ${ep.seasonNumber}, Episode ${ep.episodeNumber}",
            badgeText = "EPISODE",
            options = options,
            closeLabel = "Back"
        )
    }

    private fun playSeriesEpisodeItem(group: SeriesGroupSummary, ep: SeriesEpisodeItem, resumePositionMs: Long) {
        // Safely suspend Live TV (preserving its exact state) and launch independent Dedicated VOD Player
        suspendLiveTvForNonLiveSection("Series")
        activeSeriesGroup = group
        activeSeriesSeasonNum = ep.seasonNumber
        activeSeriesEpisodeItem = ep
        cancelOkHoldDelete()

        val navEpisodes = group.seasons.keys.sorted().flatMap { sNum ->
            group.seasons[sNum].orEmpty().sortedBy { it.episodeNumber }.map { item ->
                VodEpisodeNavItem(
                    episodeId = item.channel.id,
                    seriesId = group.seriesId,
                    seriesKey = group.seriesKey,
                    seriesTitle = group.title,
                    seasonNumber = item.seasonNumber,
                    episodeNumber = item.episodeNumber,
                    episodeTitle = item.episodeTitle,
                    streamUrl = item.channel.streamUrl,
                    posterUrl = item.channel.logoUrl.ifBlank { group.posterUrl },
                    durationLabel = item.durationLabel,
                    plot = item.plot,
                    containerExtension = item.channel.containerExtension
                )
            }
        }
        val sPad = ep.seasonNumber.toString().padStart(2, '0')
        val ePad = ep.episodeNumber.toString().padStart(2, '0')
        val payload = VodLaunchPayload(
            contentType = VodContentType.SERIES_EPISODE,
            contentId = ep.channel.id,
            streamUrl = ep.channel.streamUrl,
            title = "${group.title} • S${sPad}E${ePad} ${ep.episodeTitle}",
            subtitleLine = listOfNotNull(
                "Season ${ep.seasonNumber}, Episode ${ep.episodeNumber}",
                ep.durationLabel.takeIf { it.isNotBlank() },
                group.category.takeIf { it.isNotBlank() }
            ).joinToString(" • "),
            category = group.category,
            posterUrl = ep.channel.logoUrl.ifBlank { group.posterUrl },
            backdropUrl = group.posterUrl,
            rating = group.rating,
            releaseYear = group.releaseYear,
            durationLabel = ep.durationLabel,
            containerExtension = ep.channel.containerExtension,
            resumePositionMs = resumePositionMs.coerceAtLeast(0L),
            accountScope = activeAccountScope,
            seriesKey = group.seriesKey,
            seriesId = group.seriesId,
            seriesTitle = group.title,
            seasonNumber = ep.seasonNumber,
            episodeNumber = ep.episodeNumber,
            episodes = navEpisodes
        )
        dedicatedVodPlayerLauncher.launch(VodPlayerLauncher.createIntent(this, payload))
    }

    // =========================================================================
    // v18.1 SMART AUTO NEXT EPISODE WITH VISIBLE COUNTDOWN & CANCEL OPTION
    // (Requirement 17D: Identifies actual next episode in the same Series, shows
    // countdown near end or at completion, allows Cancel or Play Immediately)
    // =========================================================================

    private fun checkSmartAutoNextEpisodeNearEnd() {
        if (activePlaybackMode != ActivePlaybackMode.SERIES_EPISODE) return
        if (!::profileStore.isInitialized || !profileStore.isAutoNextEpisodeEnabled()) return
        val player = exoPlayer ?: return
        if (!player.isPlaying) return
        val group = activeSeriesGroup ?: return
        val curEp = activeSeriesEpisodeItem ?: return
        if (autoNextPromptShownForEpisodeId == curEp.channel.id) return

        val dur = player.duration
        val pos = player.currentPosition
        if (dur > 60_000L && pos > 0L && (dur - pos) in 1_000L..22_000L) {
            val nextEp = MediaCatalogEngine.findNextEpisodeInSeries(
                group = group,
                currentSeason = curEp.seasonNumber,
                currentEpisodeNumber = curEp.episodeNumber,
                currentEpisodeId = curEp.channel.id
            )
            if (nextEp != null) {
                autoNextPromptShownForEpisodeId = curEp.channel.id
                showAutoNextEpisodeCountdownModal(group, nextEp)
            }
        }
    }

    private fun showAutoNextEpisodeCountdownModal(group: SeriesGroupSummary, nextEp: SeriesEpisodeItem) {
        autoNextCountdownJob?.cancel()
        runCatching { loudnessEnhancer?.release() }
        loudnessEnhancer = null
        autoNextCountdownDialog?.dismiss()

        val sPad = nextEp.seasonNumber.toString().padStart(2, '0')
        val ePad = nextEp.episodeNumber.toString().padStart(2, '0')

        val rootCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_dialog_4d_glass)
            setPadding(dp(18), dp(16), dp(18), dp(16))
        }

        val tvCountdownBadge = TextView(this).apply {
            text = "NEXT EPISODE IN 8s"
            textSize = 11f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#38BDF8"))
            setBackgroundResource(R.drawable.bg_badge_neon)
            setPadding(dp(10), dp(5), dp(10), dp(5))
        }

        val headerRow = build4dModalHeader(
            iconRes = R.drawable.ic_3d_series,
            title = "Up Next: S${sPad}E${ePad} • ${nextEp.episodeTitle}",
            subtitle = "${group.title} • Season ${nextEp.seasonNumber}, Episode ${nextEp.episodeNumber}",
            badgeText = ""
        )
        headerRow.addView(tvCountdownBadge)
        rootCard.addView(headerRow)

        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(14) }
        }

        val btnCancel = create4dActionCapsuleButton("Cancel Auto-Play", R.drawable.bg_btn_3d_slate) {
            autoNextCountdownJob?.cancel()
            autoNextCountdownDialog?.dismiss()
            Toast.makeText(this, "Auto Next Episode cancelled for this episode", Toast.LENGTH_SHORT).show()
        }

        val btnPlayNow = create4dActionCapsuleButton(
            "⏭ Play Next Episode Now",
            R.drawable.bg_btn_3d_cyan,
            R.drawable.ic_3d_play
        ) {
            autoNextCountdownJob?.cancel()
            autoNextCountdownDialog?.dismiss()
            playSeriesEpisodeItem(group, nextEp, resumePositionMs = 0L)
        }

        btnRow.addView(btnCancel)
        btnRow.addView(btnPlayNow)
        rootCard.addView(btnRow)

        val dlg = present4dGlassDialog(rootCard, widthDp = 540)
        autoNextCountdownDialog = dlg
        btnPlayNow.post { btnPlayNow.requestFocus() }

        autoNextCountdownJob = lifecycleScope.launch {
            for (remaining in 8 downTo 1) {
                if (!dlg.isShowing) return@launch
                tvCountdownBadge.text = "NEXT EPISODE IN ${remaining}s"
                delay(1000L)
            }
            if (dlg.isShowing) {
                dlg.dismiss()
                playSeriesEpisodeItem(group, nextEp, resumePositionMs = 0L)
            }
        }
    }

    private fun recordCurrentVodOrSeriesProgress() {
        if (!::profileStore.isInitialized) return
        val player = exoPlayer ?: return
        val pos = player.currentPosition
        val dur = player.duration.takeIf { it > 0L && it != C.TIME_UNSET } ?: 0L
        if (pos < 10_000L) return

        when (activePlaybackMode) {
            ActivePlaybackMode.VOD_MOVIE -> {
                val movie = activeVodMovieItem ?: return
                if (movie.sourceType == ContentSourceType.XTREAM_VOD_MOVIE) {
                    profileStore.savePlaybackProgress(
                        contentId = movie.id,
                        positionMs = pos,
                        durationMs = dur,
                        seriesKey = "",
                        seasonNumber = 0,
                        episodeNumber = 0,
                        contentType = ContentSourceType.XTREAM_VOD_MOVIE,
                        accountScope = activeAccountScope
                    )
                }
            }
            ActivePlaybackMode.SERIES_EPISODE -> {
                val ep = activeSeriesEpisodeItem ?: return
                val grp = activeSeriesGroup ?: return
                profileStore.savePlaybackProgress(
                    contentId = ep.channel.id,
                    positionMs = pos,
                    durationMs = dur,
                    seriesKey = grp.seriesKey,
                    seasonNumber = ep.seasonNumber,
                    episodeNumber = ep.episodeNumber,
                    contentType = ContentSourceType.XTREAM_SERIES_EPISODE,
                    accountScope = activeAccountScope
                )
            }
            ActivePlaybackMode.LIVE_TV, ActivePlaybackMode.VOD_TRAILER -> {
                // Live TV channels and trailers NEVER enter VOD/Series Continue Watching!
            }
        }
    }

    // =========================================================================
    // v18.1 UNIVERSAL SMART SEARCH WITH STRICT CONTENT SEPARATION
    // (Requirement 17B: Searches Live TV, Movies, and Series independently,
    // displays clear content-type labels, and never shows Movies/Series for M3U accounts)
    // =========================================================================

    private fun showUnifiedSearchDialog(initialQuery: String = "") {
        suspendLiveTvForNonLiveSection("Search")
        val history = if (::profileStore.isInitialized) profileStore.getSearchHistory() else emptyList()
        val isXtream = activeSourceType == ProfileType.XTREAM
        val scopeSummary = if (isXtream) {
            "${allChannels.size} Live TV • ${vodMoviesCatalog.size} Movies • ${seriesCatalogGroups.size} Series"
        } else {
            "${allChannels.size} Live TV Channels (M3U Mode)"
        }
        show4dGlassFormModal(
            headerIconRes = R.drawable.ic_3d_search,
            title = "Universal Smart Search (Strict Catalog Separation)",
            subtitle = if (history.isNotEmpty()) {
                "Recent searches: ${history.take(5).joinToString(" • ")}  |  $scopeSummary"
            } else {
                "Search across $scopeSummary"
            },
            badgeText = if (isXtream) "LIVE • VOD • SERIES" else "LIVE TV ONLY",
            fields = listOf(
                GlassFormFieldSpec(
                    label = "SEARCH QUERY",
                    hint = if (isXtream) "Search Live TV channels, VOD Movies, or Series..." else "Search Live TV channels or categories...",
                    iconRes = R.drawable.ic_3d_search,
                    initialValue = initialQuery,
                    inputType = InputType.TYPE_CLASS_TEXT
                )
            ),
            neutralLabel = "🎙️ Voice Search",
            neutralBgRes = R.drawable.bg_btn_3d_cyan,
            neutralIconRes = R.drawable.ic_3d_search,
            onNeutral = { startVoiceSearch() },
            positiveLabel = "Search Catalogs",
            positiveBgRes = R.drawable.bg_btn_3d_cyan,
            positiveIconRes = R.drawable.ic_3d_search
        ) { values ->
            val q = ProfileStore.sanitizeExternalInput(values.firstOrNull().orEmpty())
            if (q.isNotBlank()) {
                profileStore.addSearchHistoryQuery(q)
                showUnifiedSearchResultsModal(q)
            }
        }
    }

    private fun showUnifiedSearchResultsModal(query: String) {
        lifecycleScope.launch {
            val qTrim = query.trim()
            val isXtream = activeSourceType == ProfileType.XTREAM

            val matchedOptions = withContext(Dispatchers.Default) {
                val results = ArrayList<GlassModalOption>(90)

                // 1. Search Live TV Catalog (`allChannels` — strictly Live TV)
                var liveCount = 0
                for (i in allChannels.indices) {
                    val ch = allChannels[i]
                    if (!ch.isLiveTvChannel()) continue
                    val matches = SearchIntelligenceEngine.matchesSmartQuery(
                        title = ch.name,
                        categoryOrSubtitle = ch.category,
                        rawQuery = qTrim,
                        channelNumberStr = ch.number.toString()
                    )
                    if (!matches) continue
                    val epgNow = lookupEpgForChannel(ch)?.first
                    val sub = buildString {
                        append("Live TV • ").append(ch.category)
                        if (!epgNow.isNullOrBlank()) append(" • Now: ").append(epgNow)
                    }
                    val targetIdx = i
                    results.add(
                        GlassModalOption(
                            iconRes = R.drawable.ic_3d_live_tv,
                            title = "[LIVE TV] ${ch.displayNumberFormatted()} • ${ch.name}",
                            subtitle = sub,
                            badgeText = "LIVE TV",
                            isHighlighted = activePlaybackMode == ActivePlaybackMode.LIVE_TV && targetIdx == currentChannelIndex
                        ) {
                            vodPosterGridPanel.visibility = View.GONE
                            activePlaybackMode = ActivePlaybackMode.LIVE_TV
                            switchChannel(targetIdx, immediatePlayback = true)
                        }
                    )
                    liveCount++
                    if (liveCount >= 35) break
                }

                // 2. Search VOD Movies Catalog (ONLY when connected to an Xtream account!)
                if (isXtream) {
                    var movieCount = 0
                    for (idx in vodMoviesCatalog.indices) {
                        val movie = vodMoviesCatalog[idx]
                        if (movie.sourceType != ContentSourceType.XTREAM_VOD_MOVIE) continue
                        val matches = SearchIntelligenceEngine.matchesSmartQuery(
                            title = movie.name,
                            categoryOrSubtitle = movie.category,
                            rawQuery = qTrim
                        )
                        if (!matches) continue
                        val targetMovieIdx = idx
                        val year = movie.extractReleaseYear()
                        results.add(
                            GlassModalOption(
                                iconRes = R.drawable.ic_3d_movies,
                                title = "[MOVIE] ${movie.cleanMovieDisplayTitle()}",
                                subtitle = "VOD Movie • ${movie.category}${if (year.isNotBlank()) " • $year" else ""}",
                                badgeText = "VOD MOVIE"
                            ) {
                                showMovieDetailModal(targetMovieIdx)
                            }
                        )
                        movieCount++
                        if (movieCount >= 35) break
                    }

                    // 3. Search Series Catalog (ONLY when connected to an Xtream account!)
                    var seriesCount = 0
                    for (grp in seriesCatalogGroups) {
                        val matches = SearchIntelligenceEngine.matchesSmartQuery(
                            title = grp.title,
                            categoryOrSubtitle = "${grp.category} ${grp.cast}",
                            rawQuery = qTrim
                        )
                        if (!matches) continue
                        results.add(
                            GlassModalOption(
                                iconRes = R.drawable.ic_3d_series,
                                title = "[SERIES] ${grp.title}",
                                subtitle = "VOD Series • ${grp.category}${if (grp.releaseYear.isNotBlank()) " • ${grp.releaseYear}" else ""}",
                                badgeText = "SERIES"
                            ) {
                                showSeriesDetailModal(grp)
                            }
                        )
                        seriesCount++
                        if (seriesCount >= 25) break
                    }
                }
                results
            }

            if (matchedOptions.isEmpty()) {
                Toast.makeText(this@PlayerActivity, "No matches found for '$qTrim'", Toast.LENGTH_LONG).show()
            } else {
                show4dGlassListModal(
                    headerIconRes = R.drawable.ic_3d_search,
                    title = "Search Results for \"$qTrim\"",
                    subtitle = if (isXtream) {
                        "Separated results across Live TV, VOD Movies & Series (${matchedOptions.size} matches)"
                    } else {
                        "Live TV results for M3U playlist (${matchedOptions.size} matches)"
                    },
                    badgeText = "${matchedOptions.size} FOUND",
                    options = matchedOptions,
                    closeLabel = "Close"
                )
            }
        }
    }

    private fun openDrawerAndRequestFocus() {
        leftChannelDrawer.alpha = 0f
        leftChannelDrawer.visibility = View.VISIBLE
        leftChannelDrawer.animate()
            .alpha(1f)
            .setDuration(if (activePerformanceMode.reducedAnimations) 60L else 130L)
            .withLayer()
            .start()
        topControlBar.visibility = View.VISIBLE
        renderDrawerList(scrollToActive = true, requestFocusOnActive = true)
    }

    private fun closeDrawerAndRestoreFocus() {
        leftChannelDrawer.visibility = View.GONE
        playerView.requestFocus()
    }

    private fun cacheKeyFor(raw: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(raw.toByteArray(Charsets.UTF_8))
        return bytes.take(12).joinToString("") { "%02x".format(it) }
    }

    /**
     * Rebuilds Live TV indices strictly from Live TV channels.
     * Never populates Movies or Series from `allChannels`!
     */
    private fun rebuildChannelIndicesSync(channels: List<Channel>) {
        val seq = IntArray(channels.size) { it }
        val byId = HashMap<String, Int>(channels.size)
        val nonSeqNum = SparseIntArray()
        val byCatTemp = HashMap<String, ArrayList<Int>>(32)
        val epgIds = HashSet<String>(channels.size * 2)

        for (i in channels.indices) {
            val ch = channels[i]
            if (!byId.containsKey(ch.id)) byId[ch.id] = i
            if (ch.number != i + 1 && nonSeqNum.indexOfKey(ch.number) < 0) {
                nonSeqNum.put(ch.number, i)
            }
            byCatTemp.getOrPut(ch.category.lowercase(Locale.ROOT)) { ArrayList() }.add(i)
            epgIds.add(ch.id)
            if (ch.epgId.isNotEmpty()) epgIds.add(ch.epgId)
        }
        val byCatPrimitive = HashMap<String, IntArray>(byCatTemp.size)
        for ((k, list) in byCatTemp) {
            byCatPrimitive[k] = list.toIntArray()
        }
        allSequentialIndices = seq
        channelIndexById = byId
        nonSequentialNumberMap = nonSeqNum
        channelsByCategory = byCatPrimitive
        knownEpgAndChannelIds = epgIds
    }

    private suspend fun applyLoadedChannels(
        newChannels: List<Channel>,
        sectionTitle: String? = null,
        resumeLastWatched: Boolean = true,
        isPreliminaryBatch: Boolean = false
    ) {
        // Ensure only Live TV channels enter `allChannels`
        val rawLive = newChannels.filter { it.sourceType.isLiveTv() }
        if (rawLive.isEmpty() && newChannels.isNotEmpty()) return
        if (!isPreliminaryBatch) {
            rawLoadedLiveChannels = rawLive
        }
        val liveOnlyChannels = if (::profileStore.isInitialized) {
            ChannelDeletionFilter.filterActiveChannels(
                rawChannels = rawLive,
                deletedCategories = profileStore.getAllExcludedCategories(activeAccountScope),
                deletedChannelKeys = profileStore.getDeletedChannelKeys(activeAccountScope),
                deletedChannelIds = profileStore.getDeletedChannelIds(activeAccountScope)
            )
        } else {
            rawLive
        }

        val prefs = getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
        val shouldResume = resumeLastWatched && autoResumeEnabled
        val savedLastId = if (shouldResume) prefs.getString("last_channel_id", null) else null
        val savedLastIndex = if (shouldResume) prefs.getInt("last_channel_index", 0) else 0

        if (!isPreliminaryBatch) {
            updateBootStage(80, "Indexing ${liveOnlyChannels.size} Live TV Channels...", "Zero-copy primitive arrays")
        }

        val prepared = withContext(Dispatchers.Default) {
            val seq = IntArray(liveOnlyChannels.size) { it }
            val byId = HashMap<String, Int>(liveOnlyChannels.size)
            val nonSeqNum = SparseIntArray()
            val byCatTemp = HashMap<String, ArrayList<Int>>(128)
            val categorySet = LinkedHashSet<String>()
            val epgIds = HashSet<String>(liveOnlyChannels.size.coerceAtMost(15000))

            for (i in liveOnlyChannels.indices) {
                if (i % 2000 == 0) ensureActive()
                val ch = liveOnlyChannels[i]
                if (!byId.containsKey(ch.id)) byId[ch.id] = i
                if (ch.number != i + 1 && nonSeqNum.indexOfKey(ch.number) < 0) {
                    nonSeqNum.put(ch.number, i)
                }
                if (ch.category.isNotBlank()) {
                    categorySet.add(ch.category)
                    byCatTemp.getOrPut(ch.category.lowercase(Locale.ROOT)) { ArrayList() }.add(i)
                }
                if (epgIds.size < 25000) {
                    epgIds.add(ch.id)
                    if (ch.epgId.isNotEmpty()) epgIds.add(ch.epgId)
                }
            }
            val byCatPrimitive = HashMap<String, IntArray>(byCatTemp.size)
            for ((k, list) in byCatTemp) {
                byCatPrimitive[k] = list.toIntArray()
            }
            val categories = ArrayList<String>(categorySet.size + 1).apply {
                add("All categories")
                addAll(categorySet.sorted())
            }
            val targetIdx = if (shouldResume) {
                (if (!savedLastId.isNullOrBlank()) byId[savedLastId] else null)
                    ?: savedLastIndex.takeIf { it in liveOnlyChannels.indices }
                    ?: 0
            } else {
                0
            }
            PreparedChannelData(seq, byId, nonSeqNum, byCatPrimitive, categories, epgIds, targetIdx)
        }

        allChannels = liveOnlyChannels
        allSequentialIndices = prepared.seq
        channelIndexById = prepared.byId
        nonSequentialNumberMap = prepared.nonSeqNum
        channelsByCategory = prepared.byCat
        knownEpgAndChannelIds = prepared.epgIds

        suppressCategoryCallback = true
        selectedCategory = "All categories"
        categoryFilter.adapter = createGlassCategoryAdapter(prepared.categories)
        categoryFilter.setSelection(0, false)
        suppressCategoryCallback = false

        if (sectionTitle != null) {
            tvActiveSectionBadge.text = sectionTitle
        }

        if (!isPreliminaryBatch || currentPlayingStreamUrl.isEmpty()) {
            previousChannelIndex = prepared.startIndex
            updateBootStage(92, "Starting Live TV...", "Channel #${prepared.startIndex + 1}")
            activePlaybackMode = ActivePlaybackMode.LIVE_TV
            switchChannel(prepared.startIndex, immediatePlayback = true)
        }

        if (leftChannelDrawer.visibility == View.VISIBLE) {
            renderDrawerList(scrollToActive = true)
        }
    }

    private data class PreparedChannelData(
        val seq: IntArray,
        val byId: Map<String, Int>,
        val nonSeqNum: SparseIntArray,
        val byCat: Map<String, IntArray>,
        val categories: List<String>,
        val epgIds: Set<String>,
        val startIndex: Int
    )

    private fun clearVodAndSeriesCatalogsForAccountSwitch() {
        vodCatalogLoadJob?.cancel()
        seriesCatalogLoadJob?.cancel()
        rawLoadedVodMovies = emptyList()
        vodMoviesCatalog = emptyList()
        vodMovieIndexById = emptyMap()
        rawLoadedSeries = emptyList()
        seriesCatalogRaw = emptyList()
        seriesCatalogGroups = emptyList()
        loadedSeriesEpisodesCache.clear()
        activeVodMovieItem = null
        activeVodMovieIndex = -1
        activeVodMovieDetailInfo = null
        activeSeriesGroup = null
        activeSeriesEpisodeItem = null
    }

    private fun initializeMedia3ProEngine(recreateIfPresent: Boolean = false) {
        if (exoPlayer != null && !recreateIfPresent) return
        val previousUrl = currentPlayingStreamUrl
        if (recreateIfPresent) {
            playerView.player = null
            RamPlayerPlaybackService.unregisterAuthoritativePlayer(exoPlayer)
        exoPlayer?.release()
            exoPlayer = null
            currentPlayingStreamUrl = ""
        }

        val bp = activeBufferProfile
        val allocator = DefaultAllocator(true, 64 * 1024)
        sharedAllocator = allocator
        val loadControl = DefaultLoadControl.Builder()
            .setAllocator(allocator)
            .setBufferDurationsMs(bp.minBufferMs, bp.maxBufferMs, bp.playBufferMs, bp.rebufferMs)
            .setTargetBufferBytes(bp.targetBytes)
            .setBackBuffer(0, false)
            .setPrioritizeTimeOverSizeThresholds(bp.prioritizeTimeOverSize)
            .build()

        // Avoid loading optional software decoder extensions on 512MB TVs; enable async MediaCodec queueing & fallback.
        if (::profileStore.isInitialized) {
            audioDelayProcessor.setDelayMs(profileStore.getAudioDelayMs(activeAccountScope))
        }
        val renderersFactory = object : DefaultRenderersFactory(this) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): AudioSink {
                return DefaultAudioSink.Builder(context)
                    .setEnableFloatOutput(enableFloatOutput)
                    .setEnableAudioTrackPlaybackParams(true)
                    .setAudioProcessors(arrayOf(audioDelayProcessor))
                    .build()
            }
        }
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
            .setEnableDecoderFallback(true)

        // Direct-RAM Zero-Disk OkHttpDataSource wrapped with PreloadAwareDataSourceFactory
        val okHttpDataSourceFactory = OkHttpDataSource.Factory(NetworkClient.streamClient)
            .setUserAgent(NetworkClient.resolveEffectiveUserAgent(null))
        val preloadAwareFactory = StreamPreFetcher.createPreloadAwareDataSourceFactory(okHttpDataSourceFactory)

        // OTT Navigator-grade resilient TS/HLS extractors for non-standard IPTV restreamers:
        // handles non-IDR keyframes, missing access unit delimiters & HDMV DTS audio streams.
        val resilientTsFlags = DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES or
            DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS or
            DefaultTsPayloadReaderFactory.FLAG_ENABLE_HDMV_DTS_AUDIO_STREAMS
        val resilientExtractors = DefaultExtractorsFactory()
            .setTsExtractorFlags(resilientTsFlags)
        val resilientHlsExtractor = DefaultHlsExtractorFactory(
            DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES or
                DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS,
            true
        )

        // CRITICAL AUDIO FIX (v21.0): Disable chunkless preparation so HLS MPEG-TS streams without
        // explicit CODECS metadata in master playlists always probe audio elementary streams cleanly.
        val resilientLoadPolicy = DefaultLoadErrorHandlingPolicy(4)

        hlsChunklessFactory = HlsMediaSource.Factory(preloadAwareFactory)
            .setExtractorFactory(resilientHlsExtractor)
            .setLoadErrorHandlingPolicy(resilientLoadPolicy)
            .setAllowChunklessPreparation(false)

        val mediaSourceFactory = DefaultMediaSourceFactory(preloadAwareFactory, resilientExtractors)
            .setLoadErrorHandlingPolicy(resilientLoadPolicy)
        defaultMediaSourceFactory = mediaSourceFactory

        val selector = DefaultTrackSelector(this)
        trackSelector = selector

        exoPlayer = ExoPlayer.Builder(this, renderersFactory)
            .setTrackSelector(selector)
            .setLoadControl(loadControl)
            .setSeekParameters(SeekParameters.CLOSEST_SYNC)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setMediaSourceFactory(mediaSourceFactory)
            .build()
            .also { player ->
                player.videoScalingMode = C.VIDEO_SCALING_MODE_SCALE_TO_FIT
                player.videoChangeFrameRateStrategy = C.VIDEO_CHANGE_FRAME_RATE_STRATEGY_ONLY_IF_SEAMLESS
                RamPlayerPlaybackService.registerAuthoritativePlayer(player)
                playerView.player = player
                playerView.resizeMode = resizeModes[currentResizeIndex]
        liveTvVlcEngine?.setAspectRatioByResizeIndex(currentResizeIndex)

                val globalPrefLang = if (::profileStore.isInitialized) {
                    profileStore.getGlobalPreferredAudioLanguage(activeAccountScope)
                } else "hi"
                val langPriority = listOf(globalPrefLang, "hi", "hin", "en", "eng").distinct().toTypedArray()
                val paramsBuilder = player.trackSelectionParameters
                    .buildUpon()
                    .setPreferredAudioLanguages(*langPriority)
                    .setForceHighestSupportedBitrate(true)
                    .setMaxVideoBitrate(Int.MAX_VALUE)
                    .clearViewportSizeConstraints()
                val savedSize = selectedQualityMaxSize
                if (savedSize != null) {
                    paramsBuilder.setMaxVideoSize(savedSize.first, savedSize.second)
                } else if (isLowRamTvDevice && selectedQualityLabel == "Auto") {
                    paramsBuilder.setMaxVideoSize(1920, 1080)
                }
                player.trackSelectionParameters = paramsBuilder.build()
                if (::profileStore.isInitialized && profileStore.isVideoTunnelingEnabled()) {
                    selector.setParameters(selector.buildUponParameters().setTunnelingEnabled(true))
                }
                if (::profileStore.isInitialized) {
                    applyAudioPassthroughPreference(player)
                }

                // Genuine audio codec/sink error monitoring for Automatic Audio Recovery & Diagnostics
                player.addAnalyticsListener(object : AnalyticsListener {
                    override fun onAudioCodecError(
                        eventTime: AnalyticsListener.EventTime,
                        audioCodecError: Exception
                    ) {
                        lastAudioDecoderError = audioCodecError.message ?: audioCodecError.javaClass.simpleName
                        inspectAndRecoverAudioTracks(player, allowAutoRecovery = true)
                        checkProactiveLibVlcLiveHandover(player, "Audio codec error: $lastAudioDecoderError")
                    }

                    override fun onAudioSinkError(
                        eventTime: AnalyticsListener.EventTime,
                        audioSinkError: Exception
                    ) {
                        lastAudioOutputError = audioSinkError.message ?: audioSinkError.javaClass.simpleName
                        inspectAndRecoverAudioTracks(player, allowAutoRecovery = true)
                        checkProactiveLibVlcLiveHandover(player, "Audio sink error: $lastAudioOutputError")
                    }
                })

                player.addListener(object : Player.Listener {
                    override fun onTracksChanged(tracks: Tracks) {
                        inspectAndRecoverAudioTracks(player, allowAutoRecovery = true)
                        checkProactiveLibVlcLiveHandover(player, "Unsupported track detected")
                        val activeUrl = currentPlayingStreamUrl
                        val targetSize = selectedQualityMaxSize
                        if (targetSize != null && activeUrl.isNotBlank() && lastAutoQualityAppliedStreamUrl != activeUrl) {
                            lastAutoQualityAppliedStreamUrl = activeUrl
                            applyVideoQualitySelection(player, targetSize, selectedQualityLabel, silent = true)
                        }
                    }

                    override fun onRenderedFirstFrame() {
                        val now = SystemClock.elapsedRealtime()
                        if (firstVideoFrameMs == 0L) {
                            firstVideoFrameMs = now - processStartElapsedMs
                        }
                        if (lastSwitchStartElapsedMs > 0L) {
                            lastChannelSwitchMs = now - lastSwitchStartElapsedMs
                        }
                        hasRenderedVideoFrame = true
                        uiHandler.removeCallbacks(blackScreenWatchdogRunnable)
                        if (isBootOverlayVisible) {
                            dismissDthBootOverlay("READY TO WATCH")
                        }
                        if (pendingResumeSeekPositionMs > 5_000L) {
                            val targetSeek = pendingResumeSeekPositionMs
                            pendingResumeSeekPositionMs = 0L
                            player.seekTo(targetSeek)
                        }
                        updateLiveTelemetryBadge(player)
                        if (activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
                            updateOsdForCurrentChannel()
                        }
                    }

                    override fun onPositionDiscontinuity(
                        oldPosition: Player.PositionInfo,
                        newPosition: Player.PositionInfo,
                        reason: Int
                    ) {
                        cancelPendingDelayedSubtitles()
                        audioDelayProcessor.clearDelayBuffer()
                    }

                    override fun onIsPlayingChanged(isPlaying: Boolean) {
                        if (!isPlaying) {
                            cancelPendingDelayedSubtitles()
                            audioDelayProcessor.clearDelayBuffer()
                        }
                    }

                    override fun onCues(cueGroup: CueGroup) {
                        val delayMs = if (::profileStore.isInitialized) {
                            profileStore.getSubtitleDelayMs(activeAccountScope)
                        } else 0
                        if (delayMs <= 0) {
                            tvDelayedSubtitleOverlay?.visibility = View.GONE
                            playerView.subtitleView?.visibility = View.VISIBLE
                            return
                        }
                        playerView.subtitleView?.visibility = View.GONE
                        val gen = subtitleCueGeneration
                        val text = cueGroup.cues.mapNotNull { it.text?.toString()?.trim() }
                            .filter { it.isNotEmpty() }
                            .joinToString("\n")
                        uiHandler.postDelayed({
                            if (!isFinishing && !isDestroyed && gen == subtitleCueGeneration) {
                                val overlay = ensureDelayedSubtitleOverlay()
                                if (text.isBlank()) {
                                    overlay.visibility = View.GONE
                                } else {
                                    overlay.text = text
                                    overlay.visibility = View.VISIBLE
                                }
                            }
                        }, delayMs.toLong())
                    }

                    override fun onVideoSizeChanged(videoSize: VideoSize) {
                        val h = videoSize.height
                        val w = videoSize.width
                        if (h > 0 && w > 0) {
                            liveResolutionLabel = when {
                                h >= 2160 || w >= 3840 -> "4K UHD"
                                h >= 1080 -> "1080p FHD"
                                h >= 720 -> "720p HD"
                                h >= 540 -> "576p HQ"
                                else -> "${h}p SD"
                            }
                            updateLiveTelemetryBadge(player)
                            if (activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
                                updateOsdForCurrentChannel()
                            }
                        }
                    }

                    override fun onPlaybackStateChanged(playbackState: Int) {
                        when (playbackState) {
                            Player.STATE_BUFFERING -> {
                                bufferingStartElapsedMs = SystemClock.elapsedRealtime()
                                liveStatusLabel = if (usingBackupStream) "⏳ Backup..." else "⏳ Buffering..."
                                osdLiveProgressBar.progress = 55
                                if (activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
                                    updateOsdForCurrentChannel()
                                }
                                uiHandler.removeCallbacks(stallWatchdogRunnable)
                                uiHandler.postDelayed(stallWatchdogRunnable, 2500L)
                            }
                            Player.STATE_READY -> {
                                if (bufferingStartElapsedMs > 0L) {
                                    lastBufferingDurationMs = (SystemClock.elapsedRealtime() - bufferingStartElapsedMs).coerceAtLeast(1L)
                                    bufferingStartElapsedMs = 0L
                                }
                                playbackRetryCount = 0
                                stallRecoveryCount = 0
                                uiHandler.removeCallbacks(stallWatchdogRunnable)
                                if (activePlaybackMode == ActivePlaybackMode.LIVE_TV && !hasRenderedVideoFrame && !isLiveTvUsingLibVlc) {
                                    uiHandler.removeCallbacks(blackScreenWatchdogRunnable)
                                    uiHandler.postDelayed(blackScreenWatchdogRunnable, 1300L)
                                }
                                liveStatusLabel = if (usingBackupStream) "🟢 Live (Backup)" else "🟢 Playing"
                                osdLiveProgressBar.progress = 100
                                updateLiveTelemetryBadge(player)
                                if (activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
                                    updateOsdForCurrentChannel()
                                    if (allChannels.size > 1) {
                                        val nextIdx = (currentChannelIndex + 1) % allChannels.size
                                        val prevIdx = (currentChannelIndex - 1 + allChannels.size) % allChannels.size
                                        StreamPreFetcher.scheduleAdjacentPrefetch(
                                            this@PlayerActivity,
                                            allChannels.getOrNull(nextIdx)?.streamUrl,
                                            allChannels.getOrNull(prevIdx)?.streamUrl,
                                            preferForward = lastZapForward,
                                            hlsFactory = hlsChunklessFactory,
                                            defaultMediaSourceFactory = defaultMediaSourceFactory
                                        )
                                    }
                                }
                            }
                            Player.STATE_ENDED -> {
                                uiHandler.removeCallbacks(stallWatchdogRunnable)
                                when (activePlaybackMode) {
                                    ActivePlaybackMode.VOD_MOVIE -> {
                                        activeVodMovieItem?.let { m ->
                                            if (::profileStore.isInitialized) {
                                                profileStore.clearPlaybackProgress(m.id, activeAccountScope)
                                            }
                                        }
                                        liveStatusLabel = "✓ Movie Completed"
                                        osdLiveProgressBar.progress = 100
                                        val detail = activeVodMovieDetailInfo
                                        if (detail != null && activeVodMovieIndex in vodMoviesCatalog.indices) {
                                            openVodPosterHub(EntertainmentSection.MOVIES, restoreFocusIndex = lastFocusedPosterIndex)
                                            showMovieDetailModal(activeVodMovieIndex, detail)
                                        }
                                    }
                                    ActivePlaybackMode.SERIES_EPISODE -> {
                                        val curEp = activeSeriesEpisodeItem
                                        val grp = activeSeriesGroup
                                        if (curEp != null && ::profileStore.isInitialized) {
                                            profileStore.clearPlaybackProgress(curEp.channel.id, activeAccountScope)
                                        }
                                        liveStatusLabel = "✓ Episode Completed"
                                        osdLiveProgressBar.progress = 100
                                        if (grp != null && curEp != null) {
                                            val nextEp = MediaCatalogEngine.findNextEpisodeInSeries(
                                                group = grp,
                                                currentSeason = curEp.seasonNumber,
                                                currentEpisodeNumber = curEp.episodeNumber,
                                                currentEpisodeId = curEp.channel.id
                                            )
                                            if (nextEp != null && ::profileStore.isInitialized && profileStore.isAutoNextEpisodeEnabled()) {
                                                if (autoNextPromptShownForEpisodeId != curEp.channel.id) {
                                                    autoNextPromptShownForEpisodeId = curEp.channel.id
                                                    showAutoNextEpisodeCountdownModal(grp, nextEp)
                                                }
                                            } else {
                                                openVodPosterHub(EntertainmentSection.SERIES, restoreFocusIndex = lastFocusedPosterIndex)
                                                presentSeriesDetailOverlayDialog(grp, activeSeriesSeasonNum)
                                            }
                                        }
                                    }
                                    ActivePlaybackMode.VOD_TRAILER -> {
                                        val detail = activeVodMovieDetailInfo
                                        if (detail != null && activeVodMovieIndex in vodMoviesCatalog.indices) {
                                            openVodPosterHub(EntertainmentSection.MOVIES, restoreFocusIndex = lastFocusedPosterIndex)
                                            showMovieDetailModal(activeVodMovieIndex, detail)
                                        }
                                    }
                                    ActivePlaybackMode.LIVE_TV -> {
                                        liveStatusLabel = "🔄 Reconnecting..."
                                        osdLiveProgressBar.progress = 35
                                        updateOsdForCurrentChannel()
                                        uiHandler.removeCallbacks(retryPlaybackRunnable)
                                        uiHandler.postDelayed(retryPlaybackRunnable, 750L)
                                    }
                                }
                            }
                            Player.STATE_IDLE -> {
                                uiHandler.removeCallbacks(stallWatchdogRunnable)
                            }
                        }
                    }

                    override fun onPlayerError(error: PlaybackException) {
                        uiHandler.removeCallbacks(stallWatchdogRunnable)
                        recentPlaybackErrorSummary = "${error.errorCodeName}: ${error.message ?: "Playback error"}"
                        Log.w("StreamX", "Playback error (${error.errorCodeName}): ${NetworkClient.redactSensitiveUrl(error.message)}")

                        // OTT Navigator-style smart format auto-fallback for extensionless URLs:
                        // If container/manifest sniffing fails, automatically probe HLS then DASH before failing.
                        if (error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED ||
                            error.errorCode == PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED
                        ) {
                            val activeUrl = currentPlayingStreamUrl
                            if (activeUrl.isNotBlank()) {
                                if (formatFallbackUrl != activeUrl) {
                                    formatFallbackUrl = activeUrl
                                    formatFallbackStage = 0
                                }
                                val existingDrm = NetworkClient.drmConfigForUrl(activeUrl)
                                val nextManifestType = when (formatFallbackStage) {
                                    0 -> "hls"
                                    1 -> "mpd"
                                    else -> ""
                                }
                                if (nextManifestType.isNotEmpty()) {
                                    formatFallbackStage++
                                    val fallbackCfg = NetworkClient.StreamDrmConfig(
                                        licenseType = existingDrm?.licenseType.orEmpty(),
                                        licenseKey = existingDrm?.licenseKey.orEmpty(),
                                        manifestType = nextManifestType
                                    )
                                    val probeItem = StreamPreFetcher.buildLiveMediaItem(activeUrl)
                                    val probeSource = buildOttConfiguredMediaSource(activeUrl, probeItem, fallbackCfg)
                                    if (probeSource != null) {
                                        liveStatusLabel = "⚡ Auto-Format (${nextManifestType.uppercase(Locale.ROOT)})..."
                                        if (activePlaybackMode == ActivePlaybackMode.LIVE_TV) updateOsdForCurrentChannel()
                                        player.setMediaSource(probeSource, true)
                                        player.prepare()
                                        player.playWhenReady = true
                                        return
                                    }
                                }
                            }
                        }

                        // Instant recovery for live window drift without consuming retry budget
                        if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                            liveStatusLabel = "⚡ Live Edge Sync..."
                            updateOsdForCurrentChannel()
                            player.seekToDefaultPosition()
                            player.prepare()
                            player.playWhenReady = true
                            return
                        }

                        if (error.errorCode == PlaybackException.ERROR_CODE_DECODING_FAILED ||
                            error.errorCode == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED
                        ) {
                            player.trackSelectionParameters = player.trackSelectionParameters
                                .buildUpon()
                                .setMaxVideoSize(1280, 720)
                                .setMaxVideoBitrate(4_000_000)
                                .build()
                        }

                        if (activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
                            val activeChannel = allChannels.getOrNull(currentChannelIndex)
                            if (activeChannel != null && !usingBackupStream && activeChannel.backupUrl.isNotBlank()) {
                                usingBackupStream = true
                                playbackRetryCount = 0
                                liveStatusLabel = "⚡ Auto-Failover Backup..."
                                updateOsdForCurrentChannel()
                                playSpecificStreamUrl(activeChannel.backupUrl)
                                return
                            }
                        }

                        val failureCategory = PlaybackRecoveryEngine.classifyFailure(
                            errorCode = error.errorCode,
                            errorCodeName = error.errorCodeName,
                            message = error.message
                        )
                        if (activePlaybackMode == ActivePlaybackMode.LIVE_TV && !isLiveTvUsingLibVlc) {
                            val engineMode = if (::profileStore.isInitialized) profileStore.getLiveTvEngineMode() else LiveTvEngineMode.AUTO_OTT_HEAL
                            if (LiveTvEngineRouter.shouldSwitchToLibVlcOnError(error.errorCodeName, error.message, engineMode)) {
                                if (advanceLiveTvHealStage("Media3 ${error.errorCodeName}")) {
                                    return
                                }
                            }
                        }

                        val isUnsupportedCodec = failureCategory == PlaybackFailureCategory.UNSUPPORTED_CODEC
                        if (isUnsupportedCodec) {
                            liveStatusLabel = "⚠️ ${failureCategory.displayLabel}"
                            osdLiveProgressBar.progress = 15
                            if (activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
                                updateOsdForCurrentChannel()
                            }
                            if (isBootOverlayVisible) {
                                dismissDthBootOverlay("READY TO WATCH")
                            }
                            Toast.makeText(
                                this@PlayerActivity,
                                "Unsupported stream codec on this device.",
                                Toast.LENGTH_LONG
                            ).show()
                            return
                        }

                        // Auto-Reconnect enabled for Live TV: continuously recover dropped/stalled/errored streams
                        playbackRetryCount++
                        val retryNum = playbackRetryCount
                        if (activePlaybackMode == ActivePlaybackMode.LIVE_TV && !isLiveTvUsingLibVlc && retryNum >= 2) {
                            playbackRetryCount = 0
                            if (advanceLiveTvHealStage("Media3 failed to start after retry #$retryNum (${error.errorCodeName})")) {
                                return
                            }
                        }
                        val backoffMs = when {
                            retryNum <= 3 -> (900L * (1 shl (retryNum - 1))).coerceAtMost(3200L)
                            else -> 5000L
                        }
                        liveStatusLabel = "🔄 Reconnecting (#$retryNum)..."
                        osdLiveProgressBar.progress = 30
                        if (activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
                            updateOsdForCurrentChannel()
                        }
                        if (isBootOverlayVisible && retryNum >= 2) {
                            dismissDthBootOverlay("RECONNECTING STREAM...")
                        }
                        uiHandler.removeCallbacks(retryPlaybackRunnable)
                        uiHandler.postDelayed(retryPlaybackRunnable, backoffMs)
                    }
                })
            }

        if (previousUrl.isNotEmpty()) {
            playSpecificStreamUrl(previousUrl, forceReload = true)
        }
    }

    private fun updateLiveTelemetryBadge(player: ExoPlayer) {
        val vf = player.videoFormat
        val af = player.audioFormat
        val parts = ArrayList<String>(2)
        if (vf != null) {
            if (vf.frameRate > 0f) {
                parts.add("${vf.frameRate.toInt()}fps")
            }
            if (vf.bitrate > 0) {
                val mbps = vf.bitrate / 1_000_000.0
                parts.add(String.format(Locale.US, "%.1fMbps", mbps))
            }
        }
        liveTelemetryDetail = parts.joinToString(" • ")

        val preloadPrefix = if (lastSwitchUsedPreload) "⚡ PRELOAD" else "⚡"
        val zapTag = if (lastChannelSwitchMs in 1..4999) "$preloadPrefix ${lastChannelSwitchMs}ms" else "$preloadPrefix DIRECT-RAM"
        val hdrTag = detectActiveStreamHdrLabel(vf)
        val diagSnap = lastAudioDiagnostics
        val audioTag = when {
            diagSnap != null -> diagSnap.osdShortBadge()
            af != null -> {
                val lang = af.language?.uppercase(Locale.ROOT)?.takeIf { it.isNotBlank() && it != "UND" } ?: "AUD"
                val chs = if (af.channelCount > 0) "${af.channelCount}ch" else ""
                "$lang $chs".trim()
            }
            else -> "NO AUDIO"
        }
        tvOsdStreamBadge.text = "$zapTag • $hdrTag • $audioTag"
    }

    private fun recallPreviousChannel() {
        if (allChannels.isEmpty()) return
        activePlaybackMode = ActivePlaybackMode.LIVE_TV
        if (previousChannelIndex != currentChannelIndex && previousChannelIndex in allChannels.indices) {
            val target = previousChannelIndex
            Toast.makeText(this, "⟲ Recall: ${allChannels[target].name}", Toast.LENGTH_SHORT).show()
            switchChannel(target, immediatePlayback = true)
        } else if (recentIds.size >= 2) {
            val prevId = recentIds[1]
            val idx = channelIndexById[prevId]
            if (idx != null && idx != currentChannelIndex) {
                Toast.makeText(this, "⟲ Recall: ${allChannels[idx].name}", Toast.LENGTH_SHORT).show()
                switchChannel(idx, immediatePlayback = true)
            }
        } else {
            Toast.makeText(this, "No previous channel yet", Toast.LENGTH_SHORT).show()
        }
    }

    // =========================================================================
    // 4D CRYSTAL GLASS STUDIO MODAL DIALOG ENGINE
    // =========================================================================

    private fun build4dModalHeader(
        iconRes: Int,
        title: String,
        subtitle: String,
        badgeText: String
    ): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundResource(R.drawable.bg_dialog_header_4d)
            setPadding(dp(14), dp(12), dp(14), dp(12))

            val iconFrame = ImageView(this@PlayerActivity).apply {
                setImageResource(iconRes)
                setBackgroundResource(R.drawable.bg_channel_logo_frame)
                setPadding(dp(8), dp(8), dp(8), dp(8))
                scaleType = ImageView.ScaleType.FIT_CENTER
                layoutParams = LinearLayout.LayoutParams(dp(42), dp(42))
            }
            addView(iconFrame)

            val textCol = LinearLayout(this@PlayerActivity).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = dp(12)
                    marginEnd = dp(8)
                }
            }
            val tvTitle = TextView(this@PlayerActivity).apply {
                text = title
                textSize = 15.5f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#F8FAFC"))
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }
            val tvSub = TextView(this@PlayerActivity).apply {
                text = subtitle
                textSize = 11.5f
                setTextColor(Color.parseColor("#BAE6FD"))
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
            }
            textCol.addView(tvTitle)
            textCol.addView(tvSub)
            addView(textCol)

            if (badgeText.isNotBlank()) {
                val tvBadge = TextView(this@PlayerActivity).apply {
                    text = badgeText
                    textSize = 10.5f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(Color.parseColor("#38BDF8"))
                    setBackgroundResource(R.drawable.bg_badge_neon)
                    setPadding(dp(10), dp(5), dp(10), dp(5))
                }
                addView(tvBadge)
            }
        }
    }

    private fun create4dActionCapsuleButton(
        label: String,
        bgRes: Int,
        iconRes: Int = 0,
        onClick: () -> Unit
    ): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            setBackgroundResource(bgRes)
            backgroundTintList = null
            isFocusable = true
            setPadding(dp(16), dp(8), dp(16), dp(8))
            if (iconRes != 0) {
                setCompoundDrawablesWithIntrinsicBounds(iconRes, 0, 0, 0)
                compoundDrawablePadding = dp(7)
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                dp(40)
            ).apply {
                marginStart = dp(8)
            }
            attach4dFocusMicroInteraction(this)
            setOnClickListener { onClick() }
        }
    }

    private fun present4dGlassDialog(rootCard: View, widthDp: Int = 540): AlertDialog {
        val dlg = AlertDialog.Builder(this, R.style.Theme_StreamX_GlassDialog)
            .setView(rootCard)
            .create()
        dlg.show()
        activeGlassDialogCount = (activeGlassDialogCount + 1).coerceAtLeast(1)
        dlg.setOnDismissListener {
            activeGlassDialogCount = (activeGlassDialogCount - 1).coerceAtLeast(0)
            if (activeGlassDialogCount == 0) {
                // A replacement/nested dialog is normally created synchronously by the
                // option callback. Delay the check so it can register before resuming.
                uiHandler.postDelayed({
                    val suspended = LiveTvBackgroundPlaybackController.peekSuspendedState()
                    val isBackOnLiveSurface =
                        activeGlassDialogCount == 0 &&
                        !isFinishing && !isDestroyed &&
                        activePlaybackMode == ActivePlaybackMode.LIVE_TV &&
                        !vodPosterGridPanel.isShown
                    if (isBackOnLiveSurface && suspended.wasSuspended) {
                        restoreLiveTvOnReturnFromNonLiveSection()
                    }
                }, 220L)
            }
        }
        dlg.window?.let { win ->
            win.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            val maxW = (resources.displayMetrics.widthPixels * 0.92f).toInt()
            val targetW = dp(widthDp).coerceAtMost(maxW)
            win.setLayout(targetW, WindowManager.LayoutParams.WRAP_CONTENT)
        }
        return dlg
    }

    private fun show4dGlassListModal(
        headerIconRes: Int,
        title: String,
        subtitle: String,
        badgeText: String,
        options: List<GlassModalOption>,
        closeLabel: String = "Close"
    ) {
        var dialogRef: AlertDialog? = null
        val rootCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_dialog_4d_glass)
            setPadding(dp(18), dp(16), dp(18), dp(16))
        }

        rootCard.addView(build4dModalHeader(headerIconRes, title, subtitle, badgeText))

        val maxScrollHeight = (resources.displayMetrics.heightPixels * 0.56f).toInt().coerceAtLeast(dp(180))
        val scroll = ScrollView(this).apply {
            isFillViewport = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(12)
                bottomMargin = dp(10)
            }
        }
        val listContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        var firstFocusableRow: View? = null
        options.forEachIndexed { idx, opt ->
            val rowCard = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                isFocusable = true
                isClickable = true
                isSelected = opt.isHighlighted
                setBackgroundResource(
                    if (opt.isHighlighted) themes[currentThemeIndex].activeRowDrawableRes
                    else R.drawable.bg_dialog_item_4d
                )
                setPadding(dp(12), dp(10), dp(12), dp(10))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    if (idx < options.lastIndex) bottomMargin = dp(7)
                }
                attach4dFocusMicroInteraction(this, focusedScale = 1.02f)
                setOnClickListener {
                    dialogRef?.dismiss()
                    opt.onClick()
                }
            }

            val iconView = ImageView(this).apply {
                setImageResource(opt.iconRes)
                setBackgroundResource(R.drawable.bg_channel_logo_frame)
                setPadding(dp(6), dp(6), dp(6), dp(6))
                scaleType = ImageView.ScaleType.FIT_CENTER
                layoutParams = LinearLayout.LayoutParams(dp(36), dp(36))
            }
            rowCard.addView(iconView)

            val textCol = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = dp(11)
                    marginEnd = dp(8)
                }
            }
            val tvRowTitle = TextView(this).apply {
                text = opt.title
                textSize = 13.5f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.WHITE)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }
            val tvRowSub = TextView(this).apply {
                text = opt.subtitle
                textSize = 11f
                setTextColor(if (opt.isHighlighted) Color.parseColor("#FEF08A") else Color.parseColor("#CBD5E1"))
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
            }
            textCol.addView(tvRowTitle)
            textCol.addView(tvRowSub)
            rowCard.addView(textCol)

            if (opt.badgeText.isNotBlank()) {
                val badge = TextView(this).apply {
                    text = opt.badgeText
                    textSize = 10.5f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(if (opt.isHighlighted) Color.parseColor("#6EE7B7") else Color.parseColor("#38BDF8"))
                    setBackgroundResource(
                        if (opt.isHighlighted) R.drawable.bg_live_dot_pill else R.drawable.bg_badge_neon
                    )
                    setPadding(dp(9), dp(4), dp(9), dp(4))
                }
                rowCard.addView(badge)
            }

            if (firstFocusableRow == null || opt.isHighlighted) {
                firstFocusableRow = rowCard
            }
            listContainer.addView(rowCard)
        }

        scroll.addView(listContainer)
        rootCard.addView(scroll)

        scroll.post {
            if (scroll.height > maxScrollHeight) {
                scroll.layoutParams = (scroll.layoutParams as LinearLayout.LayoutParams).apply {
                    height = maxScrollHeight
                }
            }
        }

        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        footer.addView(
            create4dActionCapsuleButton(closeLabel, R.drawable.bg_btn_3d_slate) {
                dialogRef?.dismiss()
            }
        )
        rootCard.addView(footer)

        dialogRef = present4dGlassDialog(rootCard, widthDp = 560)
        firstFocusableRow?.post { firstFocusableRow?.requestFocus() }
    }

    private fun show4dGlassFormModal(
        headerIconRes: Int,
        title: String,
        subtitle: String,
        badgeText: String,
        fields: List<GlassFormFieldSpec>,
        neutralLabel: String? = null,
        neutralBgRes: Int = R.drawable.bg_btn_3d_emerald,
        neutralIconRes: Int = 0,
        onNeutral: (() -> Unit)? = null,
        positiveLabel: String,
        positiveBgRes: Int = R.drawable.bg_btn_3d_cyan,
        positiveIconRes: Int = 0,
        onSubmit: (List<String>) -> Unit
    ) {
        var dialogRef: AlertDialog? = null
        val rootCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_dialog_4d_glass)
            setPadding(dp(18), dp(16), dp(18), dp(16))
        }

        rootCard.addView(build4dModalHeader(headerIconRes, title, subtitle, badgeText))

        val formBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(12)
                bottomMargin = dp(14)
            }
        }

        val editTexts = ArrayList<EditText>(fields.size)
        fields.forEachIndexed { idx, spec ->
            val lbl = TextView(this).apply {
                text = spec.label
                textSize = 10.5f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#7DD3FC"))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    if (idx > 0) topMargin = dp(8)
                    bottomMargin = dp(4)
                }
            }
            formBox.addView(lbl)

            val et = EditText(this).apply {
                hint = spec.hint
                setText(spec.initialValue)
                setSingleLine(true)
                inputType = spec.inputType
                textSize = 13f
                setTextColor(Color.WHITE)
                setHintTextColor(Color.parseColor("#94A3B8"))
                setBackgroundResource(R.drawable.bg_glass_input_4d)
                setPadding(dp(12), dp(10), dp(12), dp(10))
                setCompoundDrawablesWithIntrinsicBounds(spec.iconRes, 0, 0, 0)
                compoundDrawablePadding = dp(10)
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    dp(44)
                )
            }
            editTexts.add(et)
            formBox.addView(et)
        }
        rootCard.addView(formBox)

        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        if (!neutralLabel.isNullOrBlank() && onNeutral != null) {
            val neutralBtn = create4dActionCapsuleButton(neutralLabel, neutralBgRes, neutralIconRes) {
                dialogRef?.dismiss()
                onNeutral()
            }.apply {
                (layoutParams as LinearLayout.LayoutParams).marginStart = 0
            }
            footer.addView(neutralBtn)
        }

        val spacer = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }
        footer.addView(spacer)

        footer.addView(
            create4dActionCapsuleButton("Cancel", R.drawable.bg_btn_3d_slate) {
                dialogRef?.dismiss()
            }
        )
        footer.addView(
            create4dActionCapsuleButton(positiveLabel, positiveBgRes, positiveIconRes) {
                val values = editTexts.map { it.text?.toString()?.trim().orEmpty() }
                dialogRef?.dismiss()
                onSubmit(values)
            }
        )
        rootCard.addView(footer)

        dialogRef = present4dGlassDialog(rootCard, widthDp = 540)
        editTexts.firstOrNull()?.post { editTexts.firstOrNull()?.requestFocus() }
    }

    private fun applyVideoQualitySelection(
        player: ExoPlayer,
        size: Pair<Int, Int>?,
        label: String,
        silent: Boolean = false
    ) {
        val builder = player.trackSelectionParameters.buildUpon()
            .clearOverridesOfType(C.TRACK_TYPE_VIDEO)
            .clearViewportSizeConstraints()
            .setMaxVideoBitrate(Int.MAX_VALUE)
            .setForceHighestSupportedBitrate(true)

        if (size == null) {
            if (isLowRamTvDevice) {
                builder.setMaxVideoSize(1920, 1080)
            } else {
                builder.clearVideoSizeConstraints()
            }
            player.trackSelectionParameters = builder.build()
            updateLiveTelemetryBadge(player)
            if (!silent) {
                Toast.makeText(this, "Video Quality set to Auto (Best HD)", Toast.LENGTH_SHORT).show()
            }
            return
        }

        val targetWidth = size.first
        val targetHeight = size.second
        builder.setMaxVideoSize(targetWidth, targetHeight)

        // Actively find & lock the best supported video track for the chosen resolution
        var bestUnderOrEqual: Triple<Tracks.Group, Int, androidx.media3.common.Format>? = null
        var lowestAbove: Triple<Tracks.Group, Int, androidx.media3.common.Format>? = null

        for (group in player.currentTracks.groups) {
            if (group.type != C.TRACK_TYPE_VIDEO) continue
            for (tIdx in 0 until group.length) {
                if (!group.isTrackSupported(tIdx)) continue
                val fmt = group.getTrackFormat(tIdx)
                val h = fmt.height
                if (h <= 0) continue
                if (h <= targetHeight + 24) {
                    val prev = bestUnderOrEqual?.third
                    if (prev == null || h > prev.height || (h == prev.height && fmt.bitrate > prev.bitrate)) {
                        bestUnderOrEqual = Triple(group, tIdx, fmt)
                    }
                } else {
                    val prev = lowestAbove?.third
                    if (prev == null || h < prev.height || (h == prev.height && fmt.bitrate < prev.bitrate)) {
                        lowestAbove = Triple(group, tIdx, fmt)
                    }
                }
            }
        }

        val chosen = bestUnderOrEqual ?: lowestAbove
        if (chosen != null) {
            // Clear size ceiling when applying explicit override so the chosen track is never filtered out
            builder.clearVideoSizeConstraints()
            builder.addOverride(TrackSelectionOverride(chosen.first.mediaTrackGroup, listOf(chosen.second)))
        }

        player.trackSelectionParameters = builder.build()
        updateLiveTelemetryBadge(player)
        if (!silent) {
            val actualMsg = if (chosen != null) "${chosen.third.height}p (${chosen.third.width}x${chosen.third.height})" else label
            Toast.makeText(this, "📺 Video Quality locked: $actualMsg", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showAudioAndQualityDialog() {
        val player = exoPlayer ?: return
        val options = ArrayList<GlassModalOption>(14)

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_speed_bolt,
                title = "Sync to Live Broadcast Edge",
                subtitle = "Jump directly to real-time live edge with zero delay",
                badgeText = "ZERO DELAY",
                isHighlighted = false
            ) {
                player.seekToDefaultPosition()
                player.prepare()
                player.playWhenReady = true
                Toast.makeText(this, "⚡ Synced to real-time live edge!", Toast.LENGTH_SHORT).show()
            }
        )



        val currentEngineMode = if (::profileStore.isInitialized) profileStore.getLiveTvEngineMode() else LiveTvEngineMode.AUTO_OTT_HEAL
        val activeEngineTag = if (isLiveTvUsingLibVlc) {
            if (liveTvVlcEngine?.isSoftwareMode() == true) "OTT-VLC SW" else "OTT-VLC HW"
        } else {
            "MEDIA3"
        }
        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_rocket,
                title = "🚀 Live TV Engine: ${currentEngineMode.displayLabel}",
                subtitle = "Active now: $activeEngineTag • Tap to switch Auto / OTT LibVLC HW / LibVLC Software / Media3 (fixes Sony Max, Zee Cinema, Star Gold AC3 & 1080i50)",
                badgeText = activeEngineTag,
                isHighlighted = isLiveTvUsingLibVlc
            ) {
                showLiveTvEngineSelectorDialog()
            }
        )

        if (isLiveTvUsingLibVlc) {
            val vlcTracks = liveTvVlcEngine?.getAudioTracks().orEmpty()
            for (vt in vlcTracks) {
                options.add(
                    GlassModalOption(
                        iconRes = R.drawable.ic_3d_audio_hd,
                        title = "🔊 OTT-VLC Audio: ${vt.name}",
                        subtitle = "FFmpeg AC3/E-AC3/DTS/AAC software audio track",
                        badgeText = if (vt.isSelected) "ACTIVE ✓" else "TRACK",
                        isHighlighted = vt.isSelected
                    ) {
                        liveTvVlcEngine?.selectAudioTrack(vt.id)
                        liveVlcAudioSummary = vt.name.take(18)
                        updateLiveVlcTelemetryBadge()
                        Toast.makeText(this, "🔊 Switched audio: ${vt.name}", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }

        val qualities = listOf(
            Triple("Video Quality: Auto (Best HD)", "Automatically locks highest supported HD / Full HD track", null as Pair<Int, Int>?),
            Triple("Video Quality: 1080p Full HD", "1920x1080 • Forces Full HD 1080p track when available", 1920 to 1080),
            Triple("Video Quality: 720p HD", "1280x720 • Forces 720p HD track when available", 1280 to 720),
            Triple("Video Quality: 480p SD", "854x480 • Fast Zap & Mobile Data Saver", 854 to 480),
            Triple("Video Quality: 360p Eco", "640x360 • Ultra Low Bandwidth Mode", 640 to 360)
        )
        for ((titleText, subText, size) in qualities) {
            val tagKey = if (size == null) "Auto" else "${size.second}p"
            val isCurrent = selectedQualityLabel == tagKey
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_video_4k,
                    title = titleText,
                    subtitle = subText,
                    badgeText = if (isCurrent) "ACTIVE ✓" else tagKey.uppercase(Locale.ROOT),
                    isHighlighted = isCurrent
                ) {
                    selectedQualityMaxSize = size
                    selectedQualityLabel = tagKey
                    profileStore.setPreferredVideoQuality(tagKey)
                    lastAutoQualityAppliedStreamUrl = currentPlayingStreamUrl
                    applyVideoQualitySelection(player, size, tagKey, silent = false)
                }
            )
        }

        // Also list actual live stream video tracks (exact OTT Navigator-style resolution picker)
        val streamVideoTracks = ArrayList<Triple<Tracks.Group, Int, androidx.media3.common.Format>>()
        for (group in player.currentTracks.groups) {
            if (group.type == C.TRACK_TYPE_VIDEO) {
                for (tIdx in 0 until group.length) {
                    if (group.isTrackSupported(tIdx)) {
                        val fmt = group.getTrackFormat(tIdx)
                        if (fmt.height > 0) {
                            streamVideoTracks.add(Triple(group, tIdx, fmt))
                        }
                    }
                }
            }
        }
        streamVideoTracks
            .sortedWith(compareByDescending<Triple<Tracks.Group, Int, androidx.media3.common.Format>> { it.third.height }.thenByDescending { it.third.bitrate })
            .distinctBy { "${it.third.width}x${it.third.height}_${it.third.bitrate / 200_000}" }
            .take(8)
            .forEach { (group, tIdx, fmt) ->
                val selectedNow = group.isTrackSelected(tIdx)
                val mbps = if (fmt.bitrate > 0) String.format(Locale.US, " • %.1f Mbps", fmt.bitrate / 1_000_000.0) else ""
                val fps = if (fmt.frameRate > 0f) " • ${fmt.frameRate.toInt()}fps" else ""
                options.add(
                    GlassModalOption(
                        iconRes = R.drawable.ic_3d_video_4k,
                        title = "📺 Direct Track: ${fmt.height}p (${fmt.width}x${fmt.height})",
                        subtitle = "Lock this exact stream quality$mbps$fps",
                        badgeText = if (selectedNow) "PLAYING ✓" else "${fmt.height}P",
                        isHighlighted = selectedNow
                    ) {
                        selectedQualityMaxSize = fmt.width to fmt.height
                        selectedQualityLabel = "${fmt.height}p"
                        lastAutoQualityAppliedStreamUrl = currentPlayingStreamUrl
                        val params = player.trackSelectionParameters.buildUpon()
                            .clearOverridesOfType(C.TRACK_TYPE_VIDEO)
                            .clearVideoSizeConstraints()
                            .clearViewportSizeConstraints()
                            .setMaxVideoBitrate(Int.MAX_VALUE)
                            .setForceHighestSupportedBitrate(true)
                            .addOverride(TrackSelectionOverride(group.mediaTrackGroup, listOf(tIdx)))
                            .build()
                        player.trackSelectionParameters = params
                        updateLiveTelemetryBadge(player)
                        Toast.makeText(this, "📺 Locked ${fmt.height}p (${fmt.width}x${fmt.height})", Toast.LENGTH_SHORT).show()
                    }
                )
            }

        val tunnelingOn = profileStore.isVideoTunnelingEnabled()
        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_rocket,
                title = "🎬 TV Hardware Video Tunneling: ${if (tunnelingOn) "ON ✓" else "OFF"}",
                subtitle = "Smoother 1080p/4K AV sync on supported Android TVs (turn OFF if screen goes black on 512MB box)",
                badgeText = if (tunnelingOn) "ON ✓" else "OFF",
                isHighlighted = tunnelingOn
            ) {
                val nextVal = !tunnelingOn
                profileStore.setVideoTunnelingEnabled(nextVal)
                trackSelector?.let { sel ->
                    sel.setParameters(sel.buildUponParameters().setTunnelingEnabled(nextVal))
                }
                Toast.makeText(this, "Hardware Video Tunneling: ${if (nextVal) "ON" else "OFF"}", Toast.LENGTH_SHORT).show()
                showAudioAndQualityDialog()
            }
        )

        val subDelay = profileStore.getSubtitleDelayMs(activeAccountScope)
        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_subtitles,
                title = "⏱️ Subtitle Delay: +${subDelay}ms (Fine +100ms / Reset)",
                subtitle = "Generation-safe cue delay (auto-cancels on seek/pause/zap) • Tap for +100ms, or reset below",
                badgeText = "+${subDelay}ms",
                isHighlighted = subDelay > 0
            ) {
                val nextSub = if (subDelay >= 3000) 0 else (subDelay + 100).coerceAtMost(3000)
                profileStore.setSubtitleDelayMs(nextSub, activeAccountScope)
                cancelPendingDelayedSubtitles()
                Toast.makeText(this, "Subtitle delay: +${nextSub}ms", Toast.LENGTH_SHORT).show()
                showAudioAndQualityDialog()
            }
        )
        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_subtitles,
                title = "⏱️ Subtitle Delay Coarse (+500ms) / Reset to 0ms",
                subtitle = if (subDelay > 0) "Tap to jump +500ms (cycles back to 0ms after 3000ms)" else "Currently 0ms (synced)",
                badgeText = if (subDelay > 0) "COARSE" else "0ms"
            ) {
                val nextSub = if (subDelay >= 3000) 0 else (subDelay + 500).coerceAtMost(3000)
                profileStore.setSubtitleDelayMs(nextSub, activeAccountScope)
                cancelPendingDelayedSubtitles()
                showAudioAndQualityDialog()
            }
        )

        val audDelay = profileStore.getAudioDelayMs(activeAccountScope)
        val pcmActive = audioDelayProcessor.isPcmActive()
        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_audio_hd,
                title = "🎚️ Real PCM Audio Delay: +${audDelay}ms (Fine +25ms)",
                subtitle = if (pcmActive) {
                    "Active on Media3 AudioDelayProcessor (0–500ms live PCM ring buffer) • Tap for +25ms"
                } else {
                    "Saved (+${audDelay}ms); applies automatically to PCM streams (hardware bitstream passthrough bypasses PCM)"
                },
                badgeText = if (pcmActive) "+${audDelay}ms LIVE" else "+${audDelay}ms",
                isHighlighted = audDelay > 0
            ) {
                val nextAud = if (audDelay >= 500) 0 else (audDelay + 25).coerceAtMost(500)
                profileStore.setAudioDelayMs(nextAud, activeAccountScope)
                audioDelayProcessor.setDelayMs(nextAud)
                Toast.makeText(this, "Audio delay set to +${nextAud}ms", Toast.LENGTH_SHORT).show()
                showAudioAndQualityDialog()
            }
        )
        if (audDelay > 0) {
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_sync,
                    title = "↺ Reset Audio & Subtitle Delays to 0ms",
                    subtitle = "Immediately reset both audio (+${audDelay}ms) and subtitle (+${subDelay}ms) offsets",
                    badgeText = "RESET 0ms"
                ) {
                    profileStore.setAudioDelayMs(0, activeAccountScope)
                    profileStore.setSubtitleDelayMs(0, activeAccountScope)
                    audioDelayProcessor.setDelayMs(0)
                    cancelPendingDelayedSubtitles()
                    Toast.makeText(this, "Audio & Subtitle delays reset to 0ms", Toast.LENGTH_SHORT).show()
                    showAudioAndQualityDialog()
                }
            )
        }

        val supportedCodecs = detectSupportedPassthroughCodecs()
        val offloadOn = profileStore.isAudioOffloadEnabled(activeAccountScope)
        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_audio_hd,
                title = if (supportedCodecs.isEmpty()) "🔇 Hardware Bitstream Passthrough: Not Supported" else "🔊 Hardware Bitstream Capabilities: ${supportedCodecs.joinToString("/")}",
                subtitle = if (supportedCodecs.isEmpty()) {
                    "TV audio output reports PCM stereo only (AC3/DTS/TrueHD passthrough unavailable)"
                } else {
                    "Verified via AudioManager.getDevices: ${supportedCodecs.joinToString(", ")} (separate from Audio Offload)"
                },
                badgeText = if (supportedCodecs.isEmpty()) "PCM ONLY" else "VERIFIED ✓"
            ) {}
        )
        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_audio_hd,
                title = "⚡ Media3 Audio Offload: ${if (offloadOn && supportedCodecs.isNotEmpty()) "ENABLED" else "DISABLED"}",
                subtitle = if (supportedCodecs.isEmpty()) {
                    "Disabled automatically — device reports no hardware offload/passthrough codecs"
                } else {
                    "Uses TrackSelectionParameters.AudioOffloadPreferences (disables PCM Audio Delay when active)"
                },
                badgeText = if (supportedCodecs.isEmpty()) "UNSUPPORTED" else if (offloadOn) "ON ✓" else "OFF",
                isHighlighted = offloadOn && supportedCodecs.isNotEmpty()
            ) {
                if (supportedCodecs.isEmpty()) {
                    Toast.makeText(this, "Audio Offload/Passthrough not supported on this TV hardware", Toast.LENGTH_SHORT).show()
                } else {
                    val nextOffload = !offloadOn
                    profileStore.setAudioOffloadEnabled(nextOffload, activeAccountScope)
                    applyAudioPassthroughPreference(player)
                    Toast.makeText(this, if (nextOffload) "Media3 Audio Offload enabled" else "Media3 Audio Offload disabled", Toast.LENGTH_SHORT).show()
                    showAudioAndQualityDialog()
                }
            }
        )

        // v21.0 Genuine Audio Diagnostics, Preferred Language, Audio Boost & Audio Reset
        inspectAndRecoverAudioTracks(player, allowAutoRecovery = false)
        val audDiag = lastAudioDiagnostics
        val diagTitle = when {
            audDiag == null -> "🔊 Audio Diagnostics: Inspecting..."
            audDiag.failureReason == AudioFailureReason.NONE -> "🔊 Audio Active: ${audDiag.selectedTrack?.shortCodecName() ?: "PCM"} (${audDiag.selectedTrack?.channelLayoutLabel() ?: "Stereo"})"
            else -> "⚠️ Audio Issue: ${audDiag.failureReason.label}"
        }
        val diagSubtitle = if (audDiag != null) {
            val sr = audDiag.selectedTrack?.sampleRateHz?.takeIf { it > 0 }?.let { "${it / 1000}kHz" } ?: "N/A"
            val lang = audDiag.selectedTrack?.language?.uppercase(Locale.ROOT)?.ifBlank { "UND" } ?: "None"
            "Detected: ${if (audDiag.audioDetected) "${audDiag.supportedTracks}/${audDiag.totalTracks} supported" else "No"} • Lang: $lang • Rate: $sr • Decoder: ${audDiag.decoderStatus} • Out: ${audDiag.outputCapability} • Recovery: ${audDiag.recoveryStatus}"
        } else {
            "Tap to run audio track inspection & recovery"
        }
        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_audio_hd,
                title = diagTitle,
                subtitle = diagSubtitle,
                badgeText = audDiag?.osdShortBadge() ?: "DIAG",
                isHighlighted = audDiag?.failureReason != AudioFailureReason.NONE
            ) {
                audioRecoveryAttemptsForChannel = 0
                inspectAndRecoverAudioTracks(player, allowAutoRecovery = true)
                Toast.makeText(this, "Audio check: ${lastAudioDiagnostics?.decoderStatus ?: "Done"}", Toast.LENGTH_SHORT).show()
                showAudioAndQualityDialog()
            }
        )

        val prefLang = profileStore.getGlobalPreferredAudioLanguage(activeAccountScope)
        val prefLangLabel = when (prefLang) {
            "hi" -> "Hindi → English → Auto"
            "en" -> "English → Hindi → Auto"
            else -> "Auto (${prefLang.uppercase(Locale.ROOT)})"
        }
        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_audio_hd,
                title = "🌐 Preferred Audio Language: $prefLangLabel",
                subtitle = "Profile-aware default audio priority (never selects unsupported tracks)",
                badgeText = prefLang.uppercase(Locale.ROOT)
            ) {
                val nextLang = when (prefLang) {
                    "hi" -> "en"
                    "en" -> "auto"
                    else -> "hi"
                }
                profileStore.setGlobalPreferredAudioLanguage(nextLang, activeAccountScope)
                val langs = when (nextLang) {
                    "en" -> arrayOf("en", "eng", "hi", "hin")
                    "auto" -> arrayOf("hi", "hin", "en", "eng")
                    else -> arrayOf("hi", "hin", "en", "eng")
                }
                player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                    .setPreferredAudioLanguages(*langs)
                    .build()
                Toast.makeText(this, "Preferred audio language saved: ${nextLang.uppercase(Locale.ROOT)}", Toast.LENGTH_SHORT).show()
                showAudioAndQualityDialog()
            }
        )

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_sync,
                title = "↺ Reset All Audio Settings",
                subtitle = "Reset preferred language, delay (0ms), boost (0dB), passthrough & offload",
                badgeText = "RESET"
            ) {
                profileStore.resetAudioSettings(activeAccountScope)
                audioDelayProcessor.setDelayMs(0)
                applyAudioLoudnessBoost(0)
                applyAudioPassthroughPreference(player)
                player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                    .clearOverridesOfType(C.TRACK_TYPE_AUDIO)
                    .setPreferredAudioLanguages("hi", "hin", "en", "eng")
                    .build()
                Toast.makeText(this, "All audio settings reset to safe defaults", Toast.LENGTH_SHORT).show()
                showAudioAndQualityDialog()
            }
        )

        val panelHdr = detectDisplayHdrTypes()
        val streamHdr = detectActiveStreamHdrLabel(player.videoFormat)
        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_video_4k,
                title = "✨ Video Format & HDR: Stream=$streamHdr • TV=$panelHdr",
                subtitle = "Verified directly from Media3 ColorInfo & Display.HdrCapabilities (zero fake HDR claims)",
                badgeText = streamHdr
            ) {}
        )

        val tracks: Tracks = player.currentTracks
        var audioIndex = 1
        val currentChId = allChannels.getOrNull(currentChannelIndex)?.id
        for (group in tracks.groups) {
            if (group.type == C.TRACK_TYPE_AUDIO && group.isSupported) {
                for (i in 0 until group.length) {
                    val format = group.getTrackFormat(i)
                    val rawLang = format.language
                    val lang = rawLang?.let { Locale(it).displayLanguage }?.ifBlank { null } ?: "Track $audioIndex"
                    val label = format.label?.takeIf { it.isNotBlank() } ?: "Broadcast Audio"
                    val chCount = if (format.channelCount > 0) "${format.channelCount}ch" else "Stereo"
                    val isSelected = group.isTrackSelected(i)
                    val trackGroup = group.mediaTrackGroup
                    val trackIdx = i
                    options.add(
                        GlassModalOption(
                            iconRes = R.drawable.ic_3d_audio_hd,
                            title = "Audio Track $audioIndex: $lang",
                            subtitle = "$label • $chCount • Auto-saved for this channel",
                            badgeText = if (isSelected) "PLAYING ✓" else chCount.uppercase(Locale.ROOT),
                            isHighlighted = isSelected
                        ) {
                            player.trackSelectionParameters = player.trackSelectionParameters
                                .buildUpon()
                                .setOverrideForType(TrackSelectionOverride(trackGroup, trackIdx))
                                .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, false)
                                .build()
                            if (!currentChId.isNullOrBlank() && !rawLang.isNullOrBlank()) {
                                profileStore.setPreferredAudioLanguage(currentChId, rawLang)
                            }
                            Toast.makeText(this, "Switched to $lang $label (Saved for channel)", Toast.LENGTH_SHORT).show()
                        }
                    )
                    audioIndex++
                }
            }
        }

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_subtitles,
                title = "Subtitles / Closed Captions",
                subtitle = "Toggle DVB / CEA-608 / WebVTT live broadcast & VOD subtitles",
                badgeText = if (subtitlesEnabled) "ON ✓" else "OFF",
                isHighlighted = subtitlesEnabled
            ) {
                subtitlesEnabled = !subtitlesEnabled
                player.trackSelectionParameters = player.trackSelectionParameters
                    .buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !subtitlesEnabled)
                    .build()
                Toast.makeText(
                    this,
                    if (subtitlesEnabled) "Subtitles Enabled" else "Subtitles Disabled",
                    Toast.LENGTH_SHORT
                ).show()
            }
        )

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_subtitles,
                title = "Subtitle Size & Color Style",
                subtitle = "Customize subtitle font size and high-contrast caption colors",
                badgeText = "STYLE"
            ) {
                showSubtitleStyleDialog()
            }
        )

        val curBoostMb = if (::profileStore.isInitialized) profileStore.getAudioBoostDb() else 0
        val boostLabel = when (curBoostMb) {
            300 -> "+3 dB (Gentle Boost)"
            600 -> "+6 dB (Clear Dialogue)"
            900 -> "+9 dB (Max TV Boost)"
            else -> "0 dB (Normal)"
        }
        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_audio_hd,
                title = "TV Audio Dialogue Boost: $boostLabel",
                subtitle = "Amplify quiet IPTV / movie dialogue using hardware LoudnessEnhancer",
                badgeText = "${curBoostMb / 100} dB"
            ) {
                val nextMb = when (curBoostMb) {
                    0 -> 300
                    300 -> 600
                    600 -> 900
                    else -> 0
                }
                profileStore.setAudioBoostDb(nextMb)
                applyAudioLoudnessBoost(nextMb)
                showAudioAndQualityDialog()
            }
        )

        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_audio_hd,
            title = "Audio Tracks, Video Quality & Subtitles",
            subtitle = "Real-Time Media3 Track Engine • ${liveResolutionLabel}${if (liveTelemetryDetail.isNotEmpty()) " • $liveTelemetryDetail" else ""}",
            badgeText = selectedQualityLabel.uppercase(Locale.ROOT),
            options = options,
            closeLabel = "Close"
        )
    }

    private fun showPerformanceModeDialog() {
        val options = PerformanceMode.values().map { mode ->
            val isCur = mode == activePerformanceMode
            GlassModalOption(
                iconRes = when (mode) {
                    PerformanceMode.AUTO_ADAPTIVE -> R.drawable.ic_3d_rocket
                    PerformanceMode.FAST_ZAPPING -> R.drawable.ic_3d_speed_bolt
                    PerformanceMode.LOW_MEMORY -> R.drawable.ic_3d_ram_gauge
                    PerformanceMode.NETWORK_SAVER -> R.drawable.ic_3d_network
                    PerformanceMode.SMART_BALANCED -> R.drawable.ic_3d_rocket
                    PerformanceMode.HIGH_PERFORMANCE_4GB -> R.drawable.ic_3d_rocket
                },
                title = mode.title,
                subtitle = mode.subtitle,
                badgeText = if (isCur) "ACTIVE ✓" else "${mode.focusDebounceMs}ms",
                isHighlighted = isCur
            ) {
                activePerformanceMode = mode
                StreamPreFetcher.setPerformanceMode(mode)
                if (::profileStore.isInitialized) {
                    profileStore.setPerformanceMode(mode)
                }
                if (mode == PerformanceMode.LOW_MEMORY) {
                    runCatching { Glide.get(this).clearMemory() }
                    ChannelCacheStore.trimMemoryCache()
                }
                val targetBuf = BufferProfile.fromId(mode.recommendedBufferProfileId, isLowRamTvDevice)
                if (targetBuf != activeBufferProfile) {
                    activeBufferProfile = targetBuf
                    getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
                        .edit()
                        .putString("buffer_profile_id", targetBuf.id)
                        .apply()
                    initializeMedia3ProEngine(recreateIfPresent = true)
                }
                Toast.makeText(this, "⚡ Performance Mode: ${mode.title}", Toast.LENGTH_SHORT).show()
            }
        }

        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_rocket,
            title = "Performance Modes & Smart Low-Memory Guard (v18.1)",
            subtitle = "Adaptive preload, conservative poster decoding & memory profiles for Android TV",
            badgeText = activePerformanceMode.id,
            options = options,
            closeLabel = "Back"
        )
    }

    private fun showBufferProfileDialog() {
        val options = BufferProfile.values().map { p ->
            val isCur = p == activeBufferProfile
            GlassModalOption(
                iconRes = if (p == BufferProfile.LOW_LATENCY || p == BufferProfile.ULTRA_FAST_ZAP) {
                    R.drawable.ic_3d_speed_bolt
                } else {
                    R.drawable.ic_3d_ram_gauge
                },
                title = p.label,
                subtitle = p.subtitle,
                badgeText = if (isCur) "ACTIVE ✓" else "${p.playBufferMs}ms",
                isHighlighted = isCur
            ) {
                if (p != activeBufferProfile) {
                    activeBufferProfile = p
                    getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
                        .edit()
                        .putString("buffer_profile_id", p.id)
                        .apply()
                    initializeMedia3ProEngine(recreateIfPresent = true)
                    Toast.makeText(this, "Buffer Profile: ${p.label}", Toast.LENGTH_SHORT).show()
                }
            }
        }

        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_ram_gauge,
            title = "Adaptive Buffer Profiles (512MB Tuned)",
            subtitle = "Choose start speed vs. network cushion for your Smart TV",
            badgeText = "512MB GUARD",
            options = options,
            closeLabel = "Back"
        )
    }

    private fun showThemeAndPipDialog() {
        val options = ArrayList<GlassModalOption>(10)
        themes.forEachIndexed { idx, t ->
            val isCur = idx == currentThemeIndex
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_theme,
                    title = "4D Theme: ${t.name}",
                    subtitle = t.subtitle,
                    badgeText = if (isCur) "ACTIVE ✓" else "APPLY",
                    isHighlighted = isCur
                ) {
                    applyTheme(idx)
                    getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
                        .edit()
                        .putInt("theme_index", idx)
                        .apply()
                    Toast.makeText(this, "4D Theme applied: ${t.name}", Toast.LENGTH_SHORT).show()
                }
            )
        }

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_pip,
                title = "Enter Picture-in-Picture (PiP Mini Player)",
                subtitle = "Continue watching live TV in a floating corner window",
                badgeText = "MINI TV"
            ) {
                enterPipModeSafe()
            }
        )

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_aspect,
                title = "Cycle Screen Aspect Ratio (Fit / Stretch / Zoom)",
                subtitle = "Adjust video scaling for 16:9 or ultra-wide television screens",
                badgeText = "ASPECT"
            ) {
                currentResizeIndex = (currentResizeIndex + 1) % resizeModes.size
                playerView.resizeMode = resizeModes[currentResizeIndex]
        liveTvVlcEngine?.setAspectRatioByResizeIndex(currentResizeIndex)
                Toast.makeText(
                    this,
                    when (currentResizeIndex) {
                        0 -> "Aspect: 16:9 Fit"
                        1 -> "Aspect: Full Stretch"
                        else -> "Aspect: Cinema Zoom"
                    },
                    Toast.LENGTH_SHORT
                ).show()
            }
        )

        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_theme,
            title = "4D Studio Visual Themes & PiP",
            subtitle = "Crystal Glass color palettes & Picture-in-Picture mini player (All settings are in the Settings icon)",
            badgeText = "4D THEMES",
            options = options,
            closeLabel = "Close"
        )
    }

    private fun showSubtitleStyleDialog() {
        val styles = listOf(
            Triple("Standard White on Translucent Black", Color.WHITE, Color.parseColor("#B3000000")),
            Triple("High-Contrast Yellow on Black", Color.parseColor("#FDE047"), Color.parseColor("#E6000000")),
            Triple("Neon Cyan Crystal Captions", Color.parseColor("#38BDF8"), Color.parseColor("#CC071022"))
        )
        val options = ArrayList<GlassModalOption>(6)
        for ((label, fg, bg) in styles) {
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_subtitles,
                    title = "Color: $label",
                    subtitle = "Apply high-visibility subtitle color palette",
                    badgeText = "APPLY"
                ) {
                    playerView.subtitleView?.setStyle(
                        CaptionStyleCompat(fg, bg, Color.TRANSPARENT, CaptionStyleCompat.EDGE_TYPE_OUTLINE, Color.BLACK, null)
                    )
                    Toast.makeText(this, "Subtitle style: $label", Toast.LENGTH_SHORT).show()
                }
            )
        }
        for ((sizeName, sp) in listOf("Small (16sp)" to 16f, "Standard TV (20sp)" to 20f, "Large TV (26sp)" to 26f, "Extra Large (32sp)" to 32f)) {
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_subtitles,
                    title = "Font Size: $sizeName",
                    subtitle = "Adjust subtitle readability for television viewing distance",
                    badgeText = "${sp.toInt()}sp"
                ) {
                    playerView.subtitleView?.setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
                    Toast.makeText(this, "Subtitle size: $sizeName", Toast.LENGTH_SHORT).show()
                }
            )
        }
        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_subtitles,
            title = "Subtitle Size & Color Customization",
            subtitle = "Applied immediately to active Media3 subtitles",
            badgeText = "CAPTIONS",
            options = options,
            closeLabel = "Back"
        )
    }

    private fun showParentalPinSettingsDialog() {
        val currentPin = profileStore.getParentalPin()
        val currentCat = allChannels.getOrNull(currentChannelIndex)?.category ?: "General"
        val isCatLocked = profileStore.getLockedCategories().any { it.equals(currentCat, ignoreCase = true) }

        val options = listOf(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_lock,
                title = if (currentPin.length == 4) "Change 4-Digit Parental PIN" else "Set 4-Digit Parental PIN",
                subtitle = "Create or update your 4-digit category security code",
                badgeText = if (currentPin.length == 4) "ACTIVE ✓" else "SET PIN",
                isHighlighted = currentPin.length == 4
            ) {
                show4dGlassFormModal(
                    headerIconRes = R.drawable.ic_3d_lock,
                    title = "Set 4-Digit Parental PIN",
                    subtitle = "Enter exactly 4 numeric digits to lock restricted categories",
                    badgeText = "SECURITY",
                    fields = listOf(
                        GlassFormFieldSpec(
                            label = "4-DIGIT PARENTAL PIN CODE",
                            hint = "Enter 4-digit PIN (e.g. 1234)",
                            iconRes = R.drawable.ic_3d_lock,
                            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
                        )
                    ),
                    positiveLabel = "Save PIN",
                    positiveBgRes = R.drawable.bg_btn_3d_gold,
                    positiveIconRes = R.drawable.ic_3d_lock
                ) { values ->
                    val pin = values.firstOrNull().orEmpty()
                    if (pin.length == 4 && pin.all { it.isDigit() }) {
                        profileStore.setParentalPin(pin)
                        unlockedSessionCategories.clear()
                        Toast.makeText(this, "🔒 4-Digit Parental PIN Enabled!", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Please enter exactly 4 digits", Toast.LENGTH_SHORT).show()
                    }
                }
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_category,
                title = "Lock / Unlock Category: $currentCat",
                subtitle = "Toggle PIN protection for the currently playing channel's group",
                badgeText = if (isCatLocked) "LOCKED 🔒" else "UNLOCKED",
                isHighlighted = isCatLocked
            ) {
                val locked = profileStore.toggleCategoryLock(currentCat)
                Toast.makeText(
                    this,
                    if (locked) "🔒 Category '$currentCat' Locked" else "🔓 Category '$currentCat' Unlocked",
                    Toast.LENGTH_SHORT
                ).show()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_trash,
                title = "Disable Parental PIN Lock",
                subtitle = "Remove PIN requirement across all channel categories",
                badgeText = "DISABLE"
            ) {
                profileStore.setParentalPin("")
                unlockedSessionCategories.clear()
                Toast.makeText(this, "🔓 Parental PIN Lock Disabled", Toast.LENGTH_SHORT).show()
            }
        )

        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_lock,
            title = "4-Digit Parental PIN Lock",
            subtitle = "Category access control for family-safe television viewing",
            badgeText = if (currentPin.length == 4) "PIN ON" else "PIN OFF",
            options = options,
            closeLabel = "Close"
        )
    }

    private fun promptParentalPinToUnlock(category: String, onUnlocked: () -> Unit) {
        show4dGlassFormModal(
            headerIconRes = R.drawable.ic_3d_lock,
            title = "Locked Category: $category",
            subtitle = "Enter your 4-digit Parental PIN to watch channels in '$category'",
            badgeText = "LOCKED 🔒",
            fields = listOf(
                GlassFormFieldSpec(
                    label = "ENTER 4-DIGIT PARENTAL PIN",
                    hint = "••••",
                    iconRes = R.drawable.ic_3d_lock,
                    inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
                )
            ),
            positiveLabel = "Unlock Category",
            positiveBgRes = R.drawable.bg_btn_3d_gold,
            positiveIconRes = R.drawable.ic_3d_lock
        ) { values ->
            if (profileStore.verifyParentalPin(values.firstOrNull().orEmpty())) {
                unlockedSessionCategories.add(category.lowercase(Locale.ROOT))
                onUnlocked()
            } else {
                Toast.makeText(this, "❌ Incorrect Parental PIN", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun toggleAutoBootSetting() {
        autoBootEnabled = !autoBootEnabled
        getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
            .edit()
            .putBoolean("auto_boot_enabled", autoBootEnabled)
            .apply()
        runCatching {
            val comp = ComponentName(this, BootReceiver::class.java)
            val newState = if (autoBootEnabled) {
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED
            } else {
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED
            }
            packageManager.setComponentEnabledSetting(comp, newState, PackageManager.DONT_KILL_APP)
        }
        Toast.makeText(
            this,
            "🚀 Auto-Start on TV Boot: ${if (autoBootEnabled) "ENABLED" else "DISABLED"}",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun toggleAutoResumeSetting() {
        autoResumeEnabled = !autoResumeEnabled
        getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
            .edit()
            .putBoolean("auto_resume_enabled", autoResumeEnabled)
            .apply()
        Toast.makeText(
            this,
            "▶️ Auto-Resume Last Channel: ${if (autoResumeEnabled) "ENABLED" else "DISABLED"}",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun showPerformanceMonitorDialog() {
        val rt = Runtime.getRuntime()
        val usedHeapMb = (rt.totalMemory() - rt.freeMemory()) / (1024 * 1024)
        val maxHeapMb = (rt.maxMemory() / (1024 * 1024)).coerceAtLeast(1)
        val heapPct = ((usedHeapMb * 100L) / maxHeapMb).toInt().coerceIn(5, 100)
        val nativeHeapMb = Debug.getNativeHeapAllocatedSize() / (1024 * 1024)
        val chCacheKb = channelCache.totalCacheSizeBytes() / 1024
        val epgCacheKb = epgCache.cacheSizeBytes() / 1024

        var dialogRef: AlertDialog? = null
        val rootCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_dialog_4d_glass)
            setPadding(dp(18), dp(16), dp(18), dp(16))
        }

        rootCard.addView(
            build4dModalHeader(
                iconRes = R.drawable.ic_3d_ram_gauge,
                title = "RAM PLAYER v21.0 512MB & Zap Benchmarks",
                subtitle = "Real-Time Memory Footprint, Zapping Stage Timings & Separated Catalogs",
                badgeText = "${usedHeapMb}/${maxHeapMb} MB"
            )
        )

        val gaugeBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_dialog_item_4d)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(10)
            }
        }
        val tvGaugeLabel = TextView(this).apply {
            text = "JVM Heap Memory Pressure: $usedHeapMb MB used of $maxHeapMb MB ($heapPct%) • Native: $nativeHeapMb MB"
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#E0F2FE"))
        }
        val heapBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = heapPct
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(8)
            ).apply {
                topMargin = dp(6)
            }
        }
        gaugeBox.addView(tvGaugeLabel)
        gaugeBox.addView(heapBar)
        rootCard.addView(gaugeBox)

        val benchmarkMetrics = ZapBenchmarkMetrics(
            keyPressToSelectionMs = lastKeyPressToSelectionMs,
            selectionToPrepareMs = lastSelectionToPrepareMs,
            selectionToFirstFrameMs = lastChannelSwitchMs,
            channelSwitchCompletionMs = lastChannelSwitchMs + lastKeyPressToSelectionMs,
            lastBufferingDurationMs = lastBufferingDurationMs,
            prefetchHitRatePercent = StreamPreFetcher.prefetchHitRatePercent(),
            failedPrefetchRatePercent = StreamPreFetcher.failedPrefetchRatePercent()
        )

        val metrics = listOf(
            "Device & Performance Mode" to "${totalDeviceRamMb} MB • ${activePerformanceMode.title}",
            "Active Buffer Profile" to activeBufferProfile.label,
            "Key-Press → Selection / Prep" to "${benchmarkMetrics.keyPressToSelectionMs} ms key → ${benchmarkMetrics.selectionToPrepareMs} ms prep",
            "Selection → First Video Frame" to if (benchmarkMetrics.selectionToFirstFrameMs > 0) "${benchmarkMetrics.selectionToFirstFrameMs} ms (Total: ${benchmarkMetrics.channelSwitchCompletionMs} ms)" else "Instant Ready",
            "Last Buffering Duration" to "${benchmarkMetrics.lastBufferingDurationMs} ms",
            "Prefetch Hit / Fail Rate" to "${benchmarkMetrics.prefetchHitRatePercent}% Hit • ${benchmarkMetrics.failedPrefetchRatePercent}% Fail (${StreamPreFetcher.preloadStatusSummary()})",
            "Separated Catalogs & Cache" to "${allChannels.size} Live TV • ${vodMoviesCatalog.size} VOD Movies • ${seriesCatalogGroups.size} Series • ${chCacheKb}KB SXB2 • ${epgCacheKb}KB EPG"
        )

        val metricsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(8)
                bottomMargin = dp(12)
            }
        }
        for ((k, v) in metrics) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setBackgroundResource(R.drawable.bg_dialog_item_4d)
                setPadding(dp(12), dp(7), dp(12), dp(7))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = dp(5)
                }
            }
            val tvK = TextView(this).apply {
                text = k
                textSize = 11f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#7DD3FC"))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.42f)
            }
            val tvV = TextView(this).apply {
                text = v
                textSize = 11f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.WHITE)
                gravity = Gravity.END
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.58f)
            }
            row.addView(tvK)
            row.addView(tvV)
            metricsContainer.addView(row)
        }
        rootCard.addView(metricsContainer)

        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
        }
        val trimBtn = create4dActionCapsuleButton("Trim RAM Now", R.drawable.bg_btn_3d_emerald, R.drawable.ic_3d_speed_bolt) {
            StreamPreFetcher.trimIdleCacheOnLowMemory()
            ChannelCacheStore.trimMemoryCache()
            sharedAllocator?.trim()
            runCatching { Glide.get(this).clearMemory() }
            dialogRef?.dismiss()
            Toast.makeText(this, "⚡ RAM trimmed & idle buffers freed!", Toast.LENGTH_SHORT).show()
        }
        val closeBtn = create4dActionCapsuleButton("Close", R.drawable.bg_btn_3d_slate) {
            dialogRef?.dismiss()
        }
        footer.addView(trimBtn)
        footer.addView(closeBtn)
        rootCard.addView(footer)

        dialogRef = present4dGlassDialog(rootCard, widthDp = 580)
        trimBtn.post { trimBtn.requestFocus() }
    }

    private fun applyTheme(index: Int) {
        currentThemeIndex = index.coerceIn(themes.indices)
        val palette = themes[currentThemeIndex]
        val badgeTextColor = Color.parseColor(palette.badgeTextHex)
        val statusColor = Color.parseColor(palette.statusHex)

        tvChannelNumber.setTextColor(badgeTextColor)
        tvChannelCategory.setTextColor(statusColor)
        updateTabButton3dSelection(activeTab)
        channelAdapter.setActiveRowDrawable(palette.activeRowDrawableRes)
    }

    private fun enterPipModeSafe() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val params = PictureInPictureParams.Builder()
                    .setAspectRatio(Rational(16, 9))
                    .build()
                enterPictureInPictureMode(params)
            } catch (e: Exception) {
                Log.w("StreamX", "PiP not supported: ${e.message}")
                Toast.makeText(this, "PiP not supported on this device", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "PiP requires Android 8.0+", Toast.LENGTH_SHORT).show()
        }
    }

    private fun forceRefreshActivePlaylist() {
        val creds = activeXtreamCreds
        when {
            activeSourceType == ProfileType.XTREAM && creds != null -> {
                Toast.makeText(this, "🔄 Syncing fresh catalogs from Xtream Server...", Toast.LENGTH_SHORT).show()
                loadXtreamChannels(creds, forceNetworkRefresh = true)
            }
            activeSourceType == ProfileType.M3U && activeM3uInput.isNotBlank() -> {
                Toast.makeText(this, "🔄 Syncing fresh M3U Live TV playlist...", Toast.LENGTH_SHORT).show()
                loadM3uFromInput(activeM3uInput, activeM3uLabel, forceNetworkRefresh = true)
            }
            else -> {
                Toast.makeText(this, "Connect an Xtream or M3U account first to sync", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun toggleCurrentChannelFavorite() {
        if (allChannels.isEmpty()) return
        val ch = allChannels[currentChannelIndex]
        if (favoriteIds.contains(ch.id)) {
            favoriteIds.remove(ch.id)
            Toast.makeText(this, "Removed from ★ Favorites", Toast.LENGTH_SHORT).show()
        } else {
            favoriteIds.add(ch.id)
            Toast.makeText(this, "Added to ★ Favorites!", Toast.LENGTH_SHORT).show()
        }
        getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
            .edit()
            .putStringSet("fav_ids", HashSet(favoriteIds))
            .apply()
        updateFavButtonUi(ch.id)
        if (leftChannelDrawer.visibility == View.VISIBLE) {
            if (activeTab == "FAV") {
                renderDrawerList()
            } else {
                channelAdapter.notifyFavoriteChanged(currentChannelIndex)
            }
        }
    }

    private fun updateFavButtonUi(channelId: String) {
        val isFav = favoriteIds.contains(channelId)
        btnToggleFavorite.text = if (isFav) "★" else "☆"
    }

    private fun renderDrawerList(
        debounceMs: Long = 0L,
        scrollToActive: Boolean = false,
        requestFocusOnActive: Boolean = false
    ) {
        filterJob?.cancel()
        filterJob = lifecycleScope.launch {
            if (debounceMs > 0L) {
                delay(debounceMs)
            }
            val snapshotChannels = allChannels
            val snapshotSeq = allSequentialIndices
            val snapshotByCategory = channelsByCategory
            val snapshotFavs = HashSet(favoriteIds)
            val snapshotRecents = ArrayList(recentIds)
            val snapshotById = channelIndexById
            val tab = activeTab
            val query = searchQuery.trim()
            val category = selectedCategory
            val activeIdx = currentChannelIndex
            val oldIndices = channelAdapter.currentIndices()

            val (filteredAll, pagedSlice, diffResult) = withContext(Dispatchers.Default) {
                val matchAllCat = category == "All categories" || category.isBlank()
                val baseIndices: IntArray = when (tab) {
                    "FAV" -> {
                        val temp = ArrayList<Int>(snapshotFavs.size)
                        for (i in snapshotChannels.indices) {
                            if (snapshotFavs.contains(snapshotChannels[i].id)) temp.add(i)
                        }
                        temp.toIntArray()
                    }
                    "RECENT" -> {
                        val temp = ArrayList<Int>(snapshotRecents.size)
                        for (id in snapshotRecents) {
                            val idx = snapshotById[id]
                            if (idx != null && idx in snapshotChannels.indices) temp.add(idx)
                        }
                        temp.toIntArray()
                    }
                    else -> {
                        if (matchAllCat) {
                            snapshotSeq
                        } else {
                            snapshotByCategory[category.lowercase(Locale.ROOT)] ?: IntArray(0)
                        }
                    }
                }

                val hasHiddenOrCustomSort = (::profileStore.isInitialized && profileStore.getHiddenChannelIds(activeAccountScope).isNotEmpty()) ||
                    activeLiveChannelSortOrder != LiveChannelSortOrder.CHANNEL_NUMBER
                val resultIndices: IntArray = if (!hasHiddenOrCustomSort && query.isEmpty() && (tab == "ALL" || matchAllCat)) {
                    baseIndices
                } else {
                    val hiddenIds = if (::profileStore.isInitialized) {
                        profileStore.getHiddenChannelIds(activeAccountScope)
                    } else emptySet()
                    val blacklistedIds = if (::profileStore.isInitialized) {
                        profileStore.getBlacklistedChannelIds(activeAccountScope)
                    } else emptySet()
                    val temp = ArrayList<Int>(256)
                    for (idx in baseIndices) {
                        if (idx !in snapshotChannels.indices) continue
                        val ch = snapshotChannels[idx]
                        if (hiddenIds.contains(ch.id) || blacklistedIds.contains(ch.id)) continue
                        val catMatches = (tab == "ALL") || matchAllCat || ch.category.equals(category, ignoreCase = true)
                        val queryMatches = query.isEmpty() || SearchIntelligenceEngine.matchesSmartQuery(
                            title = ch.name,
                            categoryOrSubtitle = ch.category,
                            rawQuery = query,
                            channelNumberStr = ch.number.toString()
                        )
                        if (catMatches && queryMatches) {
                            temp.add(idx)
                        }
                    }
                    when (activeLiveChannelSortOrder) {
                        LiveChannelSortOrder.A_TO_Z -> temp.sortBy { snapshotChannels[it].name.lowercase(Locale.ROOT) }
                        LiveChannelSortOrder.Z_TO_A -> temp.sortByDescending { snapshotChannels[it].name.lowercase(Locale.ROOT) }
                        LiveChannelSortOrder.CATEGORY -> temp.sortWith(
                            compareBy<Int> { snapshotChannels[it].category.lowercase(Locale.ROOT) }
                                .thenBy { snapshotChannels[it].number }
                        )
                        LiveChannelSortOrder.RECENTLY_WATCHED -> {
                            val recRank = snapshotRecents.withIndex().associate { it.value to it.index }
                            temp.sortBy { recRank[snapshotChannels[it].id] ?: Int.MAX_VALUE }
                        }
                        LiveChannelSortOrder.CHANNEL_NUMBER -> Unit
                    }
                    temp.toIntArray()
                }

                val activePosInResult = if (scrollToActive) {
                    resultIndices.indexOfFirst { it == activeIdx }
                } else {
                    0
                }
                val requiredWindow = ((activePosInResult + 200).coerceAtLeast(pageStepSize))
                    .coerceAtMost(resultIndices.size)
                val slice = if (resultIndices.size > requiredWindow) {
                    resultIndices.copyOfRange(0, requiredWindow)
                } else {
                    resultIndices
                }

                val diff = if (oldIndices.isNotEmpty() && slice.isNotEmpty() &&
                    oldIndices.size <= 1800 && slice.size <= 1800 && oldIndices !== slice
                ) {
                    DiffUtil.calculateDiff(object : DiffUtil.Callback() {
                        override fun getOldListSize(): Int = oldIndices.size
                        override fun getNewListSize(): Int = slice.size
                        override fun areItemsTheSame(oldPos: Int, newPos: Int): Boolean =
                            oldIndices[oldPos] == slice[newPos]
                        override fun areContentsTheSame(oldPos: Int, newPos: Int): Boolean =
                            oldIndices[oldPos] == slice[newPos]
                    }, false)
                } else {
                    null
                }
                Triple(resultIndices, slice, diff)
            }

            fullFilteredIndices = filteredAll
            currentPagedLimit = pagedSlice.size

            if (pagedSlice.isEmpty()) {
                tvEmptyDrawer.text = if (tab == "FAV") {
                    "★ कोई Favorite चैनल नहीं है। ☆ बटन दबाकर जोड़ें।"
                } else {
                    "कोई चैनल नहीं मिला।"
                }
                tvEmptyDrawer.visibility = View.VISIBLE
                channelListRecycler.visibility = View.GONE
                channelAdapter.submitIndices(IntArray(0), activeIdx, null)
            } else {
                tvEmptyDrawer.visibility = View.GONE
                channelListRecycler.visibility = View.VISIBLE
                channelAdapter.submitIndices(pagedSlice, activeIdx, diffResult, isAscending = (tab != "RECENT"))
                if (scrollToActive) {
                    val pos = pagedSlice.indexOfFirst { it == activeIdx }.coerceAtLeast(0)
                    val lm = channelListRecycler.layoutManager as? LinearLayoutManager
                    lm?.scrollToPositionWithOffset(pos, 120)
                    if (requestFocusOnActive) {
                        channelListRecycler.post {
                            val holder = channelListRecycler.findViewHolderForAdapterPosition(pos)
                            if (holder != null) {
                                holder.itemView.requestFocus()
                            } else {
                                channelListRecycler.requestFocus()
                            }
                        }
                    }
                }
            }
        }
    }

    private fun importLocalM3uUri(uri: Uri) {
        xtreamRepo.cancelActiveFetch()
        loadChannelsJob?.cancel()
        clearVodAndSeriesCatalogsForAccountSwitch()

        loadChannelsJob = lifecycleScope.launch {
            val t0 = SystemClock.elapsedRealtime()
            tvActiveSectionBadge.text = "⏳ Importing M3U Live TV playlist..."
            runCatching {
                withContext(Dispatchers.IO) {
                    val cachedFile = File(filesDir, "local_playlist_${System.currentTimeMillis()}.m3u")
                    contentResolver.openInputStream(uri)?.use { input ->
                        cachedFile.outputStream().use { output ->
                            input.copyTo(output, bufferSize = 65536)
                        }
                    } ?: error("Cannot read selected file")
                    val channels = cachedFile.bufferedReader(Charsets.UTF_8).use { reader ->
                        M3uParser.parse(reader, maxChannels = maxPlaylistLimit, shouldCancel = { !isActive })
                    }
                    cachedFile to channels
                }
            }.onSuccess { (cachedFile, channels) ->
                lastPlaylistLoadDurationMs = SystemClock.elapsedRealtime() - t0
                if (channels.isNotEmpty()) {
                    val fileSource = "file://${cachedFile.absolutePath}"
                    val localProfile = PlaylistProfile(
                        name = "Local playlist (${channels.size} ch)",
                        type = ProfileType.M3U,
                        source = fileSource
                    )
                    profileStore.save(localProfile)
                    profileStore.setActive(localProfile.id)
                    activeSourceType = ProfileType.M3U
                    activeXtreamCreds = null
                    activeM3uInput = fileSource
                    activeM3uLabel = localProfile.name
                    activeAccountScope = localProfile.id
                    val cKey = cacheKeyFor("m3u_live_$fileSource")
                    launch(Dispatchers.IO) {
                        channelCache.saveChannels(cKey, channels, maxLimit = maxPlaylistLimit)
                    }
                    applyLoadedChannels(channels, "RAM PLAYER v21.0 • ${localProfile.name}", resumeLastWatched = false)
                    Toast.makeText(this@PlayerActivity, "Imported & cached ${channels.size} Live TV channels", Toast.LENGTH_LONG).show()
                } else {
                    tvActiveSectionBadge.text = "RAM PLAYER v21.0 • All Live TV"
                    Toast.makeText(this@PlayerActivity, "No valid M3U channels found", Toast.LENGTH_LONG).show()
                }
            }.onFailure { e ->
                Log.w("StreamX", "Local M3U import failed", e)
                tvActiveSectionBadge.text = "RAM PLAYER v21.0 • All Live TV"
                Toast.makeText(this@PlayerActivity, "File import failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun showEpgGuideHubDialog() {
        val activeCh = allChannels.getOrNull(currentChannelIndex)
        val activeEpg = activeCh?.let { lookupEpgForChannel(it) }
        val activeDetail = activeCh?.let { lookupEpgDetailForChannel(it) }
        val options = ArrayList<GlassModalOption>(64)

        if (activeCh != null) {
            val nowText = activeDetail?.nowTitle ?: activeEpg?.first ?: Channel.DEFAULT_PROGRAM
            val nextText = activeDetail?.nextTitle ?: activeEpg?.second ?: Channel.DEFAULT_NEXT_PROGRAM
            val timeWin = activeDetail?.timeWindow?.takeIf { it.isNotBlank() }?.let { " ($it)" } ?: ""
            val progPct = activeDetail?.progressPercent ?: 100
            val descText = activeDetail?.description?.takeIf { it.isNotBlank() }
                ?.let { "$it  •  Next: $nextText" }
                ?: "Next Programme: $nextText"
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_live_tv,
                    title = "Now on ${activeCh.name}: $nowText$timeWin",
                    subtitle = descText,
                    badgeText = "LIVE $progPct%",
                    isHighlighted = true
                ) {
                    showZappingOsd()
                }
            )
        }

        if (activeCh != null) {
            val nextText = activeDetail?.nextTitle ?: activeEpg?.second ?: Channel.DEFAULT_NEXT_PROGRAM
            val timeWin = activeDetail?.timeWindow.orEmpty()
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_sleep,
                    title = "⏰ Set Reminder for Upcoming Show: $nextText",
                    subtitle = "Save reminder for ${activeCh.name} ($nextText)",
                    badgeText = "REMIND ME"
                ) {
                    profileStore.addEpgReminder(activeCh.name, nextText, timeWin, activeAccountScope)
                    Toast.makeText(this, "⏰ Reminder saved: ${activeCh.name} • $nextText", Toast.LENGTH_SHORT).show()
                }
            )
        }

        val reminders = if (::profileStore.isInitialized) profileStore.getEpgReminders(activeAccountScope) else emptyList()
        if (reminders.isNotEmpty()) {
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_history,
                    title = "📋 Saved EPG Reminders (${reminders.size}): ${reminders.first()}",
                    subtitle = "Tap to clear saved programme reminders",
                    badgeText = "${reminders.size} SAVED"
                ) {
                    profileStore.clearEpgReminders(activeAccountScope)
                    Toast.makeText(this, "Cleared EPG reminders", Toast.LENGTH_SHORT).show()
                }
            )
        }

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_search,
                title = "🔍 Search EPG Programmes Across All Channels (What's On Now)",
                subtitle = "Find live or upcoming programmes by title across your channel guide",
                badgeText = "SEARCH EPG"
            ) {
                showEpgProgrammeSearchDialog()
            }
        )

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_epg,
                title = "Load / Refresh XMLTV EPG Guide URL (.XML)",
                subtitle = "Configure or refresh your XMLTV Electronic Program Guide source",
                badgeText = if (epgMap.isNotEmpty()) "${epgMap.size} EPG" else "SET URL"
            ) {
                showEpgUrlDialog()
            }
        )

        if (allChannels.isNotEmpty()) {
            val startIdx = (currentChannelIndex - 5).coerceAtLeast(0)
            val endIdx = (startIdx + 40).coerceAtMost(allChannels.size)
            for (idx in startIdx until endIdx) {
                val ch = allChannels[idx]
                val epg = lookupEpgForChannel(ch)
                val detail = lookupEpgDetailForChannel(ch)
                val nowStr = detail?.nowTitle ?: epg?.first ?: Channel.DEFAULT_PROGRAM
                val nextStr = detail?.nextTitle ?: epg?.second ?: Channel.DEFAULT_NEXT_PROGRAM
                val winPrefix = detail?.timeWindow?.takeIf { it.isNotBlank() }?.let { "[$it] " } ?: ""
                val isCur = idx == currentChannelIndex
                options.add(
                    GlassModalOption(
                        iconRes = R.drawable.ic_3d_channels,
                        title = "${ch.displayNumberFormatted()} • ${ch.name}",
                        subtitle = "${winPrefix}Now: $nowStr  •  Next: $nextStr",
                        badgeText = if (isCur) "WATCHING ✓" else ch.category.take(10).uppercase(Locale.ROOT),
                        isHighlighted = isCur
                    ) {
                        activePlaybackMode = ActivePlaybackMode.LIVE_TV
                        switchChannel(idx, immediatePlayback = true)
                    }
                )
            }
        }

        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_epg,
            title = "4D Electronic Program Guide (What's On Now & Reminders)",
            subtitle = "Browse live Now/Next schedules, search programmes or set reminders",
            badgeText = if (epgMap.isNotEmpty()) "XMLTV ACTIVE" else "TV GUIDE",
            options = options,
            closeLabel = "Close"
        )
    }

    private fun showEpgProgrammeSearchDialog() {
        show4dGlassFormModal(
            headerIconRes = R.drawable.ic_3d_search,
            title = "Search EPG Programmes (What's On Now & Next)",
            subtitle = "Search programme titles across ${epgMap.size} EPG schedules and ${allChannels.size} channels",
            badgeText = "EPG SEARCH",
            fields = listOf(
                GlassFormFieldSpec(
                    label = "PROGRAMME TITLE OR KEYWORD",
                    hint = "Type show, sport, news or movie title...",
                    iconRes = R.drawable.ic_3d_search
                )
            ),
            positiveLabel = "Search Guide",
            positiveBgRes = R.drawable.bg_btn_3d_cyan
        ) { vals ->
            val q = vals.firstOrNull()?.trim().orEmpty()
            if (q.isEmpty()) return@show4dGlassFormModal
            val matches = ArrayList<GlassModalOption>(40)
            for (i in allChannels.indices) {
                val ch = allChannels[i]
                val epg = lookupEpgForChannel(ch)
                val nowTitle = epg?.first ?: ""
                val nextTitle = epg?.second ?: ""
                if (SearchIntelligenceEngine.matchesSmartQuery("$nowTitle $nextTitle", ch.name, q)) {
                    val targetIdx = i
                    matches.add(
                        GlassModalOption(
                            iconRes = R.drawable.ic_3d_live_tv,
                            title = "${ch.displayNumberFormatted()} • ${ch.name}",
                            subtitle = "Now: ${nowTitle.ifBlank { "Live Broadcast" }}  •  Next: ${nextTitle.ifBlank { "Upcoming" }}",
                            badgeText = "WATCH"
                        ) {
                            activePlaybackMode = ActivePlaybackMode.LIVE_TV
                            switchChannel(targetIdx, immediatePlayback = true)
                        }
                    )
                    if (matches.size >= 40) break
                }
            }
            if (matches.isEmpty()) {
                Toast.makeText(this, "No EPG programmes found matching '$q'", Toast.LENGTH_SHORT).show()
            } else {
                show4dGlassListModal(
                    headerIconRes = R.drawable.ic_3d_epg,
                    title = "EPG Guide Matches for '$q'",
                    subtitle = "${matches.size} channels broadcasting matching programmes",
                    badgeText = "${matches.size} CH",
                    options = matches,
                    closeLabel = "Back"
                )
            }
        }
    }

    private fun showEpgUrlDialog() {
        val prefs = getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
        show4dGlassFormModal(
            headerIconRes = R.drawable.ic_3d_epg,
            title = "Load XMLTV EPG Program Guide",
            subtitle = "Parsed Now/Next TV schedules are cached locally and refreshed automatically",
            badgeText = "XMLTV EPG",
            fields = listOf(
                GlassFormFieldSpec(
                    label = "XMLTV EPG GUIDE URL (.XML)",
                    hint = "https://example.com/epg.xml",
                    iconRes = R.drawable.ic_3d_epg,
                    initialValue = prefs.getString("last_epg_url", "").orEmpty(),
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
                )
            ),
            positiveLabel = "Load & Cache Guide",
            positiveBgRes = R.drawable.bg_btn_3d_teal,
            positiveIconRes = R.drawable.ic_3d_sync
        ) { values ->
            val url = ProfileStore.sanitizeExternalInput(values.firstOrNull().orEmpty())
            if (url.isNotBlank()) {
                prefs.edit().putString("last_epg_url", url).apply()
                loadXmltvEpg(url, silentBackground = false)
            }
        }
    }

    private fun loadXmltvEpg(url: String, silentBackground: Boolean = false) {
        epgLoadJob?.cancel()
        epgLoadJob = lifecycleScope.launch {
            if (!silentBackground) {
                Toast.makeText(this@PlayerActivity, "Loading EPG in background...", Toast.LENGTH_SHORT).show()
            }
            val filterIds = knownEpgAndChannelIds.takeIf { it.isNotEmpty() }
            runCatching {
                withContext(Dispatchers.IO) {
                    val request = Request.Builder()
                        .url(url)
                        .header("User-Agent", NetworkClient.DEFAULT_USER_AGENT)
                        .build()
                    NetworkClient.apiClient.newCall(request).execute().use { response ->
                        if (!response.isSuccessful) error("EPG HTTP ${response.code}")
                        val body = response.body ?: error("Empty EPG response")
                        BufferedReader(InputStreamReader(body.byteStream(), Charsets.UTF_8), 32768).use { reader ->
                            XmltvParser.parseNowNext(
                                reader = reader,
                                relevantChannelIds = filterIds,
                                shouldCancel = { !isActive }
                            )
                        }
                    }
                }
            }.onSuccess { parsedEpg ->
                if (parsedEpg.isNotEmpty()) {
                    epgMap = parsedEpg
                    launch(Dispatchers.IO) {
                        epgCache.saveEpg(url, parsedEpg)
                    }
                    if (allChannels.isNotEmpty()) updateOsdForCurrentChannel()
                }
                if (!silentBackground) {
                    Toast.makeText(this@PlayerActivity, "EPG cached: ${epgMap.size} channel entries", Toast.LENGTH_LONG).show()
                }
            }.onFailure { e ->
                Log.w("StreamX", "EPG load error", e)
                if (!silentBackground) {
                    Toast.makeText(this@PlayerActivity, "EPG error: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun showProfilesDialog() {
        val profiles = profileStore.all()
        val activeId = profileStore.activeId()
        val options = ArrayList<GlassModalOption>(profiles.size + 8)

        profiles.forEach { p ->
            val isAct = p.id == activeId
            options.add(
                GlassModalOption(
                    iconRes = if (p.type == ProfileType.XTREAM) R.drawable.ic_3d_xtream else R.drawable.ic_3d_playlist,
                    title = p.name,
                    subtitle = "${p.type} Account • ${redactUrlForDisplay(p.source)}",
                    badgeText = if (isAct) "ACTIVE ✓" else "SWITCH",
                    isHighlighted = isAct
                ) {
                    activateProfile(p)
                }
            )
        }

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_accounts,
                title = "Add New Playlist / IPTV Account",
                subtitle = "Save an M3U URL or Xtream Codes VIP account with AES-256 encryption",
                badgeText = "+ NEW"
            ) {
                showAddProfileDialog()
            }
        )

        val currentCreds = activeXtreamCreds
        if (activeSourceType == ProfileType.XTREAM && currentCreds != null) {
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_movies,
                    title = "Refresh Xtream VOD Movies Catalog",
                    subtitle = "Fetch VOD Movies (`get_vod_streams`) from ${currentCreds.profileName}",
                    badgeText = "${vodMoviesCatalog.size} MOVIES"
                ) {
                    loadXtreamVodMovies(currentCreds, forceNetworkRefresh = true)
                }
            )
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_series,
                    title = "Refresh Xtream Series Catalog",
                    subtitle = "Fetch Series (`get_series`) from ${currentCreds.profileName}",
                    badgeText = "${seriesCatalogGroups.size} SERIES"
                ) {
                    loadXtreamSeriesCatalog(currentCreds, forceNetworkRefresh = true)
                }
            )
        }

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_sync,
                title = "Force Sync Active Account from Server",
                subtitle = "Refresh active playlist from network and update SXB2 cache",
                badgeText = "SYNC"
            ) {
                forceRefreshActivePlaylist()
            }
        )

        val hasPin = profileStore.hasParentalPin()
        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_lock,
                title = "Parental PIN Lock Settings",
                subtitle = "Configure 4-digit PIN and lock specific categories",
                badgeText = if (hasPin) "LOCKED ✓" else "OFF",
                isHighlighted = hasPin
            ) {
                showParentalPinSettingsDialog()
            }
        )

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_rocket,
                title = "Auto-Start on TV Boot",
                subtitle = "Automatically launch RAM PLAYER when Android TV starts",
                badgeText = if (autoBootEnabled) "ON ✓" else "OFF",
                isHighlighted = autoBootEnabled
            ) {
                toggleAutoBootSetting()
            }
        )

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_live_tv,
                title = "Auto-Resume Last Channel",
                subtitle = "Automatically play your last watched channel on launch",
                badgeText = if (autoResumeEnabled) "ON ✓" else "OFF",
                isHighlighted = autoResumeEnabled
            ) {
                toggleAutoResumeSetting()
            }
        )

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_trash,
                title = "Delete a Saved Account",
                subtitle = "Remove an existing M3U or Xtream profile and its isolated caches",
                badgeText = "REMOVE"
            ) {
                showDeleteProfileDialog()
            }
        )

        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_accounts,
            title = "Saved Accounts, Playlists & Boot Settings",
            subtitle = "Multi-account manager with strict Live/VOD/Series catalog isolation",
            badgeText = "${profiles.size} SAVED",
            options = options,
            closeLabel = "Close"
        )
    }

    private fun showAddProfileDialog() {
        val options = listOf(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_playlist,
                title = "M3U / M3U8 Playlist Account (Live TV Only)",
                subtitle = "Add a remote M3U/M3U8 playlist link or raw #EXTM3U stream list for Live TV",
                badgeText = "M3U8 LIVE"
            ) {
                showSaveM3uProfileDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_xtream,
                title = "Xtream Codes VIP Account (Live TV + VOD Movies + Series)",
                subtitle = "Connect with Server URL, Username & Password for independent Live, Movies & Series catalogs",
                badgeText = "VIP API",
                isHighlighted = true
            ) {
                showSaveXtreamProfileDialog()
            }
        )
        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_accounts,
            title = "Choose IPTV Account Type",
            subtitle = "Select how you want to connect your television channels and VOD catalogs",
            badgeText = "NEW PROFILE",
            options = options,
            closeLabel = "Back"
        )
    }

    private fun showSaveM3uProfileDialog() {
        show4dGlassFormModal(
            headerIconRes = R.drawable.ic_3d_playlist,
            title = "Save M3U / M3U8 Playlist Profile (Live TV)",
            subtitle = "Store Live TV playlist in SXB2 fast binary cache for instant startup",
            badgeText = "M3U PROFILE",
            fields = listOf(
                GlassFormFieldSpec(
                    label = "PROFILE NAME",
                    hint = "Account name (e.g. Family Live TV)",
                    iconRes = R.drawable.ic_3d_accounts,
                    inputType = InputType.TYPE_CLASS_TEXT
                ),
                GlassFormFieldSpec(
                    label = "M3U / M3U8 URL OR #EXTM3U TEXT",
                    hint = "https://server.com/playlist.m3u8",
                    iconRes = R.drawable.ic_3d_server,
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
                )
            ),
            positiveLabel = "Save & Play",
            positiveBgRes = R.drawable.bg_btn_3d_emerald,
            positiveIconRes = R.drawable.ic_3d_playlist
        ) { values ->
            val name = ProfileStore.sanitizeExternalInput(values.getOrNull(0).orEmpty())
            val source = ProfileStore.sanitizeExternalInput(values.getOrNull(1).orEmpty())
            if (name.isBlank() || source.isBlank()) {
                Toast.makeText(this, "Name and playlist are required", Toast.LENGTH_LONG).show()
            } else {
                val p = PlaylistProfile(name = name, type = ProfileType.M3U, source = source)
                profileStore.save(p); profileStore.setActive(p.id); activateProfile(p)
            }
        }
    }

    private fun showSaveXtreamProfileDialog() {
        show4dGlassFormModal(
            headerIconRes = R.drawable.ic_3d_xtream,
            title = "Save Xtream Codes VIP Account",
            subtitle = "Credentials are encrypted with AES-256 and load independent Live, Movies & Series catalogs",
            badgeText = "VIP XTREAM",
            fields = listOf(
                GlassFormFieldSpec(
                    label = "ACCOUNT / PROFILE NAME",
                    hint = "Account name (e.g. Sports & Cinema VIP)",
                    iconRes = R.drawable.ic_3d_accounts,
                    inputType = InputType.TYPE_CLASS_TEXT
                ),
                GlassFormFieldSpec(
                    label = "XTREAM SERVER URL & PORT",
                    hint = "http://line.server.com:8080",
                    iconRes = R.drawable.ic_3d_server,
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
                ),
                GlassFormFieldSpec(
                    label = "USERNAME",
                    hint = "Enter Xtream Username",
                    iconRes = R.drawable.ic_3d_user,
                    inputType = InputType.TYPE_CLASS_TEXT
                ),
                GlassFormFieldSpec(
                    label = "PASSWORD",
                    hint = "Enter Xtream Password",
                    iconRes = R.drawable.ic_3d_lock,
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                )
            ),
            positiveLabel = "Save & Play",
            positiveBgRes = R.drawable.bg_btn_3d_cyan,
            positiveIconRes = R.drawable.ic_3d_xtream
        ) { values ->
            val name = ProfileStore.sanitizeExternalInput(values.getOrNull(0).orEmpty())
            val server = ProfileStore.sanitizeExternalInput(values.getOrNull(1).orEmpty())
            val user = ProfileStore.sanitizeExternalInput(values.getOrNull(2).orEmpty())
            val pass = ProfileStore.sanitizeExternalInput(values.getOrNull(3).orEmpty())
            if (name.isBlank() || server.isBlank() || user.isBlank() || pass.isBlank()) {
                Toast.makeText(this, "All fields are required", Toast.LENGTH_LONG).show()
            } else {
                val p = PlaylistProfile(
                    name = name,
                    type = ProfileType.XTREAM,
                    source = server,
                    username = user,
                    password = pass
                )
                profileStore.save(p); profileStore.setActive(p.id); activateProfile(p)
            }
        }
    }

    private fun showDeleteProfileDialog() {
        val profiles = profileStore.all()
        if (profiles.isEmpty()) {
            Toast.makeText(this, "No saved accounts", Toast.LENGTH_SHORT).show()
            return
        }
        val options = profiles.map { p ->
            GlassModalOption(
                iconRes = R.drawable.ic_3d_trash,
                title = "Delete: ${p.name}",
                subtitle = "${p.type} • ${redactUrlForDisplay(p.source)}",
                badgeText = "DELETE"
            ) {
                profileStore.delete(p.id)
                if (profileStore.activeId() == p.id) {
                    val next = profileStore.all().firstOrNull()
                    if (next != null) {
                        profileStore.setActive(next.id)
                        activateProfile(next)
                    } else {
                        clearVodAndSeriesCatalogsForAccountSwitch()
                        Toast.makeText(this, "Account deleted. Add a playlist to start.", Toast.LENGTH_LONG).show()
                    }
                }
                showProfilesDialog()
            }
        }
        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_trash,
            title = "Delete Saved Account",
            subtitle = "Select an account below to permanently remove it",
            badgeText = "${profiles.size} ACCOUNTS",
            options = options,
            closeLabel = "Cancel"
        )
    }

    private fun activateProfile(profile: PlaylistProfile) {
        recordCurrentVodOrSeriesProgress()
        xtreamRepo.cancelActiveFetch()
        loadChannelsJob?.cancel()
        clearVodAndSeriesCatalogsForAccountSwitch()

        profileStore.setActive(profile.id)
        activeAccountScope = profile.id
        audioDelayProcessor.setDelayMs(profileStore.getAudioDelayMs(activeAccountScope))
        cancelPendingDelayedSubtitles()
        applySidebarCustomization()
        scheduleAutoRefreshIfConfigured()
        tvActiveSectionBadge.text = "RAM PLAYER v21.0 • ${profile.name}"
        when (profile.type) {
            ProfileType.M3U -> {
                activeXtreamCreds = null
                loadM3uFromInput(profile.source, profile.name, forceNetworkRefresh = false, scopeOverride = profile.id)
            }
            ProfileType.XTREAM -> {
                val creds = XtreamCredentials(profile.name, profile.source, profile.username, profile.password)
                loadXtreamChannels(creds, forceNetworkRefresh = false, scopeOverride = profile.id)
            }
        }
    }

    private fun showXtreamLoginDialog() {
        val prefs = getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
        show4dGlassFormModal(
            headerIconRes = R.drawable.ic_3d_xtream,
            title = "Xtream Codes VIP Login",
            subtitle = "Independent Live TV (`get_live_streams`), Movies (`get_vod_streams`) & Series (`get_series`)",
            badgeText = "VIP HD",
            fields = listOf(
                GlassFormFieldSpec(
                    label = "SERVER URL & PORT",
                    hint = "Server URL (e.g. http://line.server.com:8080)",
                    iconRes = R.drawable.ic_3d_server,
                    initialValue = prefs.getString("xtream_server", "").orEmpty(),
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
                ),
                GlassFormFieldSpec(
                    label = "USERNAME",
                    hint = "Username",
                    iconRes = R.drawable.ic_3d_user,
                    initialValue = prefs.getString("xtream_user", "").orEmpty(),
                    inputType = InputType.TYPE_CLASS_TEXT
                ),
                GlassFormFieldSpec(
                    label = "PASSWORD",
                    hint = "Password",
                    iconRes = R.drawable.ic_3d_lock,
                    initialValue = prefs.getString("xtream_pass", "").orEmpty(),
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                )
            ),
            positiveLabel = "Connect & Play",
            positiveBgRes = R.drawable.bg_btn_3d_cyan,
            positiveIconRes = R.drawable.ic_3d_xtream
        ) { values ->
            val srv = ProfileStore.sanitizeExternalInput(values.getOrNull(0).orEmpty())
            val usr = ProfileStore.sanitizeExternalInput(values.getOrNull(1).orEmpty())
            val pwd = ProfileStore.sanitizeExternalInput(values.getOrNull(2).orEmpty())
            if (srv.isNotEmpty() && usr.isNotEmpty()) {
                prefs.edit()
                    .putString("xtream_server", srv)
                    .putString("xtream_user", usr)
                    .putString("xtream_pass", pwd)
                    .apply()
                clearVodAndSeriesCatalogsForAccountSwitch()
                val creds = XtreamCredentials("Xtream VIP", srv, usr, pwd)
                loadXtreamChannels(creds, forceNetworkRefresh = true)
            }
        }
    }

    // =========================================================================
    // v18.1 STRICTLY SEPARATED XTREAM LIVE TV, VOD MOVIES & SERIES LOADERS
    // =========================================================================

    private fun xtreamScopeKey(creds: XtreamCredentials): String =
        cacheKeyFor("xtream_${creds.serverUrl.trim()}_${creds.username.trim()}")

    private fun loadXtreamChannels(
        creds: XtreamCredentials,
        forceNetworkRefresh: Boolean = false,
        scopeOverride: String? = null
    ) {
        activeSourceType = ProfileType.XTREAM
        activeXtreamCreds = creds
        val baseKey = xtreamScopeKey(creds)
        activeAccountScope = scopeOverride ?: baseKey
        val liveCacheKey = "live_$baseKey"

        xtreamRepo.cancelActiveFetch()
        loadChannelsJob?.cancel()
        loadChannelsJob = lifecycleScope.launch {
            val t0 = SystemClock.elapsedRealtime()

            // Restore cached VOD Movies & Series for this specific Xtream account in background
            preloadCachedXtreamVodAndSeries(creds)

            // 1. Fast SXB2 Live TV Cache Load + Progressive 80-Channel First Batch
            if (!forceNetworkRefresh) {
                updateBootStage(68, "Restoring Fast SXB2 Live TV Cache...", "Account: ${creds.profileName}")
                val cachedLive = channelCache.loadChannels(
                    key = liveCacheKey,
                    maxLimit = maxPlaylistLimit,
                    defaultSourceType = ContentSourceType.XTREAM_LIVE
                ) { firstBatch ->
                    withContext(Dispatchers.Main) {
                        if (currentPlayingStreamUrl.isEmpty()) {
                            applyLoadedChannels(
                                firstBatch,
                                "RAM PLAYER v21.0 • ⚡ ${creds.profileName} (${firstBatch.size}+ Live)",
                                resumeLastWatched = false,
                                isPreliminaryBatch = true
                            )
                        }
                    }
                }
                if (cachedLive.isNotEmpty()) {
                    lastPlaylistLoadDurationMs = SystemClock.elapsedRealtime() - t0
                    applyLoadedChannels(
                        cachedLive,
                        "RAM PLAYER v21.0 • ⚡ ${creds.profileName} (${cachedLive.size} Live)",
                        resumeLastWatched = true
                    )
                    if (isNetworkConnectedNow() && channelCache.isCacheStale(liveCacheKey)) {
                        scheduleSilentXtreamRefresh(creds, liveCacheKey)
                    }
                    return@launch
                }
            }

            // 2. Network Live TV Stream Load (`get_live_streams` ONLY)
            updateBootStage(70, "Loading Live TV from Xtream Server...", "Connecting to ${NetworkClient.redactSensitiveUrl(creds.serverUrl)}")
            tvActiveSectionBadge.text = "⏳ Loading Xtream Live TV..."
            val accountInfo = xtreamRepo.validateAccount(creds).getOrNull()
            if (accountInfo != null && accountInfo.isExpired) {
                Toast.makeText(
                    this@PlayerActivity,
                    "Xtream account status: ${accountInfo.status} (Expired). Trying cached/live streams...",
                    Toast.LENGTH_LONG
                ).show()
            }
            val allowedFmts = accountInfo?.allowedOutputFormats.orEmpty()
            val res = xtreamRepo.fetchLiveStreams(creds, maxStreams = maxPlaylistLimit, allowedOutputFormats = allowedFmts) { firstBatch ->
                withContext(Dispatchers.Main) {
                    updateBootStage(76, "Loaded first ${firstBatch.size} live channels...", "Playing immediately while streaming list")
                    applyLoadedChannels(
                        firstBatch,
                        "RAM PLAYER v21.0 • ⏳ ${creds.profileName} (${firstBatch.size}+ Live)",
                        resumeLastWatched = false,
                        isPreliminaryBatch = true
                    )
                }
            }
            res.onSuccess { list ->
                lastPlaylistLoadDurationMs = SystemClock.elapsedRealtime() - t0
                if (list.isNotEmpty()) {
                    applyLoadedChannels(
                        list,
                        "RAM PLAYER v21.0 • ${creds.profileName} (${list.size} Live)",
                        resumeLastWatched = true
                    )
                    launch(Dispatchers.IO) {
                        channelCache.saveChannels(liveCacheKey, list, maxLimit = maxPlaylistLimit)
                    }
                    Toast.makeText(
                        this@PlayerActivity,
                        "Xtream Live TV Cached (${list.size} channels)!",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    dismissDthBootOverlay("NO CHANNELS FOUND")
                    tvActiveSectionBadge.text = "RAM PLAYER v21.0 • No Live Channels"
                    Toast.makeText(this@PlayerActivity, "No live channels found on server", Toast.LENGTH_LONG).show()
                }
            }.onFailure { err ->
                Log.w("StreamX", "Xtream live load error", err)
                val fallbackCached = channelCache.loadChannels(
                    key = liveCacheKey,
                    maxLimit = maxPlaylistLimit,
                    defaultSourceType = ContentSourceType.XTREAM_LIVE
                )
                if (fallbackCached.isNotEmpty()) {
                    applyLoadedChannels(
                        fallbackCached,
                        "RAM PLAYER v21.0 • ⚡ ${creds.profileName} (${fallbackCached.size} Live)",
                        resumeLastWatched = true
                    )
                } else {
                    dismissDthBootOverlay("CONNECTION ERROR")
                    tvActiveSectionBadge.text = "RAM PLAYER v21.0 • Connection Error"
                    Toast.makeText(this@PlayerActivity, "Xtream Error: ${err.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun preloadCachedXtreamVodAndSeries(creds: XtreamCredentials) {
        val baseKey = xtreamScopeKey(creds)
        val vodCacheKey = "vod_$baseKey"
        val seriesCacheKey = "series_$baseKey"

        lifecycleScope.launch(Dispatchers.IO) {
            val cachedVod = channelCache.loadChannels(
                key = vodCacheKey,
                maxLimit = 25_000,
                defaultSourceType = ContentSourceType.XTREAM_VOD_MOVIE
            ).filter { it.sourceType == ContentSourceType.XTREAM_VOD_MOVIE }

            val excludedCats = if (::profileStore.isInitialized) {
                profileStore.getAllExcludedCategories(activeAccountScope)
            } else emptySet()

            if (cachedVod.isNotEmpty()) {
                val filteredVod = ChannelDeletionFilter.filterActiveChannels(
                    rawChannels = cachedVod,
                    deletedCategories = excludedCats,
                    deletedChannelKeys = emptySet(),
                    deletedChannelIds = emptySet()
                )
                val byId = HashMap<String, Int>(filteredVod.size)
                for (i in filteredVod.indices) byId[filteredVod[i].id] = i
                withContext(Dispatchers.Main) {
                    if (activeXtreamCreds == creds && vodMoviesCatalog.isEmpty()) {
                        rawLoadedVodMovies = cachedVod
                        vodMoviesCatalog = filteredVod
                        vodMovieIndexById = byId
                    }
                }
            }

            val cachedSeries = channelCache.loadChannels(
                key = seriesCacheKey,
                maxLimit = 15_000,
                defaultSourceType = ContentSourceType.XTREAM_SERIES
            ).filter { it.sourceType == ContentSourceType.XTREAM_SERIES }

            if (cachedSeries.isNotEmpty()) {
                val filteredSeries = ChannelDeletionFilter.filterActiveChannels(
                    rawChannels = cachedSeries,
                    deletedCategories = excludedCats,
                    deletedChannelKeys = emptySet(),
                    deletedChannelIds = emptySet()
                )
                val groups = MediaCatalogEngine.buildXtreamSeriesGroups(filteredSeries)
                withContext(Dispatchers.Main) {
                    if (activeXtreamCreds == creds && seriesCatalogGroups.isEmpty()) {
                        rawLoadedSeries = cachedSeries
                        seriesCatalogRaw = filteredSeries
                        seriesCatalogGroups = groups
                    }
                }
            }
        }
    }

    /**
     * Loads Xtream VOD Movies (`get_vod_categories` + `get_vod_streams`) into `vodMoviesCatalog` ONLY.
     * NEVER modifies or overwrites `allChannels` (Live TV)!
     */
    private fun loadXtreamVodMovies(creds: XtreamCredentials, forceNetworkRefresh: Boolean = false) {
        val baseKey = xtreamScopeKey(creds)
        val vodCacheKey = "vod_$baseKey"

        vodCatalogLoadJob?.cancel()
        vodCatalogLoadJob = lifecycleScope.launch {
            if (!forceNetworkRefresh) {
                val cachedVod = channelCache.loadChannels(
                    key = vodCacheKey,
                    maxLimit = 25_000,
                    defaultSourceType = ContentSourceType.XTREAM_VOD_MOVIE
                ).filter { it.sourceType == ContentSourceType.XTREAM_VOD_MOVIE }

                if (cachedVod.isNotEmpty()) {
                    applyLoadedVodMoviesCatalog(cachedVod)
                    return@launch
                }
            }

            Toast.makeText(this@PlayerActivity, "🎬 Loading VOD Movies from Xtream...", Toast.LENGTH_SHORT).show()
            val res = xtreamRepo.fetchVodStreams(creds, maxStreams = 25_000, startingNumber = 1)
            res.onSuccess { movies ->
                val strictMovies = movies.filter { it.sourceType == ContentSourceType.XTREAM_VOD_MOVIE }
                applyLoadedVodMoviesCatalog(strictMovies)
                if (strictMovies.isNotEmpty()) {
                    launch(Dispatchers.IO) {
                        channelCache.saveChannels(vodCacheKey, strictMovies, maxLimit = 25_000)
                    }
                    Toast.makeText(this@PlayerActivity, "🎬 Loaded ${strictMovies.size} VOD Movies!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this@PlayerActivity, "No VOD Movies returned by this Xtream server", Toast.LENGTH_SHORT).show()
                }
            }.onFailure { e ->
                Toast.makeText(this@PlayerActivity, "VOD Movies Error: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun applyLoadedVodMoviesCatalog(movies: List<Channel>) {
        rawLoadedVodMovies = movies
        val filteredMovies = if (::profileStore.isInitialized) {
            ChannelDeletionFilter.filterActiveChannels(
                rawChannels = movies,
                deletedCategories = profileStore.getAllExcludedCategories(activeAccountScope),
                deletedChannelKeys = emptySet(),
                deletedChannelIds = emptySet()
            )
        } else {
            movies
        }
        val byId = HashMap<String, Int>(filteredMovies.size)
        for (i in filteredMovies.indices) {
            byId[filteredMovies[i].id] = i
        }
        vodMoviesCatalog = filteredMovies
        vodMovieIndexById = byId
        if (vodPosterGridPanel.visibility == View.VISIBLE && activeEntertainmentSection == EntertainmentSection.MOVIES) {
            val sidebarItems = buildVodSidebarCategories(EntertainmentSection.MOVIES)
            vodSidebarAdapter.submitCategories(sidebarItems, selectedVodCategory)
            renderVodPosterGrid()
        }
    }

    /**
     * Loads Xtream Series (`get_series_categories` + `get_series`) into `seriesCatalogGroups` ONLY.
     * NEVER modifies or overwrites `allChannels` (Live TV)!
     */
    private fun loadXtreamSeriesCatalog(creds: XtreamCredentials, forceNetworkRefresh: Boolean = false) {
        val baseKey = xtreamScopeKey(creds)
        val seriesCacheKey = "series_$baseKey"

        seriesCatalogLoadJob?.cancel()
        seriesCatalogLoadJob = lifecycleScope.launch {
            if (!forceNetworkRefresh) {
                val cachedSeries = channelCache.loadChannels(
                    key = seriesCacheKey,
                    maxLimit = 15_000,
                    defaultSourceType = ContentSourceType.XTREAM_SERIES
                ).filter { it.sourceType == ContentSourceType.XTREAM_SERIES }

                if (cachedSeries.isNotEmpty()) {
                    applyLoadedSeriesCatalog(cachedSeries)
                    return@launch
                }
            }

            Toast.makeText(this@PlayerActivity, "📺 Loading Series Catalog from Xtream...", Toast.LENGTH_SHORT).show()
            val res = xtreamRepo.fetchSeriesCatalog(creds, maxSeries = 15_000, startingNumber = 1)
            res.onSuccess { seriesEntries ->
                val strictSeries = seriesEntries.filter { it.sourceType == ContentSourceType.XTREAM_SERIES }
                applyLoadedSeriesCatalog(strictSeries)
                if (strictSeries.isNotEmpty()) {
                    launch(Dispatchers.IO) {
                        channelCache.saveChannels(seriesCacheKey, strictSeries, maxLimit = 15_000)
                    }
                    Toast.makeText(this@PlayerActivity, "📺 Loaded ${strictSeries.size} Series!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this@PlayerActivity, "No Series returned by this Xtream server", Toast.LENGTH_SHORT).show()
                }
            }.onFailure { e ->
                Toast.makeText(this@PlayerActivity, "Series Load Error: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun applyLoadedSeriesCatalog(seriesEntries: List<Channel>) {
        rawLoadedSeries = seriesEntries
        val filteredSeries = if (::profileStore.isInitialized) {
            ChannelDeletionFilter.filterActiveChannels(
                rawChannels = seriesEntries,
                deletedCategories = profileStore.getAllExcludedCategories(activeAccountScope),
                deletedChannelKeys = emptySet(),
                deletedChannelIds = emptySet()
            )
        } else {
            seriesEntries
        }
        seriesCatalogRaw = filteredSeries
        seriesCatalogGroups = MediaCatalogEngine.buildXtreamSeriesGroups(filteredSeries)
        if (vodPosterGridPanel.visibility == View.VISIBLE && activeEntertainmentSection == EntertainmentSection.SERIES) {
            val sidebarItems = buildVodSidebarCategories(EntertainmentSection.SERIES)
            vodSidebarAdapter.submitCategories(sidebarItems, selectedVodCategory)
            renderVodPosterGrid()
        }
    }

    private fun scheduleSilentXtreamRefresh(creds: XtreamCredentials, liveCacheKey: String) {
        bgSyncJob?.cancel()
        bgSyncJob = lifecycleScope.launch(Dispatchers.IO) {
            delay(4000L)
            val res = xtreamRepo.fetchLiveStreams(creds, maxStreams = maxPlaylistLimit)
            res.onSuccess { freshList ->
                if (freshList.isNotEmpty()) {
                    channelCache.saveChannels(liveCacheKey, freshList, maxLimit = maxPlaylistLimit)
                }
            }
        }
    }

    private fun showM3uLoadDialog() {
        val prefs = getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
        show4dGlassFormModal(
            headerIconRes = R.drawable.ic_3d_playlist,
            title = "Load M3U / M3U8 Live TV Playlist",
            subtitle = "Stream Live TV channels from URL, paste raw #EXTM3U content, or pick a local .m3u/.m3u8 file",
            badgeText = "LIVE TV ONLY",
            fields = listOf(
                GlassFormFieldSpec(
                    label = "M3U / M3U8 PLAYLIST URL OR #EXTM3U CONTENT",
                    hint = "Paste M3U URL (https://.../playlist.m3u) or #EXTM3U",
                    iconRes = R.drawable.ic_3d_server,
                    initialValue = prefs.getString("m3u_url", "").orEmpty(),
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
                )
            ),
            neutralLabel = "Choose Local File",
            neutralBgRes = R.drawable.bg_btn_3d_emerald,
            neutralIconRes = R.drawable.ic_3d_playlist,
            onNeutral = {
                playlistPicker.launch(arrayOf("application/x-mpegURL", "audio/x-mpegurl", "text/plain", "*/*"))
            },
            positiveLabel = "Load Live TV",
            positiveBgRes = R.drawable.bg_btn_3d_cyan,
            positiveIconRes = R.drawable.ic_3d_sync
        ) { values ->
            val input = ProfileStore.sanitizeExternalInput(values.firstOrNull().orEmpty())
            if (input.isNotEmpty()) {
                prefs.edit().putString("m3u_url", input).apply()
                loadM3uFromInput(input, "M3U Live TV", forceNetworkRefresh = true)
            }
        }
    }

    /**
     * Loads M3U/M3U8 playlist strictly into Live TV (`allChannels`).
     * Clears any VOD Movies or Series catalogs so M3U profiles show a clean empty state in Movies & Series.
     */
    private fun loadM3uFromInput(
        input: String,
        label: String = "M3U",
        forceNetworkRefresh: Boolean = false,
        scopeOverride: String? = null
    ) {
        xtreamRepo.cancelActiveFetch()
        loadChannelsJob?.cancel()
        clearVodAndSeriesCatalogsForAccountSwitch()

        activeSourceType = ProfileType.M3U
        activeXtreamCreds = null
        activeM3uInput = input
        activeM3uLabel = label
        val cKey = cacheKeyFor("m3u_live_${input.take(256)}")
        activeAccountScope = scopeOverride ?: cKey

        loadChannelsJob = lifecycleScope.launch {
            val t0 = SystemClock.elapsedRealtime()
            if (!forceNetworkRefresh) {
                updateBootStage(68, "Restoring Fast SXB2 Live TV Cache...", label)
                val cached = channelCache.loadChannels(
                    key = cKey,
                    maxLimit = maxPlaylistLimit,
                    defaultSourceType = ContentSourceType.M3U_LIVE
                ) { firstBatch ->
                    withContext(Dispatchers.Main) {
                        if (currentPlayingStreamUrl.isEmpty()) {
                            applyLoadedChannels(
                                firstBatch,
                                "RAM PLAYER v21.0 • ⚡ $label (${firstBatch.size}+ CH)",
                                resumeLastWatched = false,
                                isPreliminaryBatch = true
                            )
                        }
                    }
                }
                if (cached.isNotEmpty()) {
                    lastPlaylistLoadDurationMs = SystemClock.elapsedRealtime() - t0
                    applyLoadedChannels(
                        cached,
                        "RAM PLAYER v21.0 • ⚡ $label (${cached.size} CH)",
                        resumeLastWatched = true
                    )
                    if (isNetworkConnectedNow() &&
                        (input.startsWith("http://", true) || input.startsWith("https://", true)) &&
                        channelCache.isCacheStale(cKey)
                    ) {
                        scheduleSilentM3uRefresh(input, cKey)
                    }
                    return@launch
                }
            }

            updateBootStage(72, "Loading M3U Live TV Playlist...", label)
            tvActiveSectionBadge.text = "⏳ Loading M3U Live TV..."
            try {
                val parsed = withContext(Dispatchers.IO) {
                    val emitFirstBatch: (List<Channel>) -> Unit = { batch ->
                        lifecycleScope.launch(Dispatchers.Main) {
                            if (currentPlayingStreamUrl.isEmpty()) {
                                applyLoadedChannels(
                                    batch,
                                    "RAM PLAYER v21.0 • ⏳ $label (${batch.size}+ CH)",
                                    resumeLastWatched = false,
                                    isPreliminaryBatch = true
                                )
                            }
                        }
                    }
                    when {
                        input.startsWith("http://", true) || input.startsWith("https://", true) -> {
                            val req = Request.Builder()
                                .url(input)
                                .header("User-Agent", NetworkClient.DEFAULT_USER_AGENT)
                                .build()
                            NetworkClient.apiClient.newCall(req).execute().use { res ->
                                if (!res.isSuccessful) error("Playlist HTTP ${res.code}")
                                val body = res.body ?: error("Empty M3U response")
                                BufferedReader(InputStreamReader(NetworkClient.openDecompressedStream(body.byteStream()), Charsets.UTF_8), 65536).use { reader ->
                                    val stats = M3uParser.parseWithStats(reader, maxChannels = maxPlaylistLimit, shouldCancel = { !isActive }, onFirstBatch = emitFirstBatch, baseUrl = input)
                                    val autoEpg = stats.detectedEpgUrl
                                    if (autoEpg.isNotBlank() && epgMap.isEmpty()) {
                                        lifecycleScope.launch(Dispatchers.Main) {
                                            loadXmltvEpg(autoEpg, silentBackground = true)
                                        }
                                    }
                                    stats.channels
                                }
                            }
                        }
                        input.startsWith("file://", true) -> {
                            val file = File(Uri.parse(input).path ?: "")
                            if (!file.exists()) error("Saved playlist file not found")
                            file.bufferedReader(Charsets.UTF_8).use { reader ->
                                M3uParser.parse(reader, maxChannels = maxPlaylistLimit, shouldCancel = { !isActive }, onFirstBatch = emitFirstBatch)
                            }
                        }
                        input.startsWith("content://", true) -> {
                            contentResolver.openInputStream(Uri.parse(input))?.bufferedReader(Charsets.UTF_8)?.use { reader ->
                                M3uParser.parse(reader, maxChannels = maxPlaylistLimit, shouldCancel = { !isActive }, onFirstBatch = emitFirstBatch)
                            } ?: emptyList()
                        }
                        else -> M3uParser.parse(input, maxChannels = maxPlaylistLimit, shouldCancel = { !isActive }, onFirstBatch = emitFirstBatch)
                    }
                }
                lastPlaylistLoadDurationMs = SystemClock.elapsedRealtime() - t0
                if (parsed.isNotEmpty()) {
                    applyLoadedChannels(
                        parsed,
                        "RAM PLAYER v21.0 • $label (${parsed.size} CH)",
                        resumeLastWatched = true
                    )
                    launch(Dispatchers.IO) {
                        channelCache.saveChannels(cKey, parsed, maxLimit = maxPlaylistLimit)
                        NetworkClient.saveStreamMetadataCache(cacheDir)
                    }
                    Toast.makeText(this@PlayerActivity, "M3U Live TV Cached (${parsed.size} CH)!", Toast.LENGTH_SHORT).show()
                } else {
                    dismissDthBootOverlay("NO CHANNELS FOUND")
                    tvActiveSectionBadge.text = "RAM PLAYER v21.0 • All Live TV"
                    Toast.makeText(this@PlayerActivity, "No valid channels found in M3U", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Log.w("StreamX", "M3U load error", e)
                val fallbackCached = channelCache.loadChannels(
                    key = cKey,
                    maxLimit = maxPlaylistLimit,
                    defaultSourceType = ContentSourceType.M3U_LIVE
                )
                if (fallbackCached.isNotEmpty()) {
                    applyLoadedChannels(
                        fallbackCached,
                        "RAM PLAYER v21.0 • ⚡ $label (${fallbackCached.size} CH)",
                        resumeLastWatched = true
                    )
                } else {
                    dismissDthBootOverlay("CONNECTION ERROR")
                    tvActiveSectionBadge.text = "RAM PLAYER v21.0 • M3U Error"
                    Toast.makeText(this@PlayerActivity, "M3U Error: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun scheduleSilentM3uRefresh(url: String, cKey: String) {
        bgSyncJob?.cancel()
        bgSyncJob = lifecycleScope.launch(Dispatchers.IO) {
            delay(4000L)
            runCatching {
                val req = Request.Builder()
                    .url(url)
                    .header("User-Agent", NetworkClient.DEFAULT_USER_AGENT)
                    .build()
                NetworkClient.apiClient.newCall(req).execute().use { res ->
                    if (!res.isSuccessful) return@use
                    val body = res.body ?: return@use
                    val parsed = BufferedReader(InputStreamReader(NetworkClient.openDecompressedStream(body.byteStream()), Charsets.UTF_8), 65536).use { reader ->
                        M3uParser.parse(reader, maxChannels = maxPlaylistLimit, shouldCancel = { !isActive }, baseUrl = url)
                    }
                    if (parsed.isNotEmpty()) {
                        channelCache.saveChannels(cKey, parsed, maxLimit = maxPlaylistLimit)
                        NetworkClient.saveStreamMetadataCache(cacheDir)
                    }
                }
            }
        }
    }

    private suspend fun restoreSavedDataFromBoot(prefs: android.content.SharedPreferences, hasNet: Boolean) {
        if (!autoResumeEnabled) {
            updateBootStage(90, "Preparing Live Television...", "Starting default stream")
            switchChannel(0, immediatePlayback = true)
            dismissDthBootOverlay("READY TO ADD PLAYLIST")
            return
        }

        if (prefs.getBoolean("has_saved_profiles", false)) {
            val savedProfiles = withContext(Dispatchers.IO) { profileStore.all() }
            val activeId = withContext(Dispatchers.IO) { profileStore.activeId() }
            val active = savedProfiles.firstOrNull { it.id == activeId } ?: savedProfiles.firstOrNull()
            if (active != null) {
                profileStore.setActive(active.id)
                if (!hasNet) {
                    updateBootStage(70, "Network unavailable – Loading saved channels.", active.name)
                }
                activateProfile(active)
                return
            }
        }

        val srv = prefs.getString("xtream_server", "") ?: ""
        val usr = prefs.getString("xtream_user", "") ?: ""
        val pwd = prefs.getString("xtream_pass", "") ?: ""
        val m3u = prefs.getString("m3u_url", "") ?: ""
        if (srv.isNotEmpty() && usr.isNotEmpty()) {
            loadXtreamChannels(XtreamCredentials("Saved", srv, usr, pwd), forceNetworkRefresh = false)
        } else if (m3u.isNotEmpty()) {
            loadM3uFromInput(m3u, "Saved M3U", forceNetworkRefresh = false)
        } else {
            updateBootStage(90, "Preparing Live Television...", "Ready to Watch")
            switchChannel(0, immediatePlayback = true)
            dismissDthBootOverlay("READY TO ADD PLAYLIST")
        }
    }

    private fun updateOsdForCurrentChannel() {
        if (allChannels.isEmpty() || currentChannelIndex !in allChannels.indices) return
        val channel = allChannels[currentChannelIndex]
        tvChannelNumber.text = channel.displayNumberFormatted()
        tvChannelName.text = channel.name
        if (channel.logoUrl.isNotBlank() && !isDestroyed && !isFinishing) {
            Glide.with(this)
                .load(channel.logoUrl)
                .apply(logoRequestOptions)
                .into(channelLogo)
        } else {
            channelLogo.setImageResource(R.drawable.ic_3d_live_tv)
        }
        val epg = lookupEpgForChannel(channel)
        val epgDetail = lookupEpgDetailForChannel(channel)
        val telemetrySuffix = if (liveTelemetryDetail.isNotEmpty()) " • $liveTelemetryDetail" else ""
        tvChannelCategory.text = "${channel.category} • $liveResolutionLabel$telemetrySuffix • $liveStatusLabel"
        val nowTitle = epgDetail?.nowTitle ?: epg?.first ?: Channel.DEFAULT_PROGRAM
        val nextTitle = epgDetail?.nextTitle ?: epg?.second ?: Channel.DEFAULT_NEXT_PROGRAM
        tvEpgNow.text = "Now: $nowTitle  •  Next: $nextTitle  •  CH ${currentChannelIndex + 1}/${allChannels.size}"
        if (epgDetail != null && liveStatusLabel.startsWith("🟢")) {
            osdLiveProgressBar.progress = epgDetail.progressPercent
        }
        updateFavButtonUi(channel.id)
    }

    // Ultra-Fast Zap: Fires ExoPlayer preparation FIRST on millisecond 0 before UI/Glide updates!
    private fun switchChannel(newIndex: Int, immediatePlayback: Boolean = false) {
        if (allChannels.isEmpty()) return
        val resolvedIndex = ((newIndex % allChannels.size) + allChannels.size) % allChannels.size
        val targetChannel = allChannels[resolvedIndex]

        if (::profileStore.isInitialized &&
            profileStore.isCategoryLocked(targetChannel.category) &&
            !unlockedSessionCategories.contains(targetChannel.category.lowercase(Locale.ROOT))
        ) {
            promptParentalPinToUnlock(targetChannel.category) {
                switchChannel(resolvedIndex, immediatePlayback = true)
            }
            return
        }

        recordCurrentVodOrSeriesProgress()
        activePlaybackMode = ActivePlaybackMode.LIVE_TV

        if (resolvedIndex != currentChannelIndex) {
            lastZapForward = resolvedIndex > currentChannelIndex ||
                (currentChannelIndex == allChannels.lastIndex && resolvedIndex == 0)
            previousChannelIndex = currentChannelIndex
        }
        currentChannelIndex = resolvedIndex
        val channel = allChannels[currentChannelIndex]
        playbackRetryCount = 0
        stallRecoveryCount = 0
        usingBackupStream = false
        liveTelemetryDetail = ""
        val nowElapsed = SystemClock.elapsedRealtime()
        lastKeyPressToSelectionMs = if (lastRemoteKeyPressElapsedMs in (nowElapsed - 1000L)..nowElapsed) {
            (nowElapsed - lastRemoteKeyPressElapsedMs).coerceAtLeast(1L)
        } else {
            1L
        }
        lastSwitchStartElapsedMs = nowElapsed
        liveStatusLabel = "⚡ Zapping..."
        osdLiveProgressBar.progress = 35

        StreamPreFetcher.notifyChannelSwitched(channel.streamUrl, lastZapForward)
        uiHandler.removeCallbacks(stallWatchdogRunnable)
        uiHandler.removeCallbacks(retryPlaybackRunnable)
        uiHandler.removeCallbacks(commitPlaybackRunnable)

        activePlaybackToken++
        val switchToken = activePlaybackToken

        // 1. Fire Media3 ExoPlayer immediately BEFORE any UI/Glide work for minimum zapping latency!
        if (immediatePlayback) {
            startPlaybackForCurrentChannel(forceReload = false)
        } else {
            pendingCommitToken = switchToken
            uiHandler.postDelayed(commitPlaybackRunnable, 25L)
        }
        lastSelectionToPrepareMs = (SystemClock.elapsedRealtime() - nowElapsed).coerceAtLeast(1L)

        // 2. Update OSD and Recent list asynchronously
        recentIds.remove(channel.id)
        recentIds.add(0, channel.id)
        if (recentIds.size > 20) recentIds.removeAt(recentIds.lastIndex)
        uiHandler.removeCallbacks(persistStateRunnable)
        uiHandler.postDelayed(persistStateRunnable, 600L)

        updateOsdForCurrentChannel()
        showZappingOsd()

        if (leftChannelDrawer.visibility == View.VISIBLE && activeTab == "RECENT") {
            renderDrawerList()
        } else {
            channelAdapter.updateActiveChannel(currentChannelIndex)
        }
    }

    private fun startPlaybackForCurrentChannel(forceReload: Boolean = false) {
        if (allChannels.isEmpty() || currentChannelIndex !in allChannels.indices) return
        val channel = allChannels[currentChannelIndex]
        if (::profileStore.isInitialized) {
            val savedLang = profileStore.getPreferredAudioLanguage(channel.id)
            if (!savedLang.isNullOrBlank()) {
                exoPlayer?.let { player ->
                    player.trackSelectionParameters = player.trackSelectionParameters
                        .buildUpon()
                        .setPreferredAudioLanguages(savedLang, "hi", "hin", "en", "eng")
                        .build()
                }
            }
        }
        playSpecificStreamUrl(channel.streamUrl, forceReload = forceReload)
    }

    private fun lookupEpgForChannel(channel: Channel): Pair<String, String>? {
        if (epgMap.isEmpty()) return null
        val primaryKey = channel.epgId.ifBlank { channel.id }
        epgMap[primaryKey]?.let { return it }
        epgMap[primaryKey.lowercase(Locale.ROOT)]?.let { return it }
        val normPrimary = XmltvParser.normalizeEpgKey(primaryKey)
        if (normPrimary.isNotEmpty()) {
            epgMap[normPrimary]?.let { return it }
        }
        if (channel.name.isNotBlank()) {
            epgMap[channel.name.lowercase(Locale.ROOT)]?.let { return it }
            val normName = XmltvParser.normalizeEpgKey(channel.name)
            if (normName.isNotEmpty()) {
                epgMap[normName]?.let { return it }
            }
        }
        return null
    }

    private fun lookupEpgDetailForChannel(channel: Channel): EpgProgrammeDetail? {
        val primaryKey = channel.epgId.ifBlank { channel.id }
        XmltvParser.getProgrammeDetail(primaryKey)?.let { return it }
        if (channel.name.isNotBlank()) {
            XmltvParser.getProgrammeDetail(channel.name)?.let { return it }
        }
        return null
    }

    private fun redactUrlForDisplay(raw: String): String {
        return NetworkClient.redactSensitiveUrl(raw).take(48)
    }

    private fun playSpecificStreamUrl(targetUrl: String, forceReload: Boolean = false) {
        if (activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
            val ch = allChannels.getOrNull(currentChannelIndex)
            val chKey = ch?.id?.ifBlank { ch.name }.orEmpty()
            val globalMode = if (::profileStore.isInitialized) profileStore.getLiveTvEngineMode() else LiveTvEngineMode.AUTO_OTT_HEAL
            val remembered = if (::profileStore.isInitialized && chKey.isNotEmpty()) profileStore.getChannelWinningEngine(chKey) else null
            val effectiveEngine = LiveTvEngineRouter.resolveInitialEngineForChannel(globalMode, remembered)

            if (!forceReload && isLiveTvUsingLibVlc && currentPlayingStreamUrl == targetUrl && liveTvVlcEngine?.isPlaying() == true) {
                return
            }

            liveHealGeneration++
            hasRenderedVideoFrame = false
            lastAudioDecoderError = null
            lastAudioOutputError = null
            uiHandler.removeCallbacks(blackScreenWatchdogRunnable)

            if (effectiveEngine == LiveTvEngineMode.LIBVLC_HW || effectiveEngine == LiveTvEngineMode.LIBVLC_SW) {
                val forceSw = effectiveEngine == LiveTvEngineMode.LIBVLC_SW
                currentLiveHealStage = if (forceSw) LiveTvHealStage.VLC_SW_PRIMARY else LiveTvHealStage.VLC_HW_PRIMARY
                currentPlayingStreamUrl = targetUrl
                val cleanUrl = NetworkClient.extractCleanUrlAndRegisterHeaders(targetUrl)
                startLiveTvWithLibVlc(cleanUrl, forceSoftware = forceSw, statusNote = if (forceSw) "⚡ OTT-VLC SW" else "⚡ OTT-VLC HW")
                return
            } else {
                currentLiveHealStage = LiveTvHealStage.EXO_PRIMARY
                stopLiveTvLibVlcIfActive()
            }
        }

        exoPlayer?.let { player ->
            if (!forceReload &&
                !isLiveTvUsingLibVlc &&
                currentPlayingStreamUrl == targetUrl &&
                (player.playbackState == Player.STATE_READY || player.playbackState == Player.STATE_BUFFERING)
            ) {
                player.playWhenReady = true
                return
            }
            currentPlayingStreamUrl = targetUrl

            val cleanUrl = NetworkClient.extractCleanUrlAndRegisterHeaders(targetUrl)
            val drmConfig = NetworkClient.drmConfigForUrl(cleanUrl)
            if (activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
                uiHandler.removeCallbacks(blackScreenWatchdogRunnable)
                uiHandler.postDelayed(blackScreenWatchdogRunnable, 2200L)
            }

            // Preload-to-Playback Handoff: Reuse prepared MediaSource if available and fresh (skip for DRM/explicit manifest)
            val preloadedSource = if (!forceReload && drmConfig == null && activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
                StreamPreFetcher.consumePreparedMediaSource(cleanUrl)
            } else {
                null
            }
            if (preloadedSource != null) {
                lastSwitchUsedPreload = true
                player.setMediaSource(preloadedSource, true)
                player.prepare()
                player.playWhenReady = true
                return
            }

            lastSwitchUsedPreload = false
            val mediaItem = StreamPreFetcher.buildLiveMediaItem(cleanUrl)

            if (drmConfig != null && (drmConfig.hasDrm() || drmConfig.manifestType.isNotBlank())) {
                val configuredSource = buildOttConfiguredMediaSource(cleanUrl, mediaItem, drmConfig)
                if (configuredSource != null) {
                    player.setMediaSource(configuredSource, true)
                    player.prepare()
                    player.playWhenReady = true
                    return
                }
            }

            val hlsFactory = hlsChunklessFactory
            val defFactory = defaultMediaSourceFactory
            if (hlsFactory != null && StreamPreFetcher.detectStreamFormat(cleanUrl) == StreamPreFetcher.StreamFormat.HLS) {
                player.setMediaSource(hlsFactory.createMediaSource(mediaItem), true)
            } else if (defFactory != null) {
                player.setMediaSource(defFactory.createMediaSource(mediaItem), true)
            } else {
                player.setMediaItem(mediaItem, true)
            }
            player.prepare()
            player.playWhenReady = true
        }
    }

    private fun ensureLiveTvLibVlcEngine(): LiveTvLibVlcEngine {
        liveTvVlcEngine?.let { return it }
        val engine = LiveTvLibVlcEngine(this)
        engine.attachVideoLayout(liveTvVlcLayout)
        engine.setCallbacks(object : LiveTvLibVlcEngine.Callbacks {
            override fun onOpening() {
                if (!isLiveTvUsingLibVlc) return
                liveStatusLabel = if (engine.isSoftwareMode()) "⚡ OTT-VLC SW Opening..." else "⚡ OTT-VLC HW Opening..."
                osdLiveProgressBar.progress = 40
                if (activePlaybackMode == ActivePlaybackMode.LIVE_TV) updateOsdForCurrentChannel()
            }

            override fun onBuffering(percent: Float) {
                if (!isLiveTvUsingLibVlc) return
                val p = percent.toInt().coerceIn(10, 99)
                osdLiveProgressBar.progress = p
                if (p < 95) {
                    liveStatusLabel = "⏳ OTT-VLC Buffering $p%..."
                    if (activePlaybackMode == ActivePlaybackMode.LIVE_TV) updateOsdForCurrentChannel()
                }
            }

            override fun onPlaying() {
                if (!isLiveTvUsingLibVlc) return
                playbackRetryCount = 0
                stallRecoveryCount = 0
                val ch = allChannels.getOrNull(currentChannelIndex)
                val chKey = ch?.id?.ifBlank { ch.name }.orEmpty()
                if (::profileStore.isInitialized && chKey.isNotEmpty() &&
                    profileStore.getLiveTvEngineMode() == LiveTvEngineMode.AUTO_OTT_HEAL
                ) {
                    val winId = if (engine.isSoftwareMode()) LiveTvEngineMode.LIBVLC_SW.id else LiveTvEngineMode.LIBVLC_HW.id
                    profileStore.setChannelWinningEngine(chKey, winId)
                }
                liveStatusLabel = if (engine.isSoftwareMode()) "🟢 OTT-VLC SW Live" else "🟢 OTT-VLC HW Live"
                osdLiveProgressBar.progress = 100
                updateLiveVlcTelemetryBadge()
                if (activePlaybackMode == ActivePlaybackMode.LIVE_TV) updateOsdForCurrentChannel()
            }

            override fun onFirstVideoFrame(width: Int, height: Int) {
                if (!isLiveTvUsingLibVlc) return
                hasRenderedVideoFrame = true
                uiHandler.removeCallbacks(blackScreenWatchdogRunnable)
                if (isBootOverlayVisible) {
                    dismissDthBootOverlay("READY TO WATCH")
                }
                if (height > 0 && width > 0) {
                    liveResolutionLabel = when {
                        height >= 2160 || width >= 3840 -> "4K UHD"
                        height >= 1080 -> "1080p FHD"
                        height >= 720 -> "720p HD"
                        height >= 540 -> "576p HQ"
                        else -> "${height}p SD"
                    }
                }
                val ch = allChannels.getOrNull(currentChannelIndex)
                val chKey = ch?.id?.ifBlank { ch.name }.orEmpty()
                if (::profileStore.isInitialized && chKey.isNotEmpty() &&
                    profileStore.getLiveTvEngineMode() == LiveTvEngineMode.AUTO_OTT_HEAL
                ) {
                    val winId = if (engine.isSoftwareMode()) LiveTvEngineMode.LIBVLC_SW.id else LiveTvEngineMode.LIBVLC_HW.id
                    profileStore.setChannelWinningEngine(chKey, winId)
                }
                updateLiveVlcTelemetryBadge()
                if (activePlaybackMode == ActivePlaybackMode.LIVE_TV) updateOsdForCurrentChannel()
            }

            override fun onTracksUpdated(audioSummary: String) {
                if (!isLiveTvUsingLibVlc) return
                liveVlcAudioSummary = audioSummary
                updateLiveVlcTelemetryBadge()
            }

            override fun onError(reason: String) {
                if (!isLiveTvUsingLibVlc) return
                Log.w("StreamX", "LiveTvLibVlcEngine error: $reason")
                if (!advanceLiveTvHealStage(reason)) {
                    liveStatusLabel = "🔄 OTT-VLC Reconnecting..."
                    if (activePlaybackMode == ActivePlaybackMode.LIVE_TV) updateOsdForCurrentChannel()
                    uiHandler.removeCallbacks(retryPlaybackRunnable)
                    uiHandler.postDelayed({
                        if (!isFinishing && !isDestroyed && isLiveTvUsingLibVlc && activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
                            startPlaybackForCurrentChannel(forceReload = true)
                        }
                    }, 2200L)
                }
            }

            override fun onEnded() {
                if (!isLiveTvUsingLibVlc || activePlaybackMode != ActivePlaybackMode.LIVE_TV) return
                uiHandler.postDelayed({
                    if (!isFinishing && !isDestroyed && isLiveTvUsingLibVlc && activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
                        startPlaybackForCurrentChannel(forceReload = true)
                    }
                }, 1200L)
            }
        })
        liveTvVlcEngine = engine
        return engine
    }

    private fun stopLiveTvLibVlcIfActive() {
        if (isLiveTvUsingLibVlc || liveTvVlcLayout.visibility == View.VISIBLE) {
            isLiveTvUsingLibVlc = false
            liveTvVlcEngine?.stop()
            liveTvVlcLayout.visibility = View.GONE
            playerView.visibility = View.VISIBLE
        }
    }

    private fun startLiveTvWithLibVlc(cleanUrl: String, forceSoftware: Boolean, statusNote: String) {
        exoPlayer?.let { p ->
            p.playWhenReady = false
            p.stop()
            p.clearMediaItems()
        }
        uiHandler.removeCallbacks(stallWatchdogRunnable)
        uiHandler.removeCallbacks(retryPlaybackRunnable)
        uiHandler.removeCallbacks(blackScreenWatchdogRunnable)

        isLiveTvUsingLibVlc = true
        hasRenderedVideoFrame = false
        liveVlcAudioSummary = ""
        playerView.visibility = View.INVISIBLE
        liveTvVlcLayout.visibility = View.VISIBLE

        val engine = ensureLiveTvLibVlcEngine()
        engine.attachVideoLayout(liveTvVlcLayout)
        engine.setAspectRatioByResizeIndex(currentResizeIndex)
        if (::profileStore.isInitialized) {
            engine.setAudioDelayMs(profileStore.getAudioDelayMs(activeAccountScope).toLong())
        }
        val headers = NetworkClient.headersForUrl(cleanUrl)
        val cacheMs = if (isLowRamTvDevice) 900 else 1100
        engine.playLiveStream(cleanUrl, forceSoftware = forceSoftware, headers = headers, networkCachingMs = cacheMs)

        liveStatusLabel = statusNote
        updateLiveVlcTelemetryBadge()
        if (activePlaybackMode == ActivePlaybackMode.LIVE_TV) updateOsdForCurrentChannel()

        // Fast 3.8s watchdog for LibVLC HW -> SW or backup URL failover if no video frame appears
        uiHandler.postDelayed(blackScreenWatchdogRunnable, 3800L)
    }

    private fun updateLiveVlcTelemetryBadge() {
        val tag = if (liveTvVlcEngine?.isSoftwareMode() == true) "⚡ OTT-VLC SW" else "⚡ OTT-VLC HW"
        val res = liveResolutionLabel.ifBlank { "LIVE" }
        val aud = liveVlcAudioSummary.ifBlank { "FFmpeg Audio" }
        tvOsdStreamBadge.text = "$tag • $res • $aud"
    }

    private fun checkProactiveLibVlcLiveHandover(player: ExoPlayer, reason: String) {
        if (activePlaybackMode != ActivePlaybackMode.LIVE_TV || isLiveTvUsingLibVlc) return
        val engineMode = if (::profileStore.isInitialized) profileStore.getLiveTvEngineMode() else LiveTvEngineMode.AUTO_OTT_HEAL
        if (engineMode == LiveTvEngineMode.MEDIA3_ONLY) return

        var hasUnsupportedVideo = false
        var hasSupportedVideo = false
        var hasUnsupportedAudio = false
        var hasSupportedAudio = false
        var audioMime: String? = null
        var audioCodecs: String? = null
        var audioCh = 0

        for (group in player.currentTracks.groups) {
            if (group.type == C.TRACK_TYPE_VIDEO) {
                for (i in 0 until group.length) {
                    val fmt = group.getTrackFormat(i)
                    if (group.isTrackSupported(i)) {
                        hasSupportedVideo = true
                        if (LiveTvEngineRouter.isProblematicVideoCodec(fmt.sampleMimeType, fmt.codecs)) {
                            hasUnsupportedVideo = true
                        }
                    } else {
                        hasUnsupportedVideo = true
                    }
                }
            } else if (group.type == C.TRACK_TYPE_AUDIO) {
                for (i in 0 until group.length) {
                    val fmt = group.getTrackFormat(i)
                    if (audioMime == null) {
                        audioMime = fmt.sampleMimeType
                        audioCodecs = fmt.codecs
                        audioCh = fmt.channelCount
                    }
                    if (group.isTrackSupported(i)) {
                        hasSupportedAudio = true
                    } else {
                        hasUnsupportedAudio = true
                    }
                }
            }
        }

        val effectiveUnsupportedVideo = hasUnsupportedVideo && !hasSupportedVideo
        val effectiveUnsupportedAudio = hasUnsupportedAudio && !hasSupportedAudio
        if (LiveTvEngineRouter.shouldProactivelySwitchToLibVlc(
                hasUnsupportedVideoTrack = effectiveUnsupportedVideo,
                hasUnsupportedAudioTrack = effectiveUnsupportedAudio,
                audioMimeType = audioMime,
                audioCodecs = audioCodecs,
                audioChannelCount = audioCh,
                audioDecoderError = lastAudioDecoderError,
                audioOutputError = lastAudioOutputError,
                engineMode = engineMode
            )
        ) {
            advanceLiveTvHealStage(reason)
        }
    }

    private fun advanceLiveTvHealStage(reason: String): Boolean {
        if (activePlaybackMode != ActivePlaybackMode.LIVE_TV || allChannels.isEmpty()) return false
        val ch = allChannels.getOrNull(currentChannelIndex) ?: return false
        val engineMode = if (::profileStore.isInitialized) profileStore.getLiveTvEngineMode() else LiveTvEngineMode.AUTO_OTT_HEAL
        val altUrl = LiveTvEngineRouter.buildAlternativeXtreamUrl(ch.streamUrl, ch.backupUrl)
        val nextStage = LiveTvEngineRouter.nextHealStage(
            current = currentLiveHealStage,
            hasBackupUrl = altUrl.isNotBlank(),
            engineMode = engineMode
        ) ?: return false

        currentLiveHealStage = nextStage
        val targetUrl = if (nextStage.usesBackupUrl() && altUrl.isNotBlank()) altUrl else ch.streamUrl
        val cleanUrl = NetworkClient.extractCleanUrlAndRegisterHeaders(targetUrl)
        Log.w("StreamX", "Live TV Auto-Heal -> ${nextStage.shortBadge} for ${ch.name} ($reason)")

        if (nextStage.usesLibVlc()) {
            val note = "⚡ Auto-Heal: ${nextStage.shortBadge}..."
            startLiveTvWithLibVlc(cleanUrl, forceSoftware = nextStage.forcesSoftwareDecoder(), statusNote = note)
            return true
        } else {
            usingBackupStream = true
            playSpecificStreamUrl(targetUrl, forceReload = true)
            return true
        }
    }

    private fun showLiveTvEngineSelectorDialog() {
        val current = if (::profileStore.isInitialized) profileStore.getLiveTvEngineMode() else LiveTvEngineMode.AUTO_OTT_HEAL
        val opts = LiveTvEngineMode.values().map { mode ->
            GlassModalOption(
                iconRes = R.drawable.ic_3d_rocket,
                title = mode.displayLabel,
                subtitle = when (mode) {
                    LiveTvEngineMode.AUTO_OTT_HEAL -> "Fast Media3 zapping + instant OTT LibVLC HW/SW auto-heal for AC3/1080i50/black screen (Recommended)"
                    LiveTvEngineMode.LIBVLC_HW -> "Always use OTT-grade LibVLC Hardware + Auto Software decoder for Live TV"
                    LiveTvEngineMode.LIBVLC_SW -> "Force LibVLC FFmpeg Software decoder (best for stubborn HD/interlaced channels)"
                    LiveTvEngineMode.MEDIA3_ONLY -> "Use Media3 ExoPlayer only without LibVLC fallback"
                },
                badgeText = if (mode == current) "ACTIVE ✓" else mode.id,
                isHighlighted = mode == current
            ) {
                profileStore.setLiveTvEngineMode(mode)
                Toast.makeText(this, "🚀 Live TV Engine: ${mode.displayLabel}", Toast.LENGTH_SHORT).show()
                if (activePlaybackMode == ActivePlaybackMode.LIVE_TV && allChannels.isNotEmpty()) {
                    startPlaybackForCurrentChannel(forceReload = true)
                }
            }
        } + GlassModalOption(
            iconRes = R.drawable.ic_3d_sync,
            title = "Reset Remembered Per-Channel Engines",
            subtitle = "Clear auto-learned LibVLC channel overrides so all channels re-probe freshly",
            badgeText = "RESET",
            isHighlighted = false
        ) {
            profileStore.clearChannelWinningEngines()
            Toast.makeText(this, "✓ Cleared remembered per-channel engines", Toast.LENGTH_SHORT).show()
        }
        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_rocket,
            title = "OTT Live TV Playback Engine",
            subtitle = "Choose how Live TV decodes AC3 6ch, 1080i50 & Xtream streams",
            badgeText = current.id,
            options = opts,
            closeLabel = "Close"
        )
    }

    @OptIn(UnstableApi::class)
    private fun buildOttConfiguredMediaSource(
        cleanUrl: String,
        mediaItem: androidx.media3.common.MediaItem,
        drmConfig: NetworkClient.StreamDrmConfig
    ): MediaSource? {
        return runCatching {
            val okHttpFactory = OkHttpDataSource.Factory(NetworkClient.streamClient)
                .setUserAgent(NetworkClient.resolveEffectiveUserAgent(null))
            val preloadAwareFactory = StreamPreFetcher.createPreloadAwareDataSourceFactory(okHttpFactory)

            val drmManager: DrmSessionManager? = if (drmConfig.hasDrm()) {
                val lt = drmConfig.licenseType.trim().lowercase(Locale.ROOT)
                val uuid = when {
                    lt.contains("clearkey") -> C.CLEARKEY_UUID
                    lt.contains("widevine") -> C.WIDEVINE_UUID
                    lt.contains("playready") -> C.PLAYREADY_UUID
                    else -> C.CLEARKEY_UUID
                }
                val rawKey = drmConfig.licenseKey.trim()
                val callback = if (uuid == C.CLEARKEY_UUID &&
                    !rawKey.startsWith("http://", ignoreCase = true) &&
                    !rawKey.startsWith("https://", ignoreCase = true)
                ) {
                    val jwkJson = NetworkClient.buildClearKeyJwkJson(rawKey)
                    if (jwkJson != null) LocalMediaDrmCallback(jwkJson.toByteArray(Charsets.UTF_8)) else null
                } else {
                    val pipeIdx = rawKey.indexOf('|')
                    val licUrl = if (pipeIdx > 0) rawKey.substring(0, pipeIdx).trim() else rawKey
                    val httpCb = HttpMediaDrmCallback(licUrl, okHttpFactory)
                    if (pipeIdx > 0 && pipeIdx < rawKey.lastIndex) {
                        for (pair in rawKey.substring(pipeIdx + 1).split('&')) {
                            val eq = pair.indexOf('=')
                            if (eq > 0) {
                                val hk = pair.substring(0, eq).trim()
                                val hv = pair.substring(eq + 1).trim()
                                if (hk.isNotEmpty() && hv.isNotEmpty()) {
                                    httpCb.setKeyRequestProperty(hk, hv)
                                }
                            }
                        }
                    }
                    httpCb
                }
                if (callback != null) {
                    DefaultDrmSessionManager.Builder()
                        .setUuidAndExoMediaDrmProvider(uuid, FrameworkMediaDrm.DEFAULT_PROVIDER)
                        .setMultiSession(true)
                        .setPlayClearSamplesWithoutKeys(true)
                        .build(callback)
                } else {
                    null
                }
            } else {
                null
            }

            val mt = drmConfig.manifestType.trim().lowercase(Locale.ROOT)
            val format = StreamPreFetcher.detectStreamFormat(cleanUrl)
            val isDash = mt == "mpd" || mt == "dash" || mt == "application/dash+xml" || format == StreamPreFetcher.StreamFormat.DASH
            val isHls = mt == "hls" || mt == "m3u8" || mt == "application/x-mpegurl" || format == StreamPreFetcher.StreamFormat.HLS

            val resilientLoadPolicy = DefaultLoadErrorHandlingPolicy(4)
            when {
                isDash -> {
                    val dashFactory = DashMediaSource.Factory(preloadAwareFactory)
                        .setLoadErrorHandlingPolicy(resilientLoadPolicy)
                    if (drmManager != null) dashFactory.setDrmSessionManagerProvider { drmManager }
                    val dashItem = mediaItem.buildUpon().setMimeType(MimeTypes.APPLICATION_MPD).build()
                    dashFactory.createMediaSource(dashItem)
                }
                isHls -> {
                    val hlsExtractor = DefaultHlsExtractorFactory(
                        DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES or
                            DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS,
                        true
                    )
                    val hlsFactory = HlsMediaSource.Factory(preloadAwareFactory)
                        .setExtractorFactory(hlsExtractor)
                        .setLoadErrorHandlingPolicy(resilientLoadPolicy)
                        .setAllowChunklessPreparation(false)
                    if (drmManager != null) hlsFactory.setDrmSessionManagerProvider { drmManager }
                    val hlsItem = mediaItem.buildUpon().setMimeType(MimeTypes.APPLICATION_M3U8).build()
                    hlsFactory.createMediaSource(hlsItem)
                }
                else -> {
                    val defFactory = DefaultMediaSourceFactory(preloadAwareFactory)
                        .setLoadErrorHandlingPolicy(resilientLoadPolicy)
                    if (drmManager != null) defFactory.setDrmSessionManagerProvider { drmManager }
                    defFactory.createMediaSource(mediaItem)
                }
            }
        }.getOrNull()
    }

    private fun showZappingOsd() {
        osdBanner.alpha = 1f
        osdBanner.visibility = View.VISIBLE
        topControlBar.visibility = View.VISIBLE
        uiHandler.removeCallbacks(hideOsdRunnable)
        val osdTimeoutMs = if (::profileStore.isInitialized) profileStore.getOsdTimeoutMs() else 3500L
        uiHandler.postDelayed(hideOsdRunnable, osdTimeoutMs)
    }

    private fun togglePlayerLock() {
        isPlayerLocked = !isPlayerLocked
        val msg = if (isPlayerLocked) {
            "🔒 Player Locked — Press OK or Menu to unlock"
        } else {
            "🔓 Player Unlocked"
        }
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun launchInExternalPlayer(url: String, title: String) {
        if (url.isBlank()) {
            Toast.makeText(this, "No active stream URL to open externally", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            exoPlayer?.pause()
            val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                setDataAndType(android.net.Uri.parse(url), "video/*")
                putExtra("title", title)
                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(android.content.Intent.createChooser(intent, "Open with External Player"))
        } catch (e: Exception) {
            Toast.makeText(this, "No external video player app found on this TV", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showSleepTimerCustomDialog() {
        val btnSleep = findViewById<Button>(R.id.btnSleepTimer)
        fun applySleep(mins: Int) {
            sleepMinutes = mins
            uiHandler.removeCallbacks(sleepRunnable)
            if (mins > 0) {
                uiHandler.postDelayed(sleepRunnable, mins * 60 * 1000L)
                btnSleep.text = "Sleep: ${mins}m"
                Toast.makeText(this, "Sleep Timer set for $mins mins", Toast.LENGTH_SHORT).show()
            } else {
                btnSleep.text = "Sleep: OFF"
                Toast.makeText(this, "Sleep Timer turned OFF", Toast.LENGTH_SHORT).show()
            }
        }
        val presets = listOf(15, 30, 45, 60, 90, 0)
        val options = presets.map { mins ->
            GlassModalOption(
                iconRes = R.drawable.ic_3d_sleep,
                title = if (mins == 0) "Turn Sleep Timer OFF" else "Sleep After $mins Minutes",
                subtitle = if (mins == 0) "Cancel active sleep countdown" else "Automatically pause playback after $mins minutes",
                badgeText = if (sleepMinutes == mins) "ACTIVE ✓" else if (mins == 0) "OFF" else "${mins}m",
                isHighlighted = sleepMinutes == mins
            ) {
                applySleep(mins)
            }
        } + GlassModalOption(
            iconRes = R.drawable.ic_3d_sleep,
            title = "Custom Sleep Timer (Minutes)",
            subtitle = "Enter any custom duration between 5 and 240 minutes",
            badgeText = "CUSTOM"
        ) {
            val input = EditText(this).apply {
                inputType = android.text.InputType.TYPE_CLASS_NUMBER
                hint = "Minutes (e.g. 25)"
                setTextColor(Color.WHITE)
                setHintTextColor(0xFF94A3B8.toInt())
            }
            AlertDialog.Builder(this, R.style.Theme_StreamX_GlassDialog)
                .setTitle("Custom Sleep Timer")
                .setView(input)
                .setPositiveButton("Set") { _, _ ->
                    val mins = input.text?.toString()?.trim()?.toIntOrNull()?.coerceIn(5, 240)
                    if (mins != null) applySleep(mins)
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_sleep,
            title = "RAM PLAYER Sleep Timer",
            subtitle = if (sleepMinutes > 0) "Active countdown: ${sleepMinutes}m" else "Currently OFF",
            badgeText = if (sleepMinutes > 0) "${sleepMinutes}m" else "OFF",
            options = options,
            closeLabel = "Close"
        )
    }

    // =========================================================================
    // v18.1 PREDICTABLE REMOTE NAVIGATION & BACK-STACK HANDLING
    // (Requirement 5, 6, 7:
    //  - Movie playback → Movie Details → Movies grid
    //  - Series episode playback → Episode list → Series grid
    //  - Live TV playback → Existing Live TV interface)
    // =========================================================================

    // =========================================================================
    // v18.1 NEXT-GEN ULTRA UPGRADE: CINEMATIC HOME HUB, GLOBAL QUICK MENU,
    // 15-CATEGORY SETTINGS CENTER, PLAYLIST HEALTH, STORAGE, BACKUP & RECOVERY
    // =========================================================================

    private fun handleConfigurableLongPressOk() {
        val action = if (::profileStore.isInitialized) profileStore.getLongPressOkAction() else "QUICK_MENU"
        when (action) {
            "FAVORITE_TOGGLE" -> {
                toggleCurrentChannelFavorite()
                showZappingOsd()
            }
            "CHANNEL_INFO" -> showLiveChannelManagementModal()
            "EPG_GUIDE" -> showEpgGuideHubDialog()
            else -> showGlobalQuickMenuDialog()
        }
    }

    private fun showGlobalQuickMenuDialog() {
        val ch = allChannels.getOrNull(currentChannelIndex)
        val nowPlayingSummary = when (activePlaybackMode) {
            ActivePlaybackMode.VOD_MOVIE -> "Playing Movie: ${activeVodMovieDetailInfo?.title ?: activeVodMovieItem?.name ?: "VOD Movie"}"
            ActivePlaybackMode.SERIES_EPISODE -> "Playing Series: ${activeSeriesGroup?.title ?: "Series"} • S${activeSeriesSeasonNum}E${activeSeriesEpisodeItem?.episodeNumber ?: 1}"
            ActivePlaybackMode.VOD_TRAILER -> "Playing Trailer: ${activeVodMovieDetailInfo?.title ?: "Movie Trailer"}"
            ActivePlaybackMode.LIVE_TV -> {
                val suspended = LiveTvBackgroundPlaybackController.peekSuspendedState()
                if (suspended.wasSuspended || currentPlayingStreamUrl.isEmpty()) {
                    "Live TV Paused: ${ch?.name ?: "Channel"} (#${ch?.displayNumberFormatted() ?: "001"})"
                } else {
                    "Watching Live TV: ${ch?.name ?: "Channel"} (#${ch?.displayNumberFormatted() ?: "001"})"
                }
            }
        }

        val options = listOf(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_home,
                title = "🏠 Cinematic Home Screen Hub",
                subtitle = "Hero banner, Continue Watching, Recently Watched, Watchlists & Personalized Rows",
                badgeText = "HOME",
                isHighlighted = true
            ) {
                showCinematicHomeHubDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_live_tv,
                title = "📺 Live TV (${allChannels.size} Channels)",
                subtitle = "Return to Live TV channel browsing or resume ${ch?.name ?: "selected channel"}",
                badgeText = "LIVE TV"
            ) {
                vodPosterGridPanel.visibility = View.GONE
                activePlaybackMode = ActivePlaybackMode.LIVE_TV
                startPlaybackForCurrentChannel(forceReload = true)
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_movies,
                title = "🎬 VOD Movies Library (${vodMoviesCatalog.size})",
                subtitle = "Browse Movies poster grid, categories, ratings & trailers (stops Live TV in background)",
                badgeText = "MOVIES"
            ) {
                switchToEntertainmentSection(EntertainmentSection.MOVIES)
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_series,
                title = "📺 VOD Series Library (${seriesCatalogGroups.size})",
                subtitle = "Browse Series poster grid, seasons & episodes (stops Live TV in background)",
                badgeText = "SERIES"
            ) {
                switchToEntertainmentSection(EntertainmentSection.SERIES)
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_search,
                title = "🔍 Universal Smart Search",
                subtitle = "Typo-tolerant search across Live TV, Channel Numbers, Movies, Series & Categories",
                badgeText = "SEARCH"
            ) {
                showUnifiedSearchDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_history,
                title = "▶ Continue Watching & Watch History",
                subtitle = "Resume Movies/Episodes, mark watched/unwatched, or clear watch history",
                badgeText = "HISTORY"
            ) {
                showContinueWatchingAndHistoryDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_star,
                title = "★ Favorites, Watchlists & Custom Collections",
                subtitle = "Manage Live TV Favorites, Movie/Series Watchlists & Custom Channel Groups",
                badgeText = "FAVORITES"
            ) {
                showFavoritesAndCustomCollectionsDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_channels,
                title = "🎛️ Live Channel Options (Sort, Rename, Hide, Group)",
                subtitle = "Manage ${ch?.name ?: "current channel"} or sort/unhide Live TV channels",
                badgeText = activeLiveChannelSortOrder.badgeLabel
            ) {
                showLiveChannelManagementModal()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_audio_hd,
                title = "🔊 Audio, Subtitles, Playback Speed & Seek Step",
                subtitle = "Configure audio tracks, subtitles, VOD speed (${profileStore.getVodPlaybackSpeed()}x) & seek (${profileStore.getSeekStepMs() / 1000}s)",
                badgeText = "PLAYER"
            ) {
                showAudioAndQualityDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_play,
                title = if (isPlayerLocked) "🔓 Unlock Player Controls" else "🔒 Lock Player (Prevent Accidental Presses)",
                subtitle = if (isPlayerLocked) "Remote navigation keys are currently locked" else "Block accidental channel zap & back presses during playback",
                badgeText = if (isPlayerLocked) "LOCKED" else "UNLOCKED",
                isHighlighted = isPlayerLocked
            ) {
                togglePlayerLock()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_rocket,
                title = "📺 Open Active Stream in External Player",
                subtitle = "Launch current Live/VOD stream in VLC, MX Player, or system video player",
                badgeText = "EXTERNAL"
            ) {
                launchInExternalPlayer(currentPlayingStreamUrl, nowPlayingSummary)
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_theme,
                title = "⚙️ Complete 15-Category Settings Center",
                subtitle = "All Playback, Buffer, Network, Performance, Appearance, Remote, EPG, Storage & Backup settings",
                badgeText = "SETTINGS"
            ) {
                showCategorizedSettingsCenterDialog()
            }
        )

        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_rocket,
            title = "RAM PLAYER Global Quick Menu",
            subtitle = nowPlayingSummary,
            badgeText = "QUICK JUMP",
            options = options,
            closeLabel = "Close"
        )
    }

    private fun showCinematicHomeHubDialog() {
        suspendLiveTvForNonLiveSection("Home Hub")
        val continueList = if (::profileStore.isInitialized) {
            profileStore.getContinueWatchingEntries(activeAccountScope)
        } else emptyList()
        val movieWl = if (::profileStore.isInitialized) {
            profileStore.getMovieWatchlistIds(activeAccountScope)
        } else emptySet()
        val seriesWl = if (::profileStore.isInitialized) {
            profileStore.getSeriesWatchlistIds(activeAccountScope)
        } else emptySet()
        val customGroups = if (::profileStore.isInitialized) {
            profileStore.getCustomChannelGroups(activeAccountScope)
        } else emptyMap()

        val hero = PersonalizationEngine.selectCinematicHeroItem(
            continueWatching = continueList,
            vodMovies = vodMoviesCatalog,
            vodIndexById = vodMovieIndexById,
            seriesGroups = seriesCatalogGroups,
            liveChannels = allChannels,
            currentChannelIndex = currentChannelIndex
        )

        val options = ArrayList<GlassModalOption>(14)

        val rowOrder = profileStore.getHomeRowOrder(activeAccountScope)
        val hiddenRows = profileStore.getHiddenHomeRows(activeAccountScope)

        // 1. Cinematic Hero Action Banner Row (Always visible)
        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_play,
                title = "★ Featured / Hero: ${hero.headline}",
                subtitle = hero.subtitle,
                badgeText = hero.badgeText,
                isHighlighted = true
            ) {
                when (hero.contentType) {
                    ContentSourceType.XTREAM_VOD_MOVIE -> {
                        if (hero.targetIndex in vodMoviesCatalog.indices) showMovieDetailModal(hero.targetIndex)
                    }
                    ContentSourceType.XTREAM_SERIES, ContentSourceType.XTREAM_SERIES_EPISODE -> {
                        if (hero.seriesSummary != null) showSeriesDetailModal(hero.seriesSummary)
                    }
                    ContentSourceType.M3U_LIVE, ContentSourceType.XTREAM_LIVE -> {
                        vodPosterGridPanel.visibility = View.GONE
                        activePlaybackMode = ActivePlaybackMode.LIVE_TV
                        switchChannel(hero.targetIndex.coerceIn(0, (allChannels.size - 1).coerceAtLeast(0)), immediatePlayback = true)
                    }
                }
            }
        )

        val pinnedIds = profileStore.getPinnedChannelIds(activeAccountScope)
        val totalSaved = favoriteIds.size + movieWl.size + seriesWl.size
        for (rowId in rowOrder) {
            if (hiddenRows.contains(rowId)) continue
            when (rowId) {
                "CONTINUE_WATCHING" -> options.add(
                    GlassModalOption(
                        iconRes = R.drawable.ic_3d_history,
                        title = "▶ Continue Watching (${continueList.size} Active Items)",
                        subtitle = if (continueList.isNotEmpty()) "Resume Movies & Series Episodes from your exact saved timestamp" else "No Movies or Episodes in progress yet",
                        badgeText = "${continueList.size} RESUME"
                    ) { showContinueWatchingAndHistoryDialog() }
                )
                "PINNED_CHANNELS" -> options.add(
                    GlassModalOption(
                        iconRes = R.drawable.ic_3d_star,
                        title = "📌 Pinned Live Channels (${pinnedIds.size})",
                        subtitle = "Jump directly to your pinned channels",
                        badgeText = "${pinnedIds.size} PINNED"
                    ) { showFavoritesAndCustomCollectionsDialog() }
                )
                "RECENT_LIVE" -> options.add(
                    GlassModalOption(
                        iconRes = R.drawable.ic_3d_live_tv,
                        title = "⟲ Recently Watched Live TV Channels (${recentIds.size})",
                        subtitle = "Quickly tune back to your recently watched television channels",
                        badgeText = "${recentIds.size} RECENT"
                    ) {
                        vodPosterGridPanel.visibility = View.GONE
                        activeTab = "RECENT"
                        updateTabButton3dSelection("RECENT")
                        renderDrawerList()
                        openDrawerAndRequestFocus()
                    }
                )
                "FAVORITES_LIVE" -> options.add(
                    GlassModalOption(
                        iconRes = R.drawable.ic_3d_star,
                        title = "★ Personal Watchlist & Favorites ($totalSaved Saved)",
                        subtitle = "${favoriteIds.size} Live TV Favorites • ${movieWl.size} Movies • ${seriesWl.size} Series • ${customGroups.size} Custom Groups",
                        badgeText = "WATCHLIST"
                    ) { showFavoritesAndCustomCollectionsDialog() }
                )
                "MOVIES_WATCHLIST" -> options.add(
                    GlassModalOption(
                        iconRes = R.drawable.ic_3d_movies,
                        title = "🎬 VOD Movies (${vodMoviesCatalog.size})",
                        subtitle = if (activeSourceType == ProfileType.XTREAM) "Browse provider VOD Movies poster grid" else "Connect Xtream Codes for VOD Movies",
                        badgeText = "MOVIES"
                    ) { switchToEntertainmentSection(EntertainmentSection.MOVIES) }
                )
                "SERIES_WATCHLIST" -> options.add(
                    GlassModalOption(
                        iconRes = R.drawable.ic_3d_series,
                        title = "📺 VOD Series (${seriesCatalogGroups.size})",
                        subtitle = if (activeSourceType == ProfileType.XTREAM) "Browse provider VOD Series with Seasons & Episodes" else "Connect Xtream Codes for VOD Series",
                        badgeText = "SERIES"
                    ) { switchToEntertainmentSection(EntertainmentSection.SERIES) }
                )
                "CUSTOM_GROUPS" -> options.add(
                    GlassModalOption(
                        iconRes = R.drawable.ic_3d_category,
                        title = "📂 Custom Channel Collections (${customGroups.size})",
                        subtitle = "Browse your custom organized channel groups",
                        badgeText = "${customGroups.size} GROUPS"
                    ) { showFavoritesAndCustomCollectionsDialog() }
                )
            }
        }

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_settings,
                title = "🎛️ Customize Home Rows (Show / Hide / Reorder)",
                subtitle = "Hide or reorder Home Hub rows per profile",
                badgeText = "CUSTOMIZE"
            ) { showHomeRowCustomizationDialog() }
        )

        // 7. Live TV Quick Access Row
        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_channels,
                title = "📡 Live TV Channels & EPG Guide (${allChannels.size} Channels)",
                subtitle = "Browse Live TV categories, What's On Now EPG guide & custom collections",
                badgeText = "LIVE TV"
            ) {
                switchToEntertainmentSection(EntertainmentSection.LIVE_TV)
            }
        )

        // 8. Universal Smart Search
        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_search,
                title = "🔍 Universal Smart Search",
                subtitle = "Instant typo-tolerant search across Live TV, Movies, Series & Categories",
                badgeText = "SEARCH"
            ) {
                showUnifiedSearchDialog()
            }
        )

        // 9. Complete 15-Category Settings Center
        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_theme,
                title = "⚙️ 15-Category Settings, Diagnostics & Backup Center",
                subtitle = "Playback, Buffer, Performance, Density, Overscan, Playlist Health, Storage & Backup",
                badgeText = "SETTINGS"
            ) {
                showCategorizedSettingsCenterDialog()
            }
        )

        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_home,
            title = "RAM PLAYER Cinematic Home Hub",
            subtitle = "Profile: ${activeXtreamCreds?.profileName ?: activeM3uLabel} • ${allChannels.size} Live • ${vodMoviesCatalog.size} Movies • ${seriesCatalogGroups.size} Series",
            badgeText = profileStore.getUiDensityMode().id,
            options = options,
            closeLabel = "Back"
        )
    }

    private fun showContinueWatchingAndHistoryDialog() {
        val continueList = profileStore.getContinueWatchingEntries(activeAccountScope)
        val watchedIds = profileStore.getWatchedContentIds(activeAccountScope)
        val options = ArrayList<GlassModalOption>(continueList.size + 4)

        for (entry in continueList.take(25)) {
            if (entry.contentType == ContentSourceType.XTREAM_VOD_MOVIE) {
                val mIdx = vodMovieIndexById[entry.contentId]
                val movie = if (mIdx != null) vodMoviesCatalog.getOrNull(mIdx) else null
                if (movie != null && mIdx != null) {
                    val mins = (entry.positionMs / 60_000L).coerceAtLeast(1L)
                    options.add(
                        GlassModalOption(
                            iconRes = R.drawable.ic_3d_movies,
                            title = "▶ [MOVIE] ${movie.cleanMovieDisplayTitle()} (${entry.progressPercent()}%)",
                            subtitle = "Watched $mins min • ${movie.category} • Tap to open Movie Details / Resume",
                            badgeText = "${entry.progressPercent()}%",
                            isHighlighted = true
                        ) {
                            showMovieDetailModal(mIdx)
                        }
                    )
                }
            } else if (entry.contentType == ContentSourceType.XTREAM_SERIES_EPISODE) {
                val grp = seriesCatalogGroups.firstOrNull { it.seriesKey == entry.seriesKey }
                if (grp != null) {
                    val mins = (entry.positionMs / 60_000L).coerceAtLeast(1L)
                    options.add(
                        GlassModalOption(
                            iconRes = R.drawable.ic_3d_series,
                            title = "▶ [SERIES] ${grp.title} • S${entry.seasonNumber}E${entry.episodeNumber} (${entry.progressPercent()}%)",
                            subtitle = "Watched $mins min • ${grp.category} • Tap to open Season ${entry.seasonNumber}",
                            badgeText = "${entry.progressPercent()}%",
                            isHighlighted = true
                        ) {
                            showSeriesDetailModal(grp, entry.seasonNumber)
                        }
                    )
                }
            }
        }

        if (continueList.isNotEmpty()) {
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_trash,
                    title = "Clear All Continue Watching Progress (${continueList.size} Items)",
                    subtitle = "Remove all in-progress resume points for the active profile",
                    badgeText = "CLEAR"
                ) {
                    profileStore.clearAllContinueWatching(activeAccountScope)
                    Toast.makeText(this, "Cleared Continue Watching list", Toast.LENGTH_SHORT).show()
                    if (vodPosterGridPanel.visibility == View.VISIBLE) renderVodPosterGrid()
                }
            )
        }

        if (watchedIds.isNotEmpty()) {
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_trash,
                    title = "Clear Completed Watch History (${watchedIds.size} Watched Items)",
                    subtitle = "Reset watched checkmarks for Movies and Series Episodes in this profile",
                    badgeText = "RESET"
                ) {
                    profileStore.clearWatchedHistory(activeAccountScope)
                    Toast.makeText(this, "Cleared completed watch history", Toast.LENGTH_SHORT).show()
                }
            )
        }

        if (options.isEmpty()) {
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_movies,
                    title = "No Continue Watching Items Yet",
                    subtitle = "Movies and Series Episodes you watch for at least 10 seconds appear here automatically (Live TV is excluded)",
                    badgeText = "EMPTY"
                ) {}
            )
        }

        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_history,
            title = "Continue Watching & Watch History",
            subtitle = "${continueList.size} In-Progress • ${watchedIds.size} Completed (Per-Profile Isolated)",
            badgeText = "PROGRESS",
            options = options,
            closeLabel = "Back"
        )
    }

    private fun showFavoritesAndCustomCollectionsDialog() {
        val movieWl = profileStore.getMovieWatchlistIds(activeAccountScope)
        val seriesWl = profileStore.getSeriesWatchlistIds(activeAccountScope)
        val customGroups = profileStore.getCustomChannelGroups(activeAccountScope)

        val options = ArrayList<GlassModalOption>(16)

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_live_tv,
                title = "★ Live TV Favorite Channels (${favoriteIds.size})",
                subtitle = "Open Live TV drawer filtered to your starred favorite channels",
                badgeText = "${favoriteIds.size} CH",
                isHighlighted = favoriteIds.isNotEmpty()
            ) {
                vodPosterGridPanel.visibility = View.GONE
                activeTab = "FAV"
                updateTabButton3dSelection("FAV")
                renderDrawerList()
                openDrawerAndRequestFocus()
            }
        )

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_movies,
                title = "🎬 Movies Watchlist (${movieWl.size})",
                subtitle = "Open Movies poster grid filtered to your saved Movies Watchlist",
                badgeText = "${movieWl.size} MOVIES"
            ) {
                selectedVodCategory = "FAVORITES / WATCHLIST"
                vodSpecialFilterMode = "FAV"
                updateSectionButtonsUi(EntertainmentSection.MOVIES)
                openVodPosterHub(EntertainmentSection.MOVIES)
            }
        )

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_series,
                title = "📺 Series Watchlist (${seriesWl.size})",
                subtitle = "Open Series poster grid filtered to your saved Series Watchlist",
                badgeText = "${seriesWl.size} SERIES"
            ) {
                selectedVodCategory = "FAVORITES / WATCHLIST"
                vodSpecialFilterMode = "FAV"
                updateSectionButtonsUi(EntertainmentSection.SERIES)
                openVodPosterHub(EntertainmentSection.SERIES)
            }
        )

        for ((groupName, ids) in customGroups) {
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_category,
                    title = "📂 Collection: $groupName (${ids.size} Channels)",
                    subtitle = "Tap to browse channels in '$groupName' or manage collection",
                    badgeText = "${ids.size} CH"
                ) {
                    showCustomGroupChannelsDialog(groupName, ids)
                }
            )
        }

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_category,
                title = "+ Add Current Channel to a Custom Collection",
                subtitle = "Create a new group (e.g. 'Sports VIP', 'Kids', 'Morning News') or add current channel",
                badgeText = "NEW GROUP"
            ) {
                promptAddChannelToCustomCollection(allChannels.getOrNull(currentChannelIndex))
            }
        )

        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_star,
            title = "Favorites, Watchlists & Custom Collections",
            subtitle = "Profile-isolated Live TV Favorites, Movie/Series Watchlists & Custom Channel Groups",
            badgeText = "COLLECTIONS",
            options = options,
            closeLabel = "Back"
        )
    }

    private fun showCustomGroupChannelsDialog(groupName: String, channelIds: Set<String>) {
        val matchedIndices = allChannels.indices.filter { channelIds.contains(allChannels[it].id) }
        val options = ArrayList<GlassModalOption>(matchedIndices.size + 2)
        for (idx in matchedIndices) {
            val ch = allChannels[idx]
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_live_tv,
                    title = "${ch.displayNumberFormatted()} • ${ch.name}",
                    subtitle = "${ch.category} • Tap to watch Live TV",
                    badgeText = "WATCH"
                ) {
                    vodPosterGridPanel.visibility = View.GONE
                    activePlaybackMode = ActivePlaybackMode.LIVE_TV
                    switchChannel(idx, immediatePlayback = true)
                }
            )
        }
        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_trash,
                title = "Delete Custom Collection '$groupName'",
                subtitle = "Removes this custom group without deleting any channels from your playlist",
                badgeText = "DELETE"
            ) {
                profileStore.deleteCustomChannelGroup(groupName, activeAccountScope)
                Toast.makeText(this, "Deleted collection '$groupName'", Toast.LENGTH_SHORT).show()
                showFavoritesAndCustomCollectionsDialog()
            }
        )
        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_category,
            title = "Custom Collection: $groupName",
            subtitle = "${matchedIndices.size} Channels in this collection",
            badgeText = "GROUP",
            options = options,
            closeLabel = "Back"
        )
    }

    private fun promptAddChannelToCustomCollection(ch: Channel?) {
        if (ch == null) return
        show4dGlassFormModal(
            headerIconRes = R.drawable.ic_3d_category,
            title = "Add '${ch.name}' to Custom Collection",
            subtitle = "Enter a collection name (e.g. Sports VIP, Family, News, Evening)",
            badgeText = "COLLECTION",
            fields = listOf(
                GlassFormFieldSpec(
                    label = "COLLECTION / GROUP NAME",
                    hint = "Sports VIP",
                    iconRes = R.drawable.ic_3d_category,
                    initialValue = "My Top Channels"
                )
            ),
            positiveLabel = "Save to Collection",
            positiveBgRes = R.drawable.bg_btn_3d_cyan
        ) { vals ->
            val groupName = vals.firstOrNull()?.trim().orEmpty()
            if (groupName.isNotBlank()) {
                profileStore.addChannelToCustomGroup(groupName, ch.id, activeAccountScope)
                Toast.makeText(this, "Added '${ch.name}' to '$groupName'", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showLiveChannelManagementModal() {
        val ch = allChannels.getOrNull(currentChannelIndex)
        val hiddenIds = profileStore.getHiddenChannelIds(activeAccountScope)
        val options = ArrayList<GlassModalOption>(10)

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_channels,
                title = "Sort Live TV Channels: ${activeLiveChannelSortOrder.fullTitle}",
                subtitle = "Tap to cycle: Channel Number → A-Z → Z-A → Category → Recently Watched",
                badgeText = activeLiveChannelSortOrder.badgeLabel,
                isHighlighted = true
            ) {
                activeLiveChannelSortOrder = activeLiveChannelSortOrder.nextOrder()
                Toast.makeText(this, "Live TV Sort: ${activeLiveChannelSortOrder.fullTitle}", Toast.LENGTH_SHORT).show()
                renderDrawerList()
            }
        )

        if (ch != null) {
            val isFav = favoriteIds.contains(ch.id)
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_star,
                    title = if (isFav) "★ Remove '${ch.name}' from Favorites" else "☆ Add '${ch.name}' to Favorites",
                    subtitle = "Channel #${ch.displayNumberFormatted()} • ${ch.category}",
                    badgeText = if (isFav) "FAVORITE ★" else "+ FAV"
                ) {
                    toggleCurrentChannelFavorite()
                }
            )

            val isPinned = profileStore.isChannelPinned(ch.id, activeAccountScope)
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_star,
                    title = if (isPinned) "📌 Unpin '${ch.name}' from Quick Bar" else "📌 Pin '${ch.name}' to Quick Bar",
                    subtitle = "Pinned channels appear first in your Cinematic Home Hub",
                    badgeText = if (isPinned) "PINNED ★" else "PIN"
                ) {
                    val nowPinned = profileStore.togglePinnedChannel(ch.id, activeAccountScope)
                    Toast.makeText(this, if (nowPinned) "📌 Pinned '${ch.name}'" else "Unpinned '${ch.name}'", Toast.LENGTH_SHORT).show()
                    showLiveChannelManagementModal()
                }
            )

            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_category,
                    title = "📂 Add '${ch.name}' to Custom Collection",
                    subtitle = "Organize into your own custom channel group",
                    badgeText = "GROUP"
                ) {
                    promptAddChannelToCustomCollection(ch)
                }
            )

            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_channels,
                    title = "✏️ Rename Channel '${ch.name}'",
                    subtitle = "Set a custom display alias for this channel in your profile",
                    badgeText = "RENAME"
                ) {
                    show4dGlassFormModal(
                        headerIconRes = R.drawable.ic_3d_channels,
                        title = "Custom Channel Name",
                        subtitle = "Original name: ${ch.name}",
                        badgeText = "ALIAS",
                        fields = listOf(
                            GlassFormFieldSpec(
                                label = "CUSTOM DISPLAY NAME (LEAVE BLANK TO RESET)",
                                hint = ch.name,
                                iconRes = R.drawable.ic_3d_channels,
                                initialValue = ch.name
                            )
                        ),
                        positiveLabel = "Save Name",
                        positiveBgRes = R.drawable.bg_btn_3d_cyan
                    ) { vals ->
                        val newName = vals.firstOrNull()?.trim().orEmpty()
                        profileStore.setCustomChannelName(ch.id, newName, activeAccountScope)
                        if (newName.isNotBlank()) {
                            val mutable = allChannels.toMutableList()
                            mutable[currentChannelIndex] = ch.copy(name = newName)
                            allChannels = mutable
                            updateOsdForCurrentChannel()
                            renderDrawerList()
                            Toast.makeText(this, "Renamed to '$newName'", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            )

            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_trash,
                    title = "🗑️ Delete Channel '${ch.name}' (Move to Recycle Bin)",
                    subtitle = "Removes channel from active list, search & zapping (persists across restarts/refreshes; restorable)",
                    badgeText = "DELETE CH",
                    isHighlighted = true
                ) {
                    showDeleteCurrentChannelConfirmationDialog(ch)
                }
            )

            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_category,
                    title = "🗂️ Category Manager (Delete / Restore Categories)",
                    subtitle = "Delete entire unwanted M3U/Xtream categories or restore deleted categories",
                    badgeText = "CATEGORIES"
                ) {
                    showCategoryManagerDialog()
                }
            )

            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_trash,
                    title = "🙈 Hide Channel '${ch.name}' from Drawer",
                    subtitle = "Hides this channel from Live TV browsing until unhidden",
                    badgeText = "HIDE"
                ) {
                    profileStore.toggleChannelHidden(ch.id, activeAccountScope)
                    Toast.makeText(this, "Hidden '${ch.name}' (Unhide anytime in Channel Options)", Toast.LENGTH_SHORT).show()
                    renderDrawerList()
                }
            )
            val isBlacklisted = profileStore.isChannelBlacklisted(ch.id, activeAccountScope)
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_lock,
                    title = if (isBlacklisted) "🛡️ Unblock '${ch.name}' from Blacklist" else "🚫 Blacklist '${ch.name}' Permanently",
                    subtitle = "Separate from Hide/Unhide — blacklisted channels stay blocked until explicitly unblocked",
                    badgeText = if (isBlacklisted) "BLOCKED" else "BLACKLIST"
                ) {
                    val blocked = profileStore.toggleChannelBlacklist(ch.id, activeAccountScope)
                    Toast.makeText(this, if (blocked) "🚫 Blacklisted '${ch.name}'" else "Unblocked '${ch.name}'", Toast.LENGTH_SHORT).show()
                    renderDrawerList()
                    showLiveChannelManagementModal()
                }
            )
            if (profileStore.isChannelPreviewEnabled(activeAccountScope)) {
                options.add(
                    GlassModalOption(
                        iconRes = R.drawable.ic_3d_play,
                        title = "👁️ Channel Preview Card: '${ch.name}'",
                        subtitle = "Preview channel metadata & EPG without spawning a second player (512MB RAM safe)",
                        badgeText = "PREVIEW"
                    ) {
                        showChannelPreviewCard(ch)
                    }
                )
            }
        }

        val blacklistedIds = profileStore.getBlacklistedChannelIds(activeAccountScope)
        if (blacklistedIds.isNotEmpty()) {
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_lock,
                    title = "🛡️ Manage Channel Blacklist (${blacklistedIds.size} Blocked)",
                    subtitle = "View, unblock individual channels, or clear your persistent channel blacklist",
                    badgeText = "BLACKLIST ${blacklistedIds.size}"
                ) {
                    showChannelBlacklistManagerDialog()
                }
            )
        }

        if (hiddenIds.isNotEmpty()) {
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_sync,
                    title = "👁️ Unhide All Hidden Channels (${hiddenIds.size} Hidden)",
                    subtitle = "Restore all hidden channels back into the Live TV channel list",
                    badgeText = "UNHIDE ${hiddenIds.size}"
                ) {
                    profileStore.unhideAllChannels(activeAccountScope)
                    Toast.makeText(this, "Restored ${hiddenIds.size} hidden channels", Toast.LENGTH_SHORT).show()
                    renderDrawerList()
                }
            )
        }

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_lock,
                title = "🩺 Playlist Health & Smart Duplicate Detector",
                subtitle = "Inspect channel health, missing logos, backup streams & duplicate channels",
                badgeText = "HEALTH"
            ) {
                showPlaylistHealthAndDuplicatesDialog()
            }
        )

        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_channels,
            title = "Live TV Channel Management & Sorting",
            subtitle = "${allChannels.size} Total Channels • ${hiddenIds.size} Hidden • Sort: ${activeLiveChannelSortOrder.fullTitle}",
            badgeText = "CHANNELS",
            options = options,
            closeLabel = "Close"
        )
    }

    /**
     * Section 27: Categorized 15-Section Settings Center.
     */
    private fun showCategorizedSettingsCenterDialog() {
        suspendLiveTvForNonLiveSection("Settings Center")
        val stopBg = profileStore.isStopLiveTvInBackgroundEnabled()
        val autoRec = profileStore.isAutoReconnectLiveTvOnReturnEnabled()
        val seekSec = profileStore.getSeekStepMs() / 1000L
        val vodSpd = profileStore.getVodPlaybackSpeed()
        val density = profileStore.getUiDensityMode()
        val overscan = profileStore.getOverscanMarginDp()
        val clock24 = profileStore.is24HourClockEnabled()
        val reminders = profileStore.getEpgReminders(activeAccountScope)

        val options = listOf(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_search,
                title = "🔍 Search All 24 Settings Categories",
                subtitle = "Instantly jump to any setting (Audio Delay, Subtitle Delay, Blacklist, Auto-Refresh, Privacy, Health...)",
                badgeText = "SEARCH",
                isHighlighted = true
            ) {
                showSearchableSettingsDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_trash,
                title = "🗑️ Permanent Category Delete (Multi-Select)",
                subtitle = "Select unwanted categories (e.g. UK, Pakistani) & permanently delete — never returns on refresh (${profileStore.getPermanentlyDeletedCategories(activeAccountScope).size} deleted)",
                badgeText = "DELETE CATS",
                isHighlighted = true
            ) {
                showPermanentCategoryDeleteDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_network,
                title = "🎭 Player Compatibility & User-Agent (OTT / Smarters / TiviMate)",
                subtitle = "Active: ${NetworkClient.getPreferredUserAgentLabel()} • Auto tries OTT Navigator, IPTV Smarters Pro, TiviMate, VLC, Kodi, ExoPlayer, Chrome TV, Dalvik",
                badgeText = NetworkClient.getPreferredUserAgentProfile(),
                isHighlighted = true
            ) {
                showPlayerUserAgentProfileDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_ram_gauge,
                title = "🩺 App Health Dashboard & Hardware Capabilities",
                subtitle = "Live Media3 status, HDR/Audio capabilities, Storage, Cache, Last & Next Refresh",
                badgeText = "HEALTH"
            ) {
                showAppHealthDashboardDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_trash,
                title = "♻️ Recycle Bin (Restore Deleted Profiles & Groups)",
                subtitle = "${profileStore.getRecycleBinEntries(activeAccountScope).size} soft-deleted items • 30-day retention (separate from Hide/Blacklist)",
                badgeText = "RECYCLE BIN"
            ) {
                showRecycleBinDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_lock,
                title = "🛡️ Privacy Controls & History Management",
                subtitle = "Clear Search History, Watch History, Continue Watching & manage saved credentials",
                badgeText = "PRIVACY"
            ) {
                showPrivacyControlsDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_play,
                title = "1. Playback & Live TV Background Control",
                subtitle = "Bg Stop: ${if (stopBg) "ON" else "OFF"} • Return Auto-Play: ${if (autoRec) "ON" else "OFF"} • Seek: ${seekSec}s • Speed: ${vodSpd}x",
                badgeText = "PLAYBACK",
                isHighlighted = true
            ) {
                showPlaybackAndBackgroundSettingsDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_ram_gauge,
                title = "2. Buffer Profiles (512MB Tuned)",
                subtitle = "Active: ${activeBufferProfile.label} (${activeBufferProfile.playBufferMs}ms start)",
                badgeText = activeBufferProfile.id
            ) {
                showBufferProfileDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_network,
                title = "3. Network & Connectivity Health Center",
                subtitle = "Inspect real connection status, DNS cache, timeouts & Data Saver mode",
                badgeText = "NETWORK"
            ) {
                showRecoveryAndDiagnosticsCenterDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_rocket,
                title = "4. Performance & Adaptive Engine",
                subtitle = "Active: ${activePerformanceMode.title} • Auto / Balanced / Fast / Low-RAM / Saver",
                badgeText = activePerformanceMode.id
            ) {
                showPerformanceModeDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_theme,
                title = "5. Appearance, Home Rows & Sidebar Customization",
                subtitle = "Theme: ${themes[currentThemeIndex].name} • Density: ${density.id} • Overscan: ${overscan}dp • Customize Home/Sidebar",
                badgeText = "DISPLAY"
            ) {
                showAppearanceAndLayoutHubDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_channels,
                title = "6. TV Remote Shortcuts & Key Mapping",
                subtitle = "Long-Press OK: ${profileStore.getLongPressOkAction()} • Seek Step: ${seekSec}s",
                badgeText = "REMOTE"
            ) {
                showRemoteShortcutsSettingsDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_epg,
                title = "7. EPG TV Guide & Programme Reminders",
                subtitle = "${epgMap.size} EPG Channels Indexed • ${reminders.size} Active Reminders",
                badgeText = "EPG GUIDE"
            ) {
                showEpgGuideHubDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_accounts,
                title = "8. Profiles & Multi-Account Manager",
                subtitle = "Switch, create, edit or delete M3U and Xtream Codes accounts safely",
                badgeText = "${profileStore.all().size} PROFILES"
            ) {
                showProfilesDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_lock,
                title = "9. Parental Controls (Salted SHA-256 PIN)",
                subtitle = "Manage 4-digit PIN & locked channel categories (${profileStore.getLockedCategories().size} locked)",
                badgeText = if (profileStore.hasParentalPin()) "LOCKED 🔒" else "OFF"
            ) {
                showParentalPinSettingsDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_trash,
                title = "10. Storage & Cache Manager",
                subtitle = "Inspect SXB2 cache, EPG cache, artwork cache & free device storage safely",
                badgeText = "STORAGE"
            ) {
                showStorageAndCacheManagerDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_playlist,
                title = "11. Playlist Auto-Refresh, Blacklist & Health",
                subtitle = "Auto-Refresh: ${if (profileStore.getAutoRefreshIntervalHours(activeAccountScope) == 0) "OFF" else "${profileStore.getAutoRefreshIntervalHours(activeAccountScope)}h"} • Blacklist: ${profileStore.getBlacklistedChannelIds(activeAccountScope).size} • Health",
                badgeText = "PLAYLIST"
            ) {
                showPlaylistAutoRefreshAndHealthHubDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_lock,
                title = "12. Diagnostics, Playback Telemetry & Recovery Center",
                subtitle = "Real Media3 codec/FPS/bitrate stats, troubleshooting & redacted export",
                badgeText = "DIAGNOSTICS"
            ) {
                showRecoveryAndDiagnosticsCenterDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_subtitles,
                title = "13. Accessibility & TV Viewing Comfort",
                subtitle = "High-Contrast Text: ${if (profileStore.isHighContrastTextEnabled()) "ON" else "OFF"} • Reduced Motion: ${if (activePerformanceMode.reducedAnimations) "ON" else "OFF"}",
                badgeText = "COMFORT"
            ) {
                showAppearanceDensityAndOverscanDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_sync,
                title = "14. Backup & Restore (SXBK_V19) + Reset Defaults",
                subtitle = "Export/import profiles, favorites, watchlists & settings or restore defaults",
                badgeText = "BACKUP"
            ) {
                showBackupAndRestoreDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_rocket,
                title = "15. About, Setup Wizard, Screensaver & Update Center",
                subtitle = "RAM PLAYER v21.0 AMOLED 3D • Idle Screensaver (${profileStore.getIdleScreensaverMinutes()}m) • Setup Wizard",
                badgeText = "v20.0 AMOLED"
            ) {
                showAboutAndUpdateCenterDialog()
            }
        )

        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_theme,
            title = "RAM PLAYER 15-Category Settings Center",
            subtitle = "All settings persist safely per device/profile with zero data loss",
            badgeText = "15 CATEGORIES",
            options = options,
            closeLabel = "Close"
        )
    }

    private fun showPlaybackAndBackgroundSettingsDialog() {
        val stopBg = profileStore.isStopLiveTvInBackgroundEnabled()
        val autoRec = profileStore.isAutoReconnectLiveTvOnReturnEnabled()
        val autoNext = profileStore.isAutoNextEpisodeEnabled()
        val seekSec = profileStore.getSeekStepMs() / 1000L
        val speed = profileStore.getVodPlaybackSpeed()
        val osdSec = profileStore.getOsdTimeoutMs() / 1000L
        val extPlayer = profileStore.isExternalPlayerEnabled()

        val options = listOf(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_live_tv,
                title = "Stop Live TV When Leaving Live TV Screen",
                subtitle = "Immediately stop Live TV audio/video & release buffers when opening Movies, Series, Search or Settings",
                badgeText = if (stopBg) "ON ✓" else "OFF",
                isHighlighted = stopBg
            ) {
                profileStore.setStopLiveTvInBackgroundEnabled(!stopBg)
                showPlaybackAndBackgroundSettingsDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_play,
                title = "Auto-Reconnect Live TV When Returning",
                subtitle = "ON (Default): Automatically reconnects Live TV stream on return or drop",
                badgeText = if (autoRec) "AUTO-PLAY" else "WAIT FOR OK ✓",
                isHighlighted = !autoRec
            ) {
                profileStore.setAutoReconnectLiveTvOnReturnEnabled(!autoRec)
                showPlaybackAndBackgroundSettingsDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_series,
                title = "Smart Auto Next Episode (Series)",
                subtitle = "8-second countdown prompt before playing the next episode in the same series",
                badgeText = if (autoNext) "ON ✓" else "OFF",
                isHighlighted = autoNext
            ) {
                profileStore.setAutoNextEpisodeEnabled(!autoNext)
                showPlaybackAndBackgroundSettingsDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_speed_bolt,
                title = "VOD & Series Remote Seek Step: ${seekSec} Seconds",
                subtitle = "Tap to cycle D-Pad Left/Right seek interval: 5s → 10s → 15s → 30s → 60s",
                badgeText = "${seekSec}s"
            ) {
                val nextMs = when (seekSec) {
                    5L -> 10_000L
                    10L -> 15_000L
                    15L -> 30_000L
                    30L -> 60_000L
                    else -> 5_000L
                }
                profileStore.setSeekStepMs(nextMs)
                Toast.makeText(this, "Seek step set to ${nextMs / 1000L} seconds", Toast.LENGTH_SHORT).show()
                showPlaybackAndBackgroundSettingsDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_rocket,
                title = "VOD Movie & Episode Playback Speed: ${speed}x",
                subtitle = "Tap to cycle VOD playback speed: 0.75x → 1.0x → 1.25x → 1.5x → 2.0x",
                badgeText = "${speed}x"
            ) {
                val nextSpd = when (speed) {
                    0.75f -> 1.0f
                    1.0f -> 1.25f
                    1.25f -> 1.5f
                    1.5f -> 2.0f
                    else -> 0.75f
                }
                profileStore.setVodPlaybackSpeed(nextSpd)
                if (activePlaybackMode == ActivePlaybackMode.VOD_MOVIE || activePlaybackMode == ActivePlaybackMode.SERIES_EPISODE) {
                    exoPlayer?.setPlaybackSpeed(nextSpd)
                }
                Toast.makeText(this, "VOD Playback Speed: ${nextSpd}x", Toast.LENGTH_SHORT).show()
                showPlaybackAndBackgroundSettingsDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_rocket,
                title = "Auto-Start RAM PLAYER on TV Boot",
                subtitle = "Launch RAM PLAYER automatically when Android TV powers on",
                badgeText = if (autoBootEnabled) "ON ✓" else "OFF",
                isHighlighted = autoBootEnabled
            ) {
                toggleAutoBootSetting()
                showPlaybackAndBackgroundSettingsDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_live_tv,
                title = "Auto-Resume Last Channel on Cold Boot",
                subtitle = "Automatically start your last watched Live TV channel on app launch",
                badgeText = if (autoResumeEnabled) "ON ✓" else "OFF",
                isHighlighted = autoResumeEnabled
            ) {
                toggleAutoResumeSetting()
                showPlaybackAndBackgroundSettingsDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_sleep,
                title = "OSD Auto-Hide Timeout: ${osdSec}s",
                subtitle = "Tap to cycle player info banner auto-hide delay: 2s → 3s → 5s → 8s → 12s",
                badgeText = "${osdSec}s"
            ) {
                val nextOsdMs = when (osdSec) {
                    2L -> 3500L
                    3L -> 5000L
                    5L -> 8000L
                    8L -> 12000L
                    else -> 2000L
                }
                profileStore.setOsdTimeoutMs(nextOsdMs)
                Toast.makeText(this, "OSD Auto-Hide set to ${nextOsdMs / 1000L}s", Toast.LENGTH_SHORT).show()
                showPlaybackAndBackgroundSettingsDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_play,
                title = if (isPlayerLocked) "Player Lock: LOCKED" else "Player Lock (Accidental Button Protection)",
                subtitle = "Toggle playback key lock to prevent accidental channel changes or exits",
                badgeText = if (isPlayerLocked) "LOCKED ✓" else "OFF",
                isHighlighted = isPlayerLocked
            ) {
                togglePlayerLock()
                showPlaybackAndBackgroundSettingsDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_rocket,
                title = "Optional External Player Fallback",
                subtitle = "Allow launching streams in external players (VLC / MX Player) from Quick Menu",
                badgeText = if (extPlayer) "ENABLED ✓" else "OFF",
                isHighlighted = extPlayer
            ) {
                profileStore.setExternalPlayerEnabled(!extPlayer)
                showPlaybackAndBackgroundSettingsDialog()
            }
        )

        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_play,
            title = "Playback & Live TV Background Management",
            subtitle = "Zero background audio leaks • Configurable seek step & VOD speed",
            badgeText = "PLAYBACK",
            options = options,
            closeLabel = "Back"
        )
    }

    private fun showAppearanceDensityAndOverscanDialog() {
        val density = profileStore.getUiDensityMode()
        val overscan = profileStore.getOverscanMarginDp()
        val clock24 = profileStore.is24HourClockEnabled()
        val highContrast = profileStore.isHighContrastTextEnabled()
        val startupDest = profileStore.getStartupDestination()

        val options = ArrayList<GlassModalOption>(12)
        themes.forEachIndexed { idx, t ->
            val isCur = idx == currentThemeIndex
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_theme,
                    title = "Theme: ${t.name}",
                    subtitle = t.subtitle,
                    badgeText = if (isCur) "ACTIVE ✓" else "APPLY",
                    isHighlighted = isCur
                ) {
                    applyTheme(idx)
                    getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
                        .edit()
                        .putInt("theme_index", idx)
                        .apply()
                    showAppearanceDensityAndOverscanDialog()
                }
            )
        }

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_movies,
                title = "UI & Poster Grid Density: ${density.title}",
                subtitle = "Tap to cycle: Compact (6 Cols) → Standard (5 Cols) → Cinematic (4 Cols)",
                badgeText = "${density.tvPosterColumns} COLS"
            ) {
                val allModes = UiDensityMode.values()
                val nextMode = allModes[(density.ordinal + 1) % allModes.size]
                profileStore.setUiDensityMode(nextMode)
                (vodPosterRecycler.layoutManager as? GridLayoutManager)?.spanCount = computeResponsivePosterSpanCount()
                if (vodPosterGridPanel.visibility == View.VISIBLE) renderVodPosterGrid()
                showAppearanceDensityAndOverscanDialog()
            }
        )

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_aspect,
                title = "TV Overscan Safe-Area Margin: ${overscan}dp",
                subtitle = "Adds safe border padding for televisions that crop screen edges (0dp / 8dp / 16dp / 24dp)",
                badgeText = "${overscan}dp"
            ) {
                val nextDp = when (overscan) {
                    0 -> 8
                    8 -> 16
                    16 -> 24
                    else -> 0
                }
                profileStore.setOverscanMarginDp(nextDp)
                applyOverscanMarginFromSettings()
                showAppearanceDensityAndOverscanDialog()
            }
        )

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_sleep,
                title = "Clock Format: ${if (clock24) "24-Hour (19:30)" else "12-Hour AM/PM (07:30 PM)"}",
                subtitle = "Toggle 12-hour vs 24-hour time formatting across headers and EPG",
                badgeText = if (clock24) "24H" else "12H"
            ) {
                profileStore.set24HourClockEnabled(!clock24)
                updateVodHeaderClockText()
                showAppearanceDensityAndOverscanDialog()
            }
        )

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_subtitles,
                title = "High-Contrast TV Text Mode",
                subtitle = "Enhances text brightness and contrast for viewing from a distance",
                badgeText = if (highContrast) "ON ✓" else "OFF",
                isHighlighted = highContrast
            ) {
                profileStore.setHighContrastTextEnabled(!highContrast)
                showAppearanceDensityAndOverscanDialog()
            }
        )

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_home,
                title = "Default Startup Destination: $startupDest",
                subtitle = "Choose whether launching the app opens Live TV directly or the Cinematic Home Hub",
                badgeText = startupDest
            ) {
                val nextDest = if (startupDest == "LIVE_TV") "HOME" else "LIVE_TV"
                profileStore.setStartupDestination(nextDest)
                showAppearanceDensityAndOverscanDialog()
            }
        )

        val curPicMode = profileStore.getPictureMode()
        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_video_4k,
                title = "TV Picture & Brightness Mode: $curPicMode",
                subtitle = "Tap to cycle: STANDARD → CINEMA_DIM → NIGHT_EYECARE → VIVID_MAX",
                badgeText = curPicMode
            ) {
                val nextPic = when (curPicMode) {
                    "STANDARD" -> "CINEMA_DIM"
                    "CINEMA_DIM" -> "NIGHT_EYECARE"
                    "NIGHT_EYECARE" -> "VIVID_MAX"
                    else -> "STANDARD"
                }
                profileStore.setPictureMode(nextPic)
                applyPictureBrightnessMode(nextPic)
                showAppearanceDensityAndOverscanDialog()
            }
        )

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_subtitles,
                title = "Subtitle Font Size & Color Style",
                subtitle = "Customize closed caption size (16sp–32sp) and high-contrast colors",
                badgeText = "CAPTIONS"
            ) {
                showSubtitleStyleDialog()
            }
        )

        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_theme,
            title = "Appearance, Density, Overscan & Comfort",
            subtitle = "Customize themes, poster grid density, safe-area margins & TV readability",
            badgeText = "DISPLAY",
            options = options,
            closeLabel = "Back"
        )
    }

    private fun showRemoteShortcutsSettingsDialog() {
        val curAction = profileStore.getLongPressOkAction()
        val actions = listOf(
            "QUICK_MENU" to "Global Quick Menu",
            "FAVORITE_TOGGLE" to "Toggle ★ Favorite",
            "CHANNEL_INFO" to "Channel Management",
            "EPG_GUIDE" to "EPG TV Guide",
            "AUDIO_QUALITY" to "Audio / Video / Subtitles",
            "SETTINGS" to "Settings Center",
            "PLAYER_LOCK" to "Toggle Player Lock",
            "SLEEP_TIMER" to "Cycle Sleep Timer"
        )
        val options = ArrayList<GlassModalOption>(14)
        for ((code, label) in actions.take(4)) {
            val isCur = curAction == code
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_channels,
                    title = "Long-Press OK / Select: $label",
                    subtitle = "Triggered when holding OK/Enter on the TV remote",
                    badgeText = if (isCur) "ACTIVE ✓" else "SELECT",
                    isHighlighted = isCur
                ) {
                    profileStore.setLongPressOkAction(code)
                    Toast.makeText(this, "Long-Press OK set to: $label", Toast.LENGTH_SHORT).show()
                    showRemoteShortcutsSettingsDialog()
                }
            )
        }
        val colorKeys = listOf("RED", "GREEN", "YELLOW", "BLUE")
        for (ck in colorKeys) {
            val currentCkAction = profileStore.getRemoteColorKeyAction(ck, activeAccountScope)
            val currentLabel = actions.firstOrNull { it.first == currentCkAction }?.second ?: currentCkAction
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_channels,
                    title = "Remote $ck Button: $currentLabel",
                    subtitle = "Tap to cycle action for $ck color key on your TV remote",
                    badgeText = ck
                ) {
                    val idx = actions.indexOfFirst { it.first == currentCkAction }
                    val next = actions[(idx + 1) % actions.size]
                    profileStore.setRemoteColorKeyAction(ck, next.first, activeAccountScope)
                    Toast.makeText(this, "$ck key → ${next.second}", Toast.LENGTH_SHORT).show()
                    showRemoteShortcutsSettingsDialog()
                }
            )
        }
        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_channels,
            title = "TV Remote Shortcuts Configuration",
            subtitle = "Customize Long-Press OK and Red / Green / Yellow / Blue remote keys",
            badgeText = "REMOTE",
            options = options,
            closeLabel = "Back"
        )
    }

    private fun showPlaylistHealthAndDuplicatesDialog() {
        lifecycleScope.launch {
            val hiddenIds = profileStore.getHiddenChannelIds(activeAccountScope)
            val report = withContext(Dispatchers.Default) {
                PlaylistHealthEngine.analyzeCatalogHealth(
                    liveChannels = allChannels,
                    vodMovies = vodMoviesCatalog,
                    seriesGroups = seriesCatalogGroups,
                    hiddenChannelIds = hiddenIds
                )
            }

            val options = ArrayList<GlassModalOption>(report.duplicateGroups.size + 6)
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_lock,
                    title = "Catalog Summary: ${report.totalLiveChannels} Live • ${report.totalVodMovies} Movies • ${report.totalSeries} Series",
                    subtitle = "${report.channelsWithBackupStream} Dual-Stream (.m3u8+.ts) • ${report.channelsWithLogo} with Logos • ${report.channelsWithEpgId} with EPG IDs",
                    badgeText = "HEALTHY ✓",
                    isHighlighted = true
                ) {}
            )

            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_sync,
                    title = "Safe Refresh Active Playlist from Server",
                    subtitle = "Updates playlist without destroying cached fallback if server is unreachable",
                    badgeText = "REFRESH"
                ) {
                    forceRefreshActivePlaylist()
                }
            )

            if (report.duplicateGroups.isEmpty()) {
                options.add(
                    GlassModalOption(
                        iconRes = R.drawable.ic_3d_live_tv,
                        title = "Zero Duplicate Channel Groups Detected",
                        subtitle = "All Live TV channels have unique normalized names or have already been paired with backup streams",
                        badgeText = "0 DUPLICATES"
                    ) {}
                )
            } else {
                for (dup in report.duplicateGroups.take(25)) {
                    options.add(
                        GlassModalOption(
                            iconRes = R.drawable.ic_3d_channels,
                            title = "Duplicate Candidate: ${dup.displayTitle} (${dup.channelIds.size} entries)",
                            subtitle = "Category: ${dup.category} • ${if (dup.hasDistinctUrls) "Distinct alternate stream URLs" else "Same stream URL"} • Tap to review/hide extras",
                            badgeText = "${dup.channelIds.size}x"
                        ) {
                            showDuplicateGroupActionModal(dup)
                        }
                    )
                }
            }

            show4dGlassListModal(
                headerIconRes = R.drawable.ic_3d_playlist,
                title = "Playlist Health & Smart Duplicate Detector",
                subtitle = "${report.duplicateGroups.size} Duplicate Groups • ${report.channelsMissingLogo} Missing Logos • ${report.hiddenChannelsCount} Hidden",
                badgeText = "REPORT",
                options = options,
                closeLabel = "Back"
            )
        }
    }

    private fun showDuplicateGroupActionModal(dup: PlaylistHealthEngine.DuplicateChannelGroup) {
        val options = ArrayList<GlassModalOption>(dup.channelIndices.size + 2)
        for ((pos, chIdx) in dup.channelIndices.withIndex()) {
            val ch = allChannels.getOrNull(chIdx) ?: continue
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_live_tv,
                    title = "Stream #${pos + 1}: Ch ${ch.displayNumberFormatted()} • ${ch.name}",
                    subtitle = "${ch.category} • ${NetworkClient.redactSensitiveUrl(ch.streamUrl)}",
                    badgeText = if (pos == 0) "PRIMARY" else "ALT #${pos + 1}",
                    isHighlighted = pos == 0
                ) {
                    vodPosterGridPanel.visibility = View.GONE
                    activePlaybackMode = ActivePlaybackMode.LIVE_TV
                    switchChannel(chIdx, immediatePlayback = true)
                }
            )
        }
        if (dup.channelIds.size > 1) {
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_trash,
                    title = "Confirm: Hide ${dup.channelIds.size - 1} Secondary Duplicate(s)",
                    subtitle = "Keeps Stream #1 visible and hides the extra duplicate entries (reversible anytime)",
                    badgeText = "HIDE EXTRAS"
                ) {
                    for (extraId in dup.channelIds.drop(1)) {
                        if (!profileStore.getHiddenChannelIds(activeAccountScope).contains(extraId)) {
                            profileStore.toggleChannelHidden(extraId, activeAccountScope)
                        }
                    }
                    renderDrawerList()
                    Toast.makeText(this, "Hidden ${dup.channelIds.size - 1} duplicate(s) for ${dup.displayTitle}", Toast.LENGTH_SHORT).show()
                }
            )
        }
        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_channels,
            title = "Review Duplicates: ${dup.displayTitle}",
            subtitle = "Streams are never deleted without your confirmation",
            badgeText = "${dup.channelIds.size} STREAMS",
            options = options,
            closeLabel = "Back"
        )
    }

    private fun showStorageAndCacheManagerDialog() {
        val snap = StorageBudgetManager.inspectStorage(this)
        val autoCleanup = StorageBudgetManager.isAutoCleanupEnabled(this)
        val freeMb = snap.freeDeviceStorageBytes / StorageBudgetManager.MB

        val options = listOf(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_ram_gauge,
                title = "Total App Storage: ${StorageBudgetManager.formatSize(snap.totalAppStorageBytes)} (${freeMb} MB Free)",
                subtitle = "APK: ${StorageBudgetManager.formatSize(snap.appApkSizeBytes)} • App Data & Settings: ${StorageBudgetManager.formatSize(snap.appDataAndPrefsBytes)} • Active Cache: ${StorageBudgetManager.formatSize(snap.totalManagedCacheBytes)} / 30 MB Cap (<100 MB Total)",
                badgeText = StorageBudgetManager.formatSize(snap.totalManagedCacheBytes),
                isHighlighted = true
            ) {},
            GlassModalOption(
                iconRes = R.drawable.ic_3d_ram_gauge,
                title = "Breakdown: Logos/Posters ${StorageBudgetManager.formatSize(snap.glideImagesCacheBytes)} (Cap 14 MB)",
                subtitle = "Playlist Cache (GZIP): ${StorageBudgetManager.formatSize(snap.playlistCacheBytes)} • EPG Cache (GZIP): ${StorageBudgetManager.formatSize(snap.epgCacheBytes)} • Temp/HTTP: ${StorageBudgetManager.formatSize(snap.tempAndHttpCacheBytes)}",
                badgeText = "LIVE AUDIT"
            ) {},
            GlassModalOption(
                iconRes = R.drawable.ic_3d_rocket,
                title = "Auto Storage Cleanup (30 MB Cache / <100 MB Total): ${if (autoCleanup) "ON ✓" else "OFF"}",
                subtitle = "Automatically prunes old logos, expired EPG & temp files on startup and low storage",
                badgeText = if (autoCleanup) "ON ✓" else "OFF",
                isHighlighted = autoCleanup
            ) {
                val next = !autoCleanup
                StorageBudgetManager.setAutoCleanupEnabled(this, next)
                Toast.makeText(this, "Auto Storage Cleanup: ${if (next) "ON" else "OFF"}", Toast.LENGTH_SHORT).show()
                showStorageAndCacheManagerDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_trash,
                title = "Safe Clear Cache Now (${StorageBudgetManager.formatSize(snap.glideImagesCacheBytes + snap.tempAndHttpCacheBytes)})",
                subtitle = "Clears Glide logos/posters, temp files & RAM buffers (100% preserves accounts, playlists, favorites & settings)",
                badgeText = "CLEAR CACHE"
            ) {
                lifecycleScope.launch(Dispatchers.IO) {
                    val activeLocalPaths = profileStore.all()
                        .map { it.source }
                        .toSet()
                    runCatching { Glide.get(this@PlayerActivity).clearDiskCache() }
                    StorageBudgetManager.enforceStorageBudget(this@PlayerActivity, activeLocalPaths, forceCleanup = true)
                    withContext(Dispatchers.Main) {
                        runCatching { Glide.get(this@PlayerActivity).clearMemory() }
                        ChannelCacheStore.trimMemoryCache()
                        StreamPreFetcher.trimIdleCacheOnLowMemory()
                        Toast.makeText(this@PlayerActivity, "✓ Cache cleared safely (Accounts & playlists preserved)", Toast.LENGTH_SHORT).show()
                        showStorageAndCacheManagerDialog()
                    }
                }
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_trash,
                title = "Purge Compressed Playlist & EPG Caches (${StorageBudgetManager.formatSize(snap.playlistCacheBytes + snap.epgCacheBytes)})",
                subtitle = "Removes cached catalog & EPG files only (Saved Xtream/M3U accounts, favorites & settings remain 100% intact)",
                badgeText = "PURGE DB"
            ) {
                lifecycleScope.launch {
                    channelCache.clearAllCaches()
                    epgCache.clear()
                    Toast.makeText(this@PlayerActivity, "✓ Cleared Playlist & EPG caches (User data preserved)", Toast.LENGTH_SHORT).show()
                    showStorageAndCacheManagerDialog()
                }
            }
        )

        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_ram_gauge,
            title = "Storage & Smart Cache Monitor (v23.3)",
            subtitle = "30 MB hard cache cap (<100 MB total storage) • Zero risk to accounts, playlists or settings",
            badgeText = "${freeMb}MB FREE",
            options = options,
            closeLabel = "Back"
        )
    }

    private fun showRecoveryAndDiagnosticsCenterDialog() {
        val rt = Runtime.getRuntime()
        val usedHeapMb = (rt.totalMemory() - rt.freeMemory()) / (1024L * 1024L)
        val maxHeapMb = (rt.maxMemory() / (1024L * 1024L)).coerceAtLeast(1L)
        val player = exoPlayer
        val vFormat = player?.videoFormat
        val aFormat = player?.audioFormat
        val bufferedMs = if (player != null) (player.bufferedPosition - player.currentPosition).coerceAtLeast(0L) else 0L

        val measuredTrackInfo = buildString {
            if (vFormat != null) {
                append("${vFormat.width}x${vFormat.height}")
                if (vFormat.frameRate > 0f) append(" @ ${vFormat.frameRate.toInt()}fps")
                if (!vFormat.sampleMimeType.isNullOrBlank()) append(" • ${vFormat.sampleMimeType}")
                if (vFormat.bitrate > 0) append(" • ${vFormat.bitrate / 1000} kbps")
            } else {
                append("Video: Idle / Not Playing")
            }
            if (aFormat != null) {
                append(" | Audio: ${aFormat.sampleMimeType ?: "PCM"}")
                if (!aFormat.language.isNullOrBlank()) append(" (${aFormat.language})")
            }
            append(" | Buffer: ${bufferedMs}ms")
        }

        val netConnected = isNetworkConnectedNow()
        val netSummary = if (netConnected) "Connected • DNS Cache Active • HTTP/2 + Keep-Alive" else "Offline (Cached Catalog Mode Active)"

        val options = listOf(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_video_4k,
                title = "Measured Media3 Playback Diagnostics",
                subtitle = measuredTrackInfo,
                badgeText = if (player?.isPlaying == true) "PLAYING" else "IDLE",
                isHighlighted = true
            ) {
                showPerformanceMonitorDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_network,
                title = "Network Health Status: ${if (netConnected) "ONLINE ✓" else "OFFLINE ⚠️"}",
                subtitle = "$netSummary • Last Error: ${NetworkClient.redactSensitiveUrl(recentPlaybackErrorSummary)}",
                badgeText = if (netConnected) "ONLINE" else "OFFLINE"
            ) {},
            GlassModalOption(
                iconRes = R.drawable.ic_3d_sync,
                title = "Recovery Action 1: Soft-Reconnect Active Stream",
                subtitle = "Resets network sockets and reconnects current stream without losing navigation state",
                badgeText = "RECONNECT"
            ) {
                NetworkClient.evictIdleConnections()
                if (activePlaybackMode == ActivePlaybackMode.LIVE_TV && allChannels.isNotEmpty()) {
                    startPlaybackForCurrentChannel(forceReload = true)
                } else {
                    exoPlayer?.prepare()
                    exoPlayer?.playWhenReady = true
                }
                Toast.makeText(this, "🔄 Stream connection refreshed", Toast.LENGTH_SHORT).show()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_rocket,
                title = "Recovery Action 2: Re-Initialize Media3 Decoder Pipeline",
                subtitle = "Safely recreates ExoPlayer instance if hardware decoder stalled on TV",
                badgeText = "RESET PLAYER"
            ) {
                initializeMedia3ProEngine(recreateIfPresent = true)
                Toast.makeText(this, "✓ Media3 player pipeline re-initialized", Toast.LENGTH_SHORT).show()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_speed_bolt,
                title = "Measure Real Server Connection Latency (HTTP TTFB)",
                subtitle = "Tests actual TCP/TLS/HTTP response time to your active IPTV server",
                badgeText = "PING TEST"
            ) {
                runRealServerLatencyTest()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_lock,
                title = "Export Redacted Diagnostic Report",
                subtitle = "View or copy complete diagnostic report with all passwords/tokens automatically redacted",
                badgeText = "EXPORT"
            ) {
                val reportText = DiagnosticsEngine.buildRedactedDiagnosticExport(
                    appVersion = "18.1-Ultra",
                    performanceMode = activePerformanceMode,
                    uiDensityMode = profileStore.getUiDensityMode(),
                    usedHeapMb = usedHeapMb,
                    maxHeapMb = maxHeapMb,
                    liveCount = allChannels.size,
                    vodCount = vodMoviesCatalog.size,
                    seriesCount = seriesCatalogGroups.size,
                    activeStreamUrl = currentPlayingStreamUrl,
                    videoDiagSummary = measuredTrackInfo,
                    networkStatusSummary = netSummary,
                    lastErrorSummary = recentPlaybackErrorSummary,
                    sxb2CacheKb = channelCache.totalCacheSizeBytes() / 1024L,
                    epgCacheKb = epgCache.cacheSizeBytes() / 1024L
                )
                show4dGlassFormModal(
                    headerIconRes = R.drawable.ic_3d_lock,
                    title = "Redacted Diagnostic Report",
                    subtitle = "All credentials and stream tokens are masked with ****",
                    badgeText = "SAFE EXPORT",
                    fields = listOf(
                        GlassFormFieldSpec(
                            label = "DIAGNOSTIC REPORT (CREDENTIALS REDACTED)",
                            hint = "",
                            iconRes = R.drawable.ic_3d_rocket,
                            initialValue = reportText
                        )
                    ),
                    positiveLabel = "Done",
                    positiveBgRes = R.drawable.bg_btn_3d_cyan
                ) {}
            }
        )

        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_lock,
            title = "Diagnostics, Network Health & Recovery Center",
            subtitle = "Real measured telemetry • Zero fabricated stats • One-click stream recovery",
            badgeText = "${usedHeapMb}/${maxHeapMb}MB",
            options = options,
            closeLabel = "Back"
        )
    }

    private fun showBackupAndRestoreDialog() {
        val options = listOf(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_lock,
                title = "Export Safe Backup (Credentials Redacted)",
                subtitle = "Exports Favorites, Movie/Series Watchlists, Custom Groups, Watched History & Settings (Excludes passwords)",
                badgeText = "SAFE BACKUP",
                isHighlighted = true
            ) {
                val json = BackupRestoreEngine.exportVersionedBackupJson(
                    profileStore = profileStore,
                    liveFavoriteIds = favoriteIds,
                    accountScope = activeAccountScope,
                    includeCredentials = false
                )
                showBackupJsonPayloadDialog(json, includesCredentials = false)
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_accounts,
                title = "Export Complete Backup (Includes Account Credentials)",
                subtitle = "Exports all profiles (including M3U/Xtream URLs & passwords), Favorites, Watchlists & Settings",
                badgeText = "FULL BACKUP"
            ) {
                val json = BackupRestoreEngine.exportVersionedBackupJson(
                    profileStore = profileStore,
                    liveFavoriteIds = favoriteIds,
                    accountScope = activeAccountScope,
                    includeCredentials = true
                )
                showBackupJsonPayloadDialog(json, includesCredentials = true)
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_lock,
                title = "🔐 Export Password-Protected Backup (AES-256-GCM)",
                subtitle = "Encrypts full profile, favorites, blacklist, home/sidebar & settings with your password",
                badgeText = "AES-256"
            ) {
                showPasswordProtectedBackupExportDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_sync,
                title = "Restore from SXBK_V19 Backup JSON",
                subtitle = "Validates versioned backup format before restoring Favorites, Watchlists, Groups & Settings",
                badgeText = "RESTORE"
            ) {
                val savedLocalBackup = getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
                    .getString("last_sxbk_v19_backup", "") ?: ""
                show4dGlassFormModal(
                    headerIconRes = R.drawable.ic_3d_sync,
                    title = "Restore Validated SXBK_V19 Backup",
                    subtitle = "Paste backup JSON or restore your last saved local snapshot",
                    badgeText = "SXBK_V19",
                    fields = listOf(
                        GlassFormFieldSpec(
                            label = "SXBK_V19 BACKUP JSON PAYLOAD",
                            hint = "Paste SXBK_V19 Backup JSON",
                            iconRes = R.drawable.ic_3d_sync,
                            initialValue = savedLocalBackup
                        )
                    ),
                    positiveLabel = "Validate & Restore",
                    positiveBgRes = R.drawable.bg_btn_3d_emerald
                ) { vals ->
                    val raw = vals.firstOrNull().orEmpty()
                    val check = BackupRestoreEngine.validateBackupJson(raw)
                    if (!check.isValid) {
                        Toast.makeText(this, "❌ Backup rejected: ${check.message}", Toast.LENGTH_LONG).show()
                    } else {
                        AlertDialog.Builder(this, R.style.Theme_StreamX_GlassDialog)
                            .setTitle("Confirm Backup Restore")
                            .setMessage("Validated: ${check.message}\n\nRestore this backup into active profile? Existing data is preserved if restore fails.")
                            .setPositiveButton("Restore Now") { _, _ ->
                                val ok = BackupRestoreEngine.restoreValidatedBackupTransactional(
                                    rawJson = raw,
                                    profileStore = profileStore,
                                    accountScope = activeAccountScope,
                                    outLiveFavorites = favoriteIds
                                )
                                if (ok) {
                                    getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
                                        .edit()
                                        .putStringSet("fav_ids", HashSet(favoriteIds))
                                        .apply()
                                    applyOverscanMarginFromSettings()
                                    applySidebarCustomization()
                                    renderDrawerList()
                                    Toast.makeText(this, "✓ Restored: ${check.message}", Toast.LENGTH_LONG).show()
                                } else {
                                    Toast.makeText(this, "Restore failed safely; existing data preserved", Toast.LENGTH_LONG).show()
                                }
                            }
                            .setNegativeButton("Cancel", null)
                            .show()
                    }
                }
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_trash,
                title = "Restore Default App Settings (Keep Profiles & Favorites)",
                subtitle = "Resets playback, density, overscan & remote settings to recommended defaults without deleting accounts",
                badgeText = "DEFAULTS"
            ) {
                profileStore.restoreDefaultSettingsPreservingProfilesAndCatalogs()
                applyOverscanMarginFromSettings()
                Toast.makeText(this, "✓ Restored recommended default settings (Profiles & Favorites preserved)", Toast.LENGTH_SHORT).show()
            }
        )

        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_sync,
            title = "Versioned Backup & Restore (SXBK_V19)",
            subtitle = "Validated backup format with explicit credential control & safe restore",
            badgeText = "SXBK_V19",
            options = options,
            closeLabel = "Back"
        )
    }

    private fun showBackupJsonPayloadDialog(jsonPayload: String, includesCredentials: Boolean) {
        getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
            .edit()
            .putString("last_sxbk_v19_backup", jsonPayload)
            .apply()
        show4dGlassFormModal(
            headerIconRes = R.drawable.ic_3d_lock,
            title = if (includesCredentials) "Full Backup Saved (Credentials Included)" else "Safe Backup Saved (Credentials Redacted)",
            subtitle = "Also saved to local recovery slot for instant 1-click restore",
            badgeText = "SXBK_V19",
            fields = listOf(
                GlassFormFieldSpec(
                    label = "BACKUP PAYLOAD (SXBK_V19)",
                    hint = "",
                    iconRes = R.drawable.ic_3d_lock,
                    initialValue = jsonPayload
                )
            ),
            positiveLabel = "Done",
            positiveBgRes = R.drawable.bg_btn_3d_cyan
        ) {}
    }

    private fun showAboutAndUpdateCenterDialog() {
        val idleMins = profileStore.getIdleScreensaverMinutes()
        val options = listOf(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_rocket,
                title = "RAM PLAYER v21.0 — AMOLED 3D Edition (Build 210)",
                subtitle = "Package: com.harindra.iptvpro • Media3 1.11.1 • Strict ContentSourceType Separation • 512MB Low-RAM Guard",
                badgeText = "v20.0 ✓",
                isHighlighted = true
            ) {},
            GlassModalOption(
                iconRes = R.drawable.ic_3d_settings,
                title = getString(R.string.legal_disclaimer_title),
                subtitle = getString(R.string.legal_disclaimer),
                badgeText = "LEGAL"
            ) {
                AlertDialog.Builder(this, R.style.Theme_StreamX_GlassDialog)
                    .setTitle(getString(R.string.legal_disclaimer_title))
                    .setMessage(getString(R.string.legal_disclaimer))
                    .setPositiveButton("OK", null)
                    .show()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_home,
                title = "Run First-Time TV Setup Wizard",
                subtitle = "Configure TV Performance Mode, UI Density, Overscan Safe-Area & Live TV Background behavior in 1 minute",
                badgeText = "WIZARD"
            ) {
                showFirstTimeSetupWizardDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_sleep,
                title = "Ambient Idle Screensaver: ${if (idleMins == 0) "OFF" else "After $idleMins Minutes"}",
                subtitle = "Tap to cycle idle timeout: 10m → 15m → 30m → Off → 5m (Displays clock & active profile when idle)",
                badgeText = if (idleMins == 0) "OFF" else "${idleMins}m"
            ) {
                val nextMins = when (idleMins) {
                    5 -> 10
                    10 -> 15
                    15 -> 30
                    30 -> 0
                    else -> 5
                }
                profileStore.setIdleScreensaverMinutes(nextMins)
                showAboutAndUpdateCenterDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_play,
                title = "Preview Ambient TV Screensaver Now",
                subtitle = "Test the low-memory ambient clock screensaver (press any remote key to dismiss)",
                badgeText = "PREVIEW"
            ) {
                showAmbientScreensaverModal()
            }
        )

        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_rocket,
            title = "About, Setup Wizard, Screensaver & Update Center",
            subtitle = "What's New: Live TV Background Stop, Cinematic Home Hub, 15-Category Settings, Duplicate Detector & SXBK_V19 Backup",
            badgeText = "v20.0 AMOLED",
            options = options,
            closeLabel = "Back"
        )
    }

    private fun showFirstTimeSetupWizardDialog() {
        val options = listOf(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_ram_gauge,
                title = "Step 1: Apply Recommended 512MB Smart TV Profile",
                subtitle = "Enables Smart Balanced prefetching, RGB_565 poster bounds & Background Live TV Stop",
                badgeText = "RECOMMENDED",
                isHighlighted = true
            ) {
                activePerformanceMode = PerformanceMode.SMART_BALANCED
                profileStore.setPerformanceMode(PerformanceMode.SMART_BALANCED)
                profileStore.setStopLiveTvInBackgroundEnabled(true)
                profileStore.setSetupWizardCompleted(true)
                Toast.makeText(this, "✓ Applied recommended 512MB Smart TV configuration!", Toast.LENGTH_SHORT).show()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_aspect,
                title = "Step 2: Adjust TV Overscan & UI Density",
                subtitle = "Configure screen edge padding and poster grid columns (4, 5, or 6 columns)",
                badgeText = "DISPLAY"
            ) {
                showAppearanceDensityAndOverscanDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_accounts,
                title = "Step 3: Connect Your M3U Playlist or Xtream Codes Account",
                subtitle = "M3U loads Live TV • Xtream loads independent Live TV, VOD Movies & Series catalogs",
                badgeText = "ACCOUNTS"
            ) {
                showAddProfileDialog()
            }
        )
        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_rocket,
            title = "RAM PLAYER Android TV Quick Setup Wizard",
            subtitle = "Detected Device RAM: ${totalDeviceRamMb} MB • Optimized for Android TV Remote Navigation",
            badgeText = "SETUP",
            options = options,
            closeLabel = "Finish"
        )
    }

    private fun showAmbientScreensaverModal() {
        if (isScreensaverShowing) return
        isScreensaverShowing = true
        val clockStr = SimpleDateFormat(
            if (profileStore.is24HourClockEnabled()) "HH:mm" else "hh:mm a",
            Locale.US
        ).format(Date())
        val dateStr = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.US).format(Date())
        val ch = allChannels.getOrNull(currentChannelIndex)

        val options = listOf(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_sleep,
                title = "🕒 $clockStr  •  $dateStr",
                subtitle = "RAM PLAYER Ambient Mode • Last Channel: ${ch?.name ?: "Live TV"} • Press OK or Back to wake",
                badgeText = "AMBIENT",
                isHighlighted = true
            ) {
                isScreensaverShowing = false
                lastUserInteractionElapsedMs = SystemClock.elapsedRealtime()
            }
        )
        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_sleep,
            title = "RAM PLAYER Ambient Screensaver",
            subtitle = "Low-power OLED/LED screen protection active",
            badgeText = clockStr,
            options = options,
            closeLabel = "Wake Screen"
        )
        isScreensaverShowing = false
        lastUserInteractionElapsedMs = SystemClock.elapsedRealtime()
    }

    private fun applyAudioLoudnessBoost(millibels: Int) {
        val player = exoPlayer ?: return
        runCatching {
            val sessionId = player.audioSessionId
            if (sessionId != C.AUDIO_SESSION_ID_UNSET && sessionId != 0) {
                if (loudnessEnhancer == null) {
                    loudnessEnhancer = LoudnessEnhancer(sessionId)
                }
                loudnessEnhancer?.setTargetGain(millibels.coerceIn(0, 900))
                loudnessEnhancer?.enabled = millibels > 0
            }
        }
    }

    private fun applyPictureBrightnessMode(mode: String) {
        runCatching {
            val lp = window.attributes
            lp.screenBrightness = when (mode) {
                "CINEMA_DIM" -> 0.55f
                "NIGHT_EYECARE" -> 0.35f
                "VIVID_MAX" -> 1.0f
                else -> WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
            }
            window.attributes = lp
        }
    }

    private fun showVodSmartFilterDialog() {
        val filters = listOf(
            "ALL" to "All Available Titles (No Filter)",
            "4K" to "4K UHD Titles Only",
            "1080P" to "1080p Full HD & 4K Titles",
            "UNWATCHED" to "Unwatched Titles Only"
        )
        val options = filters.map { (code, label) ->
            val isCur = vodSmartQualityFilter == code
            GlassModalOption(
                iconRes = R.drawable.ic_3d_video_4k,
                title = label,
                subtitle = "Filter current Movies/Series poster grid without changing provider categories",
                badgeText = if (isCur) "ACTIVE ✓" else "FILTER",
                isHighlighted = isCur
            ) {
                vodSmartQualityFilter = code
                renderVodPosterGrid()
            }
        }
        presentObsidianSheetDialog(
            title = "Smart VOD Quality & Unwatched Filter",
            subtitle = "Long-press Sort button anytime to filter by 4K, 1080p or Unwatched",
            badgeText = vodSmartQualityFilter,
            options = options,
            closeLabel = "Back"
        )
    }

    private fun runRealServerLatencyTest() {
        val targetUrl = activeXtreamCreds?.serverUrl?.takeIf { it.isNotBlank() }
            ?: activeM3uInput.takeIf { it.startsWith("http", ignoreCase = true) }
            ?: allChannels.firstOrNull()?.streamUrl
            ?: "https://www.google.com"
        Toast.makeText(this, "📡 Measuring real HTTP latency...", Toast.LENGTH_SHORT).show()
        lifecycleScope.launch(Dispatchers.IO) {
            val t0 = SystemClock.elapsedRealtime()
            val statusMsg = runCatching {
                val req = Request.Builder().url(targetUrl).head().build()
                NetworkClient.fastMetaClient.newCall(req).execute().use { res ->
                    val rtt = SystemClock.elapsedRealtime() - t0
                    "HTTP ${res.code} • Real Server Response: ${rtt} ms"
                }
            }.getOrElse { e ->
                "Connection Failed (${SystemClock.elapsedRealtime() - t0} ms): ${e.message}"
            }
            withContext(Dispatchers.Main) {
                Toast.makeText(this@PlayerActivity, statusMsg, Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val keyCode = event.keyCode
        val isOverlayOpen = leftChannelDrawer.visibility == View.VISIBLE || vodPosterGridPanel.visibility == View.VISIBLE
        if (okHoldDeleteController.isOkKeyCode(keyCode) &&
            !isOverlayOpen &&
            activeGlassDialogCount == 0 &&
            !okHoldDeleteDialogShowing &&
            !isPlayerLocked &&
            activePlaybackMode == ActivePlaybackMode.LIVE_TV &&
            currentFocus !is EditText &&
            currentFocus !is Button &&
            numberInputBuffer.isEmpty()
        ) {
            val activeCh = allChannels.getOrNull(currentChannelIndex)
            if (activeCh != null) {
                if (event.action == KeyEvent.ACTION_DOWN) {
                    val rep = event.repeatCount
                    val started = okHoldDeleteController.onKeyDown(
                        keyCode = keyCode,
                        repeatCount = rep,
                        nowElapsedMs = SystemClock.elapsedRealtime(),
                        isEligibleLiveTv = true,
                        channelId = activeCh.id,
                        channelName = activeCh.name,
                        channelNumber = activeCh.number
                    )
                    if (started && rep == 0) {
                        uiHandler.removeCallbacks(okHoldPollRunnable)
                        uiHandler.postDelayed(okHoldPollRunnable, 80L)
                    }
                    return true
                } else if (event.action == KeyEvent.ACTION_UP && okHoldDeleteController.isHolding()) {
                    return onKeyUp(keyCode, event)
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        lastUserInteractionElapsedMs = SystemClock.elapsedRealtime()
        val isKeyRepeat = (event?.repeatCount ?: 0) > 0
        val isOverlayOpen = leftChannelDrawer.visibility == View.VISIBLE || vodPosterGridPanel.visibility == View.VISIBLE
        if (isPlayerLocked && !isOverlayOpen) {
            when (keyCode) {
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_SETTINGS -> {
                    isPlayerLocked = false
                    Toast.makeText(this, "🔓 Player Unlocked", Toast.LENGTH_SHORT).show()
                    showGlobalQuickMenuDialog()
                    return true
                }
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT,
                KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_PAGE_UP, KeyEvent.KEYCODE_PAGE_DOWN,
                KeyEvent.KEYCODE_BACK -> {
                    Toast.makeText(this, "🔒 Player Locked — Press OK or Menu to unlock", Toast.LENGTH_SHORT).show()
                    return true
                }
            }
        }
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_PAGE_UP -> {
                if (!isOverlayOpen && activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
                    lastRemoteKeyPressElapsedMs = SystemClock.elapsedRealtime()
                    lastZapForward = true
                    switchChannel(currentChannelIndex + 1, immediatePlayback = !isKeyRepeat)
                    return true
                }
            }
            KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_PAGE_DOWN -> {
                if (!isOverlayOpen && activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
                    lastRemoteKeyPressElapsedMs = SystemClock.elapsedRealtime()
                    lastZapForward = false
                    switchChannel(currentChannelIndex - 1, immediatePlayback = !isKeyRepeat)
                    return true
                }
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                if (!isOverlayOpen) {
                    if (activePlaybackMode == ActivePlaybackMode.VOD_MOVIE || activePlaybackMode == ActivePlaybackMode.SERIES_EPISODE) {
                        val stepMs = if (::profileStore.isInitialized) profileStore.getSeekStepMs() else 15_000L
                        exoPlayer?.let { p ->
                            val newPos = (p.currentPosition - stepMs).coerceAtLeast(0L)
                            p.seekTo(newPos)
                            showZappingOsd()
                        }
                        return true
                    }
                    openDrawerAndRequestFocus()
                    return true
                }
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (leftChannelDrawer.visibility == View.VISIBLE && channelListRecycler.hasFocus()) {
                    closeDrawerAndRestoreFocus()
                    return true
                }
                if (!isOverlayOpen) {
                    if (activePlaybackMode == ActivePlaybackMode.VOD_MOVIE || activePlaybackMode == ActivePlaybackMode.SERIES_EPISODE) {
                        val stepMs = if (::profileStore.isInitialized) profileStore.getSeekStepMs() else 15_000L
                        exoPlayer?.let { p ->
                            val dur = p.duration.takeIf { it > 0L && it != C.TIME_UNSET } ?: Long.MAX_VALUE
                            val newPos = (p.currentPosition + stepMs).coerceAtMost(dur)
                            p.seekTo(newPos)
                            showZappingOsd()
                        }
                        return true
                    }
                    recallPreviousChannel()
                    return true
                }
            }
            KeyEvent.KEYCODE_LAST_CHANNEL, KeyEvent.KEYCODE_MEDIA_PREVIOUS, KeyEvent.KEYCODE_DEL -> {
                if (!isOverlayOpen) {
                    recallPreviousChannel()
                    return true
                }
            }
            KeyEvent.KEYCODE_SEARCH -> {
                showUnifiedSearchDialog()
                return true
            }
            KeyEvent.KEYCODE_PROG_RED -> {
                executeConfigurableRemoteAction(profileStore.getRemoteColorKeyAction("RED", activeAccountScope))
                return true
            }
            KeyEvent.KEYCODE_PROG_GREEN -> {
                executeConfigurableRemoteAction(profileStore.getRemoteColorKeyAction("GREEN", activeAccountScope))
                return true
            }
            KeyEvent.KEYCODE_PROG_YELLOW -> {
                executeConfigurableRemoteAction(profileStore.getRemoteColorKeyAction("YELLOW", activeAccountScope))
                return true
            }
            KeyEvent.KEYCODE_PROG_BLUE -> {
                executeConfigurableRemoteAction(profileStore.getRemoteColorKeyAction("BLUE", activeAccountScope))
                return true
            }
            KeyEvent.KEYCODE_INFO, KeyEvent.KEYCODE_GUIDE -> {
                showEpgGuideHubDialog()
                return true
            }
            KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_MEDIA_AUDIO_TRACK, KeyEvent.KEYCODE_CAPTIONS -> {
                showAudioAndQualityDialog()
                return true
            }
            KeyEvent.KEYCODE_SETTINGS -> {
                showCategorizedSettingsCenterDialog()
                return true
            }
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                exoPlayer?.let { player ->
                    if (player.isPlaying) {
                        recordCurrentVodOrSeriesProgress()
                        player.pause()
                        liveStatusLabel = "⏸ Paused"
                    } else {
                        if (activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
                            player.seekToDefaultPosition()
                        }
                        player.playWhenReady = true
                        liveStatusLabel = "🟢 Playing"
                    }
                    if (activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
                        updateOsdForCurrentChannel()
                    }
                    showZappingOsd()
                }
                return true
            }
            KeyEvent.KEYCODE_BACK -> {
                // 1. If playing a VOD Movie or Trailer in full-screen -> return to Movie Details & Movies Grid!
                if (vodPosterGridPanel.visibility != View.VISIBLE &&
                    (activePlaybackMode == ActivePlaybackMode.VOD_MOVIE || activePlaybackMode == ActivePlaybackMode.VOD_TRAILER)
                ) {
                    recordCurrentVodOrSeriesProgress()
                    exoPlayer?.pause()
                    updateSectionButtonsUi(EntertainmentSection.MOVIES)
                    openVodPosterHub(EntertainmentSection.MOVIES, restoreFocusIndex = lastFocusedPosterIndex)
                    val mIdx = activeVodMovieIndex
                    val detail = activeVodMovieDetailInfo
                    if (mIdx in vodMoviesCatalog.indices) {
                        showMovieDetailModal(mIdx, detail)
                    }
                    return true
                }
                // 2. If playing a Series Episode in full-screen -> return to the exact Series & Season Episode List!
                if (vodPosterGridPanel.visibility != View.VISIBLE &&
                    activePlaybackMode == ActivePlaybackMode.SERIES_EPISODE
                ) {
                    recordCurrentVodOrSeriesProgress()
                    autoNextCountdownJob?.cancel()
                    autoNextCountdownDialog?.dismiss()
                    exoPlayer?.pause()
                    updateSectionButtonsUi(EntertainmentSection.SERIES)
                    openVodPosterHub(EntertainmentSection.SERIES, restoreFocusIndex = lastFocusedPosterIndex)
                    val grp = activeSeriesGroup
                    if (grp != null) {
                        presentSeriesDetailOverlayDialog(grp, activeSeriesSeasonNum)
                    }
                    return true
                }
                // 3. If VOD Poster Grid is open -> return to Live TV
                if (vodPosterGridPanel.visibility == View.VISIBLE) {
                    closeVodGridAndReturnToLiveTv()
                    return true
                }
                // 4. If Live TV Channel Drawer is open -> close drawer
                if (leftChannelDrawer.visibility == View.VISIBLE) {
                    closeDrawerAndRestoreFocus()
                    return true
                }
                // 5. If OSD or Top Bar is visible -> hide them
                if (osdBanner.visibility == View.VISIBLE || topControlBar.visibility == View.VISIBLE) {
                    uiHandler.removeCallbacks(hideOsdRunnable)
                    osdBanner.visibility = View.GONE
                    topControlBar.visibility = View.GONE
                    return true
                }
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                if (numberInputBuffer.isNotEmpty()) {
                    uiHandler.removeCallbacks(numberJumpRunnable)
                    numberJumpRunnable.run()
                    return true
                }
                if (!isOverlayOpen) {
                    val focusedIsInput = currentFocus is EditText
                    val activeCh = allChannels.getOrNull(currentChannelIndex)
                    val eligibleFor5sDelete = activePlaybackMode == ActivePlaybackMode.LIVE_TV &&
                        !isPlayerLocked &&
                        !okHoldDeleteDialogShowing &&
                        !focusedIsInput &&
                        activeCh != null
                    if (eligibleFor5sDelete && activeCh != null) {
                        val rep = event?.repeatCount ?: 0
                        val started = okHoldDeleteController.onKeyDown(
                            keyCode = keyCode,
                            repeatCount = rep,
                            nowElapsedMs = SystemClock.elapsedRealtime(),
                            isEligibleLiveTv = true,
                            channelId = activeCh.id,
                            channelName = activeCh.name,
                            channelNumber = activeCh.number
                        )
                        if (started && rep == 0) {
                            uiHandler.removeCallbacks(okHoldPollRunnable)
                            uiHandler.postDelayed(okHoldPollRunnable, 80L)
                        }
                        return true
                    }
                    if (event?.isLongPress == true || (event?.repeatCount ?: 0) == 1) {
                        handleConfigurableLongPressOk()
                        return true
                    }
                    showZappingOsd()
                    return true
                }
            }
            in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> {
                if ((leftChannelDrawer.visibility == View.VISIBLE && channelSearch.hasFocus()) ||
                    (vodPosterGridPanel.visibility == View.VISIBLE && vodPosterSearch.hasFocus())
                ) {
                    return super.onKeyDown(keyCode, event)
                }
                if (activePlaybackMode != ActivePlaybackMode.LIVE_TV) {
                    return super.onKeyDown(keyCode, event)
                }
                val digit = keyCode - KeyEvent.KEYCODE_0
                if (numberInputBuffer.length < 5) {
                    numberInputBuffer += digit.toString()
                }
                tvChannelNumber.text = numberInputBuffer.padStart(3, '-')
                osdBanner.alpha = 1f
                osdBanner.visibility = View.VISIBLE
                uiHandler.removeCallbacks(numberJumpRunnable)
                uiHandler.postDelayed(numberJumpRunnable, 750L)
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun registerNetworkCallbackSafe() {
        if (networkCallbackRegistered) return
        val cm = connectivityManager ?: return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                cm.registerDefaultNetworkCallback(networkCallback)
            } else {
                val req = NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .build()
                cm.registerNetworkCallback(req, networkCallback)
            }
            networkCallbackRegistered = true
        } catch (e: Exception) {
            Log.w("StreamX", "NetworkCallback registration warning: ${e.message}")
        }
    }

    private fun unregisterNetworkCallbackSafe() {
        if (!networkCallbackRegistered) return
        try {
            connectivityManager?.unregisterNetworkCallback(networkCallback)
        } catch (e: Exception) {
            Log.w("StreamX", "NetworkCallback unregister warning: ${e.message}")
        } finally {
            networkCallbackRegistered = false
        }
    }

    override fun onStart() {
        super.onStart()
        registerNetworkCallbackSafe()
        exoPlayer?.let { player ->
            if (player.mediaItemCount > 0) {
                if (player.playbackState == Player.STATE_IDLE) {
                    if (activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
                        player.seekToDefaultPosition()
                    }
                    player.prepare()
                }
                player.playWhenReady = true
            }
        }
    }

    override fun onStop() {
        super.onStop()
        val inPip = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) isInPictureInPictureMode else false
        if (!inPip) {
            unregisterNetworkCallbackSafe()
            StreamPreFetcher.cancelAllPrefetches()
            uiHandler.removeCallbacks(stallWatchdogRunnable)
            uiHandler.removeCallbacks(blackScreenWatchdogRunnable)
            uiHandler.removeCallbacks(persistStateRunnable)
            persistStateRunnable.run()
            exoPlayer?.pause()
            liveTvVlcEngine?.pause()
            // Keep total storage strictly under 100 MB across multi-day TV usage
            lifecycleScope.launch(Dispatchers.IO) {
                runCatching {
                    val activeLocal = if (::profileStore.isInitialized) {
                        profileStore.all().map { it.source }.toSet()
                    } else emptySet()
                    StorageBudgetManager.enforceStorageBudget(this@PlayerActivity, activeLocal)
                }
            }
        }
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        runCatching {
            Glide.get(this).trimMemory(level)
            if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW ||
                level >= ComponentCallbacks2.TRIM_MEMORY_BACKGROUND
            ) {
                Glide.get(this).clearMemory()
                StreamPreFetcher.trimIdleCacheOnLowMemory()
                ChannelCacheStore.trimMemoryCache()
                sharedAllocator?.trim()
            }
        }
    }

    override fun onLowMemory() {
        super.onLowMemory()
        runCatching {
            Glide.get(this).clearMemory()
            StreamPreFetcher.trimIdleCacheOnLowMemory()
            ChannelCacheStore.trimMemoryCache()
            sharedAllocator?.trim()
        }
    }

    override fun onDestroy() {
        recordCurrentVodOrSeriesProgress()
        cancelBootAnimators()
        unregisterNetworkCallbackSafe()
        StreamPreFetcher.cancelAllPrefetches()
        xtreamRepo.cancelActiveFetch()
        filterJob?.cancel()
        vodPosterFilterJob?.cancel()
        vodCatalogLoadJob?.cancel()
        seriesCatalogLoadJob?.cancel()
        autoNextCountdownJob?.cancel()
        loadChannelsJob?.cancel()
        epgLoadJob?.cancel()
        bgSyncJob?.cancel()
        uiHandler.removeCallbacksAndMessages(null)
        playerView.player = null
        exoPlayer?.release()
        exoPlayer = null
        liveTvVlcEngine?.release()
        liveTvVlcEngine = null
        super.onDestroy()
    }

    /**
     * v18.1 Left VOD Category Sidebar Adapter (Matches Reference Screenshots 25369.jpg / 25373.jpg / 25375.jpg:
     * FAVORITES / WATCHLIST, RECENTLY ADDED, CONTINUE WATCHING, BOLLYWOOD (2025-2026) (297), PAK: HUM TV (224), etc.)
     */
    private class VodCategorySidebarAdapter(
        private val reducedAnimations: () -> Boolean,
        private val onCategorySelected: (VodCategorySidebarItem) -> Unit
    ) : RecyclerView.Adapter<VodCategorySidebarAdapter.SidebarViewHolder>() {

        private var items: List<VodCategorySidebarItem> = emptyList()
        private var selectedCatName: String = "RECENTLY ADDED"

        fun submitCategories(newItems: List<VodCategorySidebarItem>, activeCategory: String) {
            items = newItems
            selectedCatName = activeCategory
            notifyDataSetChanged()
        }

        fun setSelectedCategory(categoryName: String) {
            if (selectedCatName == categoryName) return
            selectedCatName = categoryName
            notifyDataSetChanged()
        }

        override fun getItemCount(): Int = items.size

        private fun dp(ctx: Context, v: Int): Int =
            TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), ctx.resources.displayMetrics).toInt()

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SidebarViewHolder {
            val ctx = parent.context
            val row = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                isFocusable = true
                isClickable = true
                setBackgroundResource(R.drawable.bg_obsidian_rail_item)
                setPadding(dp(ctx, 11), dp(ctx, 9), dp(ctx, 9), dp(ctx, 9))
                layoutParams = RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(ctx, 3) }
            }

            val tvName = TextView(ctx).apply {
                textSize = 11f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#D1D5DB"))
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            row.addView(tvName)

            val tvCount = TextView(ctx).apply {
                textSize = 10f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#6B7280"))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { marginStart = dp(ctx, 6) }
            }
            row.addView(tvCount)

            return SidebarViewHolder(row, tvName, tvCount, reducedAnimations, onCategorySelected)
        }

        override fun onBindViewHolder(holder: SidebarViewHolder, position: Int) {
            val item = items[position]
            holder.boundItem = item
            val isSelected = item.categoryName.equals(selectedCatName, ignoreCase = true)
            holder.isItemSelected = isSelected
            holder.root.isSelected = isSelected
            holder.tvName.text = item.categoryName
            holder.tvCount.text = if (item.count > 0) "${item.count}" else ""
            holder.applyTextColors(holder.root.hasFocus())
        }

        class SidebarViewHolder(
            val root: LinearLayout,
            val tvName: TextView,
            val tvCount: TextView,
            reducedAnimations: () -> Boolean,
            onCategorySelected: (VodCategorySidebarItem) -> Unit
        ) : RecyclerView.ViewHolder(root) {
            var boundItem: VodCategorySidebarItem? = null
            var isItemSelected: Boolean = false

            fun applyTextColors(hasFocus: Boolean) {
                if (hasFocus) {
                    tvName.setTextColor(Color.parseColor("#090A0D"))
                    tvCount.setTextColor(Color.parseColor("#374151"))
                } else if (isItemSelected) {
                    tvName.setTextColor(Color.parseColor("#E5A93B"))
                    tvCount.setTextColor(Color.parseColor("#E5A93B"))
                } else {
                    tvName.setTextColor(Color.parseColor("#D1D5DB"))
                    tvCount.setTextColor(Color.parseColor("#6B7280"))
                }
            }

            init {
                root.setOnClickListener {
                    boundItem?.let(onCategorySelected)
                }
                root.setOnFocusChangeListener { v, hasFocus ->
                    applyTextColors(hasFocus)
                    if (reducedAnimations()) {
                        v.scaleX = if (hasFocus) 1.015f else 1.0f
                        v.scaleY = if (hasFocus) 1.015f else 1.0f
                    } else {
                        val s = if (hasFocus) 1.025f else 1.0f
                        v.animate().scaleX(s).scaleY(s).setDuration(90L).start()
                    }
                }
            }
        }
    }

    /**
     * V23.1 Obsidian Cinema Poster Grid Adapter for Movies & Series.
     * Clean 2:3 cinema posters with rounded clipping, subtle dark matte badges,
     * cinema gold resume progress bar, crisp white TV focus ring, and bounded RGB_565 Glide loading.
     */
    private class VodPosterGridAdapter(
        private val posterOptionsProvider: () -> RequestOptions,
        private val reducedAnimations: () -> Boolean,
        private val onPosterFocused: (Int) -> Unit,
        private val onPosterClicked: (PosterCardBindItem) -> Unit
    ) : RecyclerView.Adapter<VodPosterGridAdapter.PosterViewHolder>() {

        private var items: List<PosterCardBindItem> = emptyList()

        init {
            setHasStableIds(true)
        }

        fun submitItems(newItems: List<PosterCardBindItem>) {
            items = newItems
            notifyDataSetChanged()
        }

        fun getItemOrNull(position: Int): PosterCardBindItem? = items.getOrNull(position)

        override fun getItemId(position: Int): Long {
            return M3uParser.fnv1a64(items[position].key)
        }

        override fun getItemCount(): Int = items.size

        private fun dp(ctx: Context, v: Int): Int =
            TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), ctx.resources.displayMetrics).toInt()

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PosterViewHolder {
            val ctx = parent.context
            val card = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                isFocusable = true
                isClickable = true
                setBackgroundResource(R.drawable.bg_obsidian_poster_card)
                setPadding(dp(ctx, 4), dp(ctx, 4), dp(ctx, 4), dp(ctx, 8))
                layoutParams = RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    val m = dp(ctx, 6)
                    setMargins(m, m, m, m)
                }
            }

            val posterFrame = FrameLayout(ctx).apply {
                setBackgroundColor(Color.parseColor("#FF161922"))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    dp(ctx, 198)
                )
                val r = dp(ctx, 7).toFloat()
                outlineProvider = object : android.view.ViewOutlineProvider() {
                    override fun getOutline(v: View, outline: android.graphics.Outline) {
                        outline.setRoundRect(0, 0, v.width, v.height, r)
                    }
                }
                clipToOutline = true
            }

            val ivPoster = ImageView(ctx).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(Color.parseColor("#FF161922"))
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            }
            posterFrame.addView(ivPoster)

            val scrimView = View(ctx).apply {
                setBackgroundResource(R.drawable.bg_vod_poster_scrim)
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    dp(ctx, 44),
                    Gravity.BOTTOM
                )
            }
            posterFrame.addView(scrimView)

            val tvQualityBadge = TextView(ctx).apply {
                textSize = 9f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#F4F5F7"))
                setBackgroundResource(R.drawable.bg_obsidian_badge_dark)
                setPadding(dp(ctx, 6), dp(ctx, 2), dp(ctx, 6), dp(ctx, 2))
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP or Gravity.END
                ).apply {
                    topMargin = dp(ctx, 6)
                    marginEnd = dp(ctx, 6)
                }
            }
            posterFrame.addView(tvQualityBadge)

            val tvYearBadge = TextView(ctx).apply {
                textSize = 9f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#E5A93B"))
                setBackgroundResource(R.drawable.bg_obsidian_badge_dark)
                setPadding(dp(ctx, 6), dp(ctx, 2), dp(ctx, 6), dp(ctx, 2))
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP or Gravity.START
                ).apply {
                    topMargin = dp(ctx, 6)
                    marginStart = dp(ctx, 6)
                }
            }
            posterFrame.addView(tvYearBadge)

            val progressBar = ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                progress = 0
                visibility = View.GONE
                progressTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#E5A93B"))
                progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#66000000"))
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    dp(ctx, 3),
                    Gravity.BOTTOM
                )
            }
            posterFrame.addView(progressBar)

            card.addView(posterFrame)

            val tvTitle = TextView(ctx).apply {
                textSize = 12f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#F4F5F7"))
                gravity = Gravity.START
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setPadding(dp(ctx, 4), 0, dp(ctx, 4), 0)
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    topMargin = dp(ctx, 7)
                }
            }
            card.addView(tvTitle)

            val tvSubtitle = TextView(ctx).apply {
                textSize = 10f
                setTextColor(Color.parseColor("#9CA3AF"))
                gravity = Gravity.START
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setPadding(dp(ctx, 4), 0, dp(ctx, 4), 0)
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    topMargin = dp(ctx, 2)
                }
            }
            card.addView(tvSubtitle)

            return PosterViewHolder(
                card,
                ivPoster,
                tvQualityBadge,
                tvYearBadge,
                progressBar,
                tvTitle,
                tvSubtitle,
                reducedAnimations,
                onPosterFocused,
                onPosterClicked
            )
        }

        override fun onBindViewHolder(holder: PosterViewHolder, position: Int) {
            val item = items[position]
            holder.boundItem = item
            holder.boundPosition = position
            holder.tvTitle.text = item.title
            holder.tvSubtitle.text = if (item.isFavorite) "★ ${item.subtitle}" else item.subtitle

            if (item.qualityBadge.isNotBlank()) {
                holder.tvQualityBadge.text = item.qualityBadge
                holder.tvQualityBadge.visibility = View.VISIBLE
            } else {
                holder.tvQualityBadge.visibility = View.GONE
            }

            if (item.yearBadge.isNotBlank()) {
                holder.tvYearBadge.text = item.yearBadge
                holder.tvYearBadge.visibility = View.VISIBLE
            } else {
                holder.tvYearBadge.visibility = View.GONE
            }

            if (item.progressPercent > 0) {
                holder.progressBar.progress = item.progressPercent
                holder.progressBar.visibility = View.VISIBLE
            } else {
                holder.progressBar.visibility = View.GONE
            }

            val fallbackIcon = if (item.seriesSummary != null) R.drawable.ic_3d_series else R.drawable.ic_3d_movies
            if (item.posterUrl.isNotBlank()) {
                holder.ivPoster.scaleType = ImageView.ScaleType.CENTER_CROP
                Glide.with(holder.ivPoster.context)
                    .load(item.posterUrl)
                    .apply(posterOptionsProvider().placeholder(fallbackIcon).error(fallbackIcon))
                    .into(holder.ivPoster)
            } else {
                Glide.with(holder.ivPoster.context).clear(holder.ivPoster)
                holder.ivPoster.scaleType = ImageView.ScaleType.CENTER_INSIDE
                holder.ivPoster.setImageResource(fallbackIcon)
            }
        }

        class PosterViewHolder(
            val root: LinearLayout,
            val ivPoster: ImageView,
            val tvQualityBadge: TextView,
            val tvYearBadge: TextView,
            val progressBar: ProgressBar,
            val tvTitle: TextView,
            val tvSubtitle: TextView,
            reducedAnimations: () -> Boolean,
            onPosterFocused: (Int) -> Unit,
            onPosterClicked: (PosterCardBindItem) -> Unit
        ) : RecyclerView.ViewHolder(root) {
            var boundItem: PosterCardBindItem? = null
            var boundPosition: Int = 0

            init {
                root.setOnClickListener {
                    boundItem?.let(onPosterClicked)
                }
                root.setOnFocusChangeListener { v, hasFocus ->
                    if (hasFocus) {
                        onPosterFocused(boundPosition)
                    }
                    if (reducedAnimations()) {
                        v.scaleX = if (hasFocus) 1.02f else 1.0f
                        v.scaleY = if (hasFocus) 1.02f else 1.0f
                    } else {
                        val s = if (hasFocus) 1.045f else 1.0f
                        v.animate().scaleX(s).scaleY(s).setDuration(105L).start()
                    }
                }
            }
        }
    }

    /**
     * 4D Crystal Glass Channel Card Adapter for 512MB RAM Android TVs.
     */
    private class ChannelDrawerAdapter(
        private val channelProvider: (Int) -> Channel?,
        private val isFavorite: (String) -> Boolean,
        private val epgProvider: (Channel) -> String?,
        private val logoOptions: RequestOptions,
        private val onChannelClick: (Int) -> Unit,
        private val onChannelFocused: (Int) -> Unit
    ) : RecyclerView.Adapter<ChannelDrawerAdapter.ChannelViewHolder>() {

        companion object {
            private const val PAYLOAD_ACTIVE_STATE = 1
            private const val PAYLOAD_FAVORITE_STATE = 2
        }

        private var indices: IntArray = IntArray(0)
        private var indicesAscending: Boolean = true
        private var activeGlobalIndex: Int = 0
        private var activeRowDrawableRes: Int = R.drawable.bg_btn_3d_cyan
        private val inactiveRowDrawableRes: Int = R.drawable.bg_channel_row_4d
        private val metaBuilder = StringBuilder(64)

        init {
            setHasStableIds(true)
        }

        fun currentIndices(): IntArray = indices

        private fun findAdapterPos(globalIndex: Int): Int {
            if (indices.isEmpty()) return -1
            if (indicesAscending) {
                val pos = Arrays.binarySearch(indices, globalIndex)
                return if (pos >= 0) pos else -1
            }
            return indices.indexOfFirst { it == globalIndex }
        }

        fun setActiveRowDrawable(drawableRes: Int) {
            if (activeRowDrawableRes == drawableRes) return
            activeRowDrawableRes = drawableRes
            val activePos = findAdapterPos(activeGlobalIndex)
            if (activePos != -1) {
                notifyItemChanged(activePos, PAYLOAD_ACTIVE_STATE)
            }
        }

        fun submitIndices(
            newIndices: IntArray,
            currentGlobalIndex: Int,
            diffResult: DiffUtil.DiffResult?,
            isAscending: Boolean = true
        ) {
            val prevActiveGlobal = activeGlobalIndex
            indices = newIndices
            indicesAscending = isAscending
            activeGlobalIndex = currentGlobalIndex
            if (diffResult != null) {
                diffResult.dispatchUpdatesTo(this)
                if (prevActiveGlobal != currentGlobalIndex) {
                    val oldPos = findAdapterPos(prevActiveGlobal)
                    val newPos = findAdapterPos(currentGlobalIndex)
                    if (oldPos != -1) notifyItemChanged(oldPos, PAYLOAD_ACTIVE_STATE)
                    if (newPos != -1) notifyItemChanged(newPos, PAYLOAD_ACTIVE_STATE)
                }
            } else {
                notifyDataSetChanged()
            }
        }

        fun updateActiveChannel(newGlobalIndex: Int) {
            if (activeGlobalIndex == newGlobalIndex) return
            val oldGlobal = activeGlobalIndex
            activeGlobalIndex = newGlobalIndex
            val oldPos = findAdapterPos(oldGlobal)
            val newPos = findAdapterPos(newGlobalIndex)
            if (oldPos != -1) notifyItemChanged(oldPos, PAYLOAD_ACTIVE_STATE)
            if (newPos != -1) notifyItemChanged(newPos, PAYLOAD_ACTIVE_STATE)
        }

        fun notifyFavoriteChanged(globalIndex: Int) {
            val pos = findAdapterPos(globalIndex)
            if (pos != -1) notifyItemChanged(pos, PAYLOAD_FAVORITE_STATE)
        }

        override fun getItemId(position: Int): Long = indices[position].toLong()

        private fun dp(ctx: Context, v: Int): Int =
            TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), ctx.resources.displayMetrics).toInt()

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChannelViewHolder {
            val ctx = parent.context
            val root = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                isFocusable = true
                isClickable = true
                setBackgroundResource(inactiveRowDrawableRes)
                setPadding(dp(ctx, 10), dp(ctx, 8), dp(ctx, 10), dp(ctx, 8))
                layoutParams = RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = dp(ctx, 7)
                }
            }

            val tvNum = TextView(ctx).apply {
                textSize = 12f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#38BDF8"))
                setBackgroundResource(R.drawable.bg_badge_neon)
                gravity = Gravity.CENTER
                minWidth = dp(ctx, 42)
                setPadding(dp(ctx, 7), dp(ctx, 4), dp(ctx, 7), dp(ctx, 4))
            }
            root.addView(tvNum)

            val ivLogo = ImageView(ctx).apply {
                setBackgroundResource(R.drawable.bg_channel_logo_frame)
                setPadding(dp(ctx, 4), dp(ctx, 4), dp(ctx, 4), dp(ctx, 4))
                scaleType = ImageView.ScaleType.FIT_CENTER
                setImageResource(R.drawable.ic_3d_live_tv)
                layoutParams = LinearLayout.LayoutParams(dp(ctx, 34), dp(ctx, 34)).apply {
                    marginStart = dp(ctx, 8)
                }
            }
            root.addView(ivLogo)

            val textCol = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = dp(ctx, 9)
                    marginEnd = dp(ctx, 6)
                }
            }
            val tvTitle = TextView(ctx).apply {
                textSize = 13.5f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.WHITE)
                setSingleLine(true)
                ellipsize = TextUtils.TruncateAt.END
            }
            val tvSub = TextView(ctx).apply {
                textSize = 11f
                setTextColor(Color.parseColor("#BAE6FD"))
                setSingleLine(true)
                ellipsize = TextUtils.TruncateAt.END
            }
            textCol.addView(tvTitle)
            textCol.addView(tvSub)
            root.addView(textCol)

            val tvFavBadge = TextView(ctx).apply {
                textSize = 11f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#FDE047"))
                setPadding(dp(ctx, 4), dp(ctx, 2), dp(ctx, 4), dp(ctx, 2))
            }
            root.addView(tvFavBadge)

            return ChannelViewHolder(root, tvNum, ivLogo, tvTitle, tvSub, tvFavBadge, onChannelClick, onChannelFocused)
        }

        override fun onBindViewHolder(
            holder: ChannelViewHolder,
            position: Int,
            payloads: MutableList<Any>
        ) {
            if (payloads.isEmpty()) {
                onBindViewHolder(holder, position)
                return
            }
            val globalIdx = indices[position]
            val ch = channelProvider(globalIdx) ?: return
            val isSelected = globalIdx == activeGlobalIndex
            holder.root.isSelected = isSelected
            for (payload in payloads) {
                when (payload) {
                    PAYLOAD_ACTIVE_STATE -> {
                        holder.root.setBackgroundResource(if (isSelected) activeRowDrawableRes else inactiveRowDrawableRes)
                        bindBadgeState(holder, ch, isSelected)
                    }
                    PAYLOAD_FAVORITE_STATE -> {
                        bindBadgeState(holder, ch, isSelected)
                    }
                }
            }
        }

        override fun onBindViewHolder(holder: ChannelViewHolder, position: Int) {
            val globalIdx = indices[position]
            holder.boundGlobalIndex = globalIdx
            val ch = channelProvider(globalIdx) ?: return
            val isSelected = globalIdx == activeGlobalIndex
            holder.root.isSelected = isSelected

            holder.tvNum.text = ch.displayNumberFormatted()
            holder.tvTitle.text = ch.name

            metaBuilder.setLength(0)
            metaBuilder.append(ch.category)
            val nowProg = epgProvider(ch)
            if (!nowProg.isNullOrBlank()) {
                metaBuilder.append(" • ").append(nowProg)
            } else if (ch.backupUrl.isNotBlank()) {
                metaBuilder.append(" • ⚡ Dual-Stream")
            } else {
                metaBuilder.append(" • Live HD")
            }
            holder.tvSub.text = metaBuilder.toString()

            if (ch.logoUrl.isNotBlank()) {
                Glide.with(holder.ivLogo.context)
                    .load(ch.logoUrl)
                    .apply(logoOptions)
                    .into(holder.ivLogo)
            } else {
                Glide.with(holder.ivLogo.context).clear(holder.ivLogo)
                holder.ivLogo.setImageResource(R.drawable.ic_3d_live_tv)
            }

            holder.root.setBackgroundResource(if (isSelected) activeRowDrawableRes else inactiveRowDrawableRes)
            bindBadgeState(holder, ch, isSelected)
        }

        private fun bindBadgeState(holder: ChannelViewHolder, ch: Channel, isSelected: Boolean) {
            val fav = isFavorite(ch.id)
            when {
                isSelected && fav -> {
                    holder.tvFavBadge.text = "★ LIVE"
                    holder.tvFavBadge.setTextColor(Color.parseColor("#FDE047"))
                }
                isSelected -> {
                    holder.tvFavBadge.text = "● LIVE"
                    holder.tvFavBadge.setTextColor(Color.parseColor("#6EE7B7"))
                }
                fav -> {
                    holder.tvFavBadge.text = "★"
                    holder.tvFavBadge.setTextColor(Color.parseColor("#FDE047"))
                }
                else -> {
                    holder.tvFavBadge.text = ""
                }
            }
        }

        override fun getItemCount(): Int = indices.size

        class ChannelViewHolder(
            val root: LinearLayout,
            val tvNum: TextView,
            val ivLogo: ImageView,
            val tvTitle: TextView,
            val tvSub: TextView,
            val tvFavBadge: TextView,
            onChannelClick: (Int) -> Unit,
            onChannelFocused: (Int) -> Unit
        ) : RecyclerView.ViewHolder(root) {
            var boundGlobalIndex: Int = -1

            init {
                root.setOnClickListener {
                    if (boundGlobalIndex >= 0) {
                        onChannelClick(boundGlobalIndex)
                    }
                }
                root.setOnFocusChangeListener { v, hasFocus ->
                    val targetScale = if (hasFocus) 1.02f else 1.0f
                    v.animate().scaleX(targetScale).scaleY(targetScale).setDuration(100L).start()
                    if (hasFocus && boundGlobalIndex >= 0) {
                        onChannelFocused(boundGlobalIndex)
                    }
                }
            }
        }
    }

    // =========================================================================
    // RAM PLAYER v21.0 COMPLETE MISSING FEATURES IMPLEMENTATION
    // =========================================================================

    private fun startVoiceSearch() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak channel, movie, or series name...")
        }
        if (packageManager.resolveActivity(intent, 0) != null) {
            try {
                voiceSearchLauncher.launch(intent)
            } catch (e: Exception) {
                Toast.makeText(this, "Voice search unavailable; use keyboard search", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "No voice recognizer app installed on this TV", Toast.LENGTH_SHORT).show()
        }
    }

    private fun ensureDelayedSubtitleOverlay(): TextView {
        tvDelayedSubtitleOverlay?.let { return it }
        val parent = playerView.parent as? ViewGroup
        val tv = TextView(this).apply {
            textSize = 18f
            setTextColor(Color.WHITE)
            setBackgroundColor(0x99000000.toInt())
            setPadding(dp(14), dp(6), dp(14), dp(6))
            gravity = Gravity.CENTER
            visibility = View.GONE
        }
        val lp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            bottomMargin = dp(48)
        }
        parent?.addView(tv, lp)
        tvDelayedSubtitleOverlay = tv
        return tv
    }

    private fun detectDisplayHdrTypes(): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return "SDR"
        val hdrTypes = try {
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay?.hdrCapabilities?.supportedHdrTypes ?: intArrayOf()
        } catch (_: Exception) {
            intArrayOf()
        }
        if (hdrTypes.isEmpty()) return "SDR"
        val labels = ArrayList<String>(4)
        for (t in hdrTypes) {
            when (t) {
                Display.HdrCapabilities.HDR_TYPE_DOLBY_VISION -> labels.add("DV")
                Display.HdrCapabilities.HDR_TYPE_HDR10 -> labels.add("HDR10")
                Display.HdrCapabilities.HDR_TYPE_HLG -> labels.add("HLG")
                else -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && t == Display.HdrCapabilities.HDR_TYPE_HDR10_PLUS) labels.add("HDR10+")
            }
        }
        return if (labels.isEmpty()) "SDR" else labels.distinct().joinToString("/")
    }

    private fun detectActiveStreamHdrLabel(vf: androidx.media3.common.Format?): String {
        if (vf == null) return "SDR"
        val mime = vf.sampleMimeType.orEmpty()
        if (mime.contains("dolby-vision", ignoreCase = true)) return "Dolby Vision"
        val ci = vf.colorInfo ?: return "SDR"
        return when (ci.colorTransfer) {
            C.COLOR_TRANSFER_HLG -> "HLG HDR"
            C.COLOR_TRANSFER_ST2084 -> "HDR10"
            else -> "SDR"
        }
    }

    private fun detectSupportedPassthroughCodecs(): List<String> {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return emptyList()
        val am = getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return emptyList()
        val encodings = HashSet<Int>()
        try {
            for (dev in am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
                for (enc in dev.encodings) {
                    encodings.add(enc)
                }
            }
        } catch (_: Exception) {
            return emptyList()
        }
        val supported = ArrayList<String>(4)
        if (encodings.contains(AudioFormat.ENCODING_AC3)) supported.add("AC3")
        if (encodings.contains(AudioFormat.ENCODING_E_AC3)) supported.add("E-AC3")
        if (encodings.contains(AudioFormat.ENCODING_DTS)) supported.add("DTS")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && encodings.contains(AudioFormat.ENCODING_DOLBY_TRUEHD)) {
            supported.add("TrueHD")
        }
        return supported
    }

    private fun applyAudioPassthroughPreference(player: ExoPlayer) {
        val supported = detectSupportedPassthroughCodecs()
        val enabled = profileStore.isAudioOffloadEnabled(activeAccountScope) && supported.isNotEmpty()
        val mode = if (enabled) {
            TrackSelectionParameters.AudioOffloadPreferences.AUDIO_OFFLOAD_MODE_ENABLED
        } else {
            TrackSelectionParameters.AudioOffloadPreferences.AUDIO_OFFLOAD_MODE_DISABLED
        }
        val offloadPrefs = TrackSelectionParameters.AudioOffloadPreferences.Builder()
            .setAudioOffloadMode(mode)
            .build()
        player.trackSelectionParameters = player.trackSelectionParameters
            .buildUpon()
            .setAudioOffloadPreferences(offloadPrefs)
            .build()
    }

    private fun executeConfigurableRemoteAction(action: String) {
        when (action) {
            "FAVORITE_TOGGLE" -> {
                toggleCurrentChannelFavorite()
                showZappingOsd()
            }
            "EPG_GUIDE" -> showEpgGuideHubDialog()
            "AUDIO_QUALITY" -> showAudioAndQualityDialog()
            "SETTINGS" -> showCategorizedSettingsCenterDialog()
            "CHANNEL_INFO" -> showLiveChannelManagementModal()
            "PLAYER_LOCK" -> togglePlayerLock()
            "SLEEP_TIMER" -> showSleepTimerCustomDialog()
            else -> showGlobalQuickMenuDialog()
        }
    }

    private fun showChannelPreviewCard(ch: Channel) {
        val epgPair = epgMap[ch.epgId]
        val nowProg = epgPair?.first?.takeIf { it.isNotBlank() } ?: "No live EPG programme"
        val nextProg = epgPair?.second?.takeIf { it.isNotBlank() } ?: "Upcoming info unavailable"
        val streamType = when {
            ch.streamUrl.contains(".m3u8", ignoreCase = true) -> "HLS Adaptive"
            ch.streamUrl.contains("/live/", ignoreCase = true) -> "Xtream Live"
            else -> "Direct Stream"
        }
        val options = listOf(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_play,
                title = "▶ Tune to #${ch.displayNumberFormatted()} ${ch.name}",
                subtitle = "Now: $nowProg • Next: $nextProg • Format: $streamType",
                badgeText = "TUNE NOW",
                isHighlighted = true
            ) {
                val idx = channelIndexById[ch.id] ?: currentChannelIndex
                vodPosterGridPanel.visibility = View.GONE
                activePlaybackMode = ActivePlaybackMode.LIVE_TV
                switchChannel(idx, immediatePlayback = true)
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_epg,
                title = "📺 Category: ${ch.category}",
                subtitle = "512MB-RAM-safe metadata + EPG preview (zero dual-decoder overhead)",
                badgeText = streamType
            ) {}
        )
        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_live_tv,
            title = "Channel Preview: ${ch.name}",
            subtitle = "Channel #${ch.displayNumberFormatted()} • ${ch.category}",
            badgeText = "PREVIEW",
            options = options,
            closeLabel = "Back"
        )
    }

    private fun showChannelBlacklistManagerDialog() {
        val blockedIds = profileStore.getBlacklistedChannelIds(activeAccountScope)
        val options = ArrayList<GlassModalOption>(blockedIds.size + 2)
        for (id in blockedIds) {
            val ch = channelIndexById[id]?.let { allChannels.getOrNull(it) }
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_lock,
                    title = ch?.name ?: "Channel ID: $id",
                    subtitle = "Tap to unblock and restore this channel to Live TV",
                    badgeText = "UNBLOCK"
                ) {
                    profileStore.unblockBlacklistedChannel(id, activeAccountScope)
                    renderDrawerList()
                    showChannelBlacklistManagerDialog()
                }
            )
        }
        if (blockedIds.isNotEmpty()) {
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_trash,
                    title = "Clear All Blacklisted Channels (${blockedIds.size})",
                    subtitle = "Restore every blacklisted channel for the active profile",
                    badgeText = "CLEAR ALL"
                ) {
                    profileStore.clearAllBlacklistedChannels(activeAccountScope)
                    renderDrawerList()
                    Toast.makeText(this, "Blacklist cleared", Toast.LENGTH_SHORT).show()
                }
            )
        }
        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_lock,
            title = "Persistent Channel Blacklist",
            subtitle = "${blockedIds.size} blocked channels (separate from Hide/Unhide)",
            badgeText = "${blockedIds.size} BLOCKED",
            options = options,
            closeLabel = "Back"
        )
    }

    private fun scheduleAutoRefreshIfConfigured() {
        uiHandler.removeCallbacks(autoRefreshRunnable)
        if (!::profileStore.isInitialized) return
        val hours = profileStore.getAutoRefreshIntervalHours(activeAccountScope)
        try {
            PlaylistRefreshWorker.schedulePeriodicRefresh(this, hours, activeAccountScope)
        } catch (_: Exception) {
            if (hours > 0) uiHandler.postDelayed(autoRefreshRunnable, hours * 3_600_000L)
        }
    }

    private fun cancelAutoRefreshScheduler() {
        uiHandler.removeCallbacks(autoRefreshRunnable)
        isAutoRefreshRunning = false
        xtreamRepo.cancelActiveFetch()
        try {
            PlaylistRefreshWorker.cancelScheduledRefresh(this, activeAccountScope)
        } catch (_: Exception) {}
        profileStore.recordPlaylistRefreshResult(false, "Cancelled by user", activeAccountScope)
        Toast.makeText(this, "WorkManager scheduled playlist refresh cancelled", Toast.LENGTH_SHORT).show()
    }

    private fun triggerPlaylistRefreshNow(isScheduled: Boolean) {
        val activeId = profileStore.activeId()
        val profile = profileStore.all().firstOrNull { it.id == activeId }
        if (profile == null) {
            profileStore.recordPlaylistRefreshResult(false, "No active profile", activeAccountScope)
            return
        }
        isAutoRefreshRunning = true
        try {
            when (profile.type) {
                ProfileType.M3U -> loadM3uFromInput(profile.source, profile.name, forceNetworkRefresh = true, scopeOverride = profile.id)
                ProfileType.XTREAM -> {
                    val creds = XtreamCredentials(profile.name, profile.source, profile.username, profile.password)
                    loadXtreamChannels(creds, forceNetworkRefresh = true, scopeOverride = profile.id)
                }
            }
            profileStore.recordPlaylistRefreshResult(true, if (isScheduled) "Auto-refreshed ${profile.name}" else "Refreshed ${profile.name}", activeAccountScope)
        } catch (e: Exception) {
            profileStore.recordPlaylistRefreshResult(false, e.message ?: "Refresh error", activeAccountScope)
        } finally {
            isAutoRefreshRunning = false
            scheduleAutoRefreshIfConfigured()
        }
    }

    private fun showPlaylistAutoRefreshAndHealthHubDialog() {
        val hours = profileStore.getAutoRefreshIntervalHours(activeAccountScope)
        val onStartup = profileStore.isAutoRefreshOnStartup(activeAccountScope)
        val lastStatus = profileStore.getLastRefreshStatus(activeAccountScope)
        val options = listOf(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_sync,
                title = "Auto-Refresh Interval: ${if (hours == 0) "OFF" else "Every ${hours}h"}",
                subtitle = "Tap to cycle schedule: OFF → 6h → 12h → 24h → 72h",
                badgeText = if (hours == 0) "OFF" else "${hours}h",
                isHighlighted = hours > 0
            ) {
                val nextH = when (hours) {
                    0 -> 6
                    6 -> 12
                    12 -> 24
                    24 -> 72
                    else -> 0
                }
                profileStore.setAutoRefreshIntervalHours(nextH, activeAccountScope)
                scheduleAutoRefreshIfConfigured()
                showPlaylistAutoRefreshAndHealthHubDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_rocket,
                title = "Refresh Playlist on Startup",
                subtitle = "Automatically refresh active playlist when RAM PLAYER launches",
                badgeText = if (onStartup) "ON ✓" else "OFF",
                isHighlighted = onStartup
            ) {
                profileStore.setAutoRefreshOnStartup(!onStartup, activeAccountScope)
                showPlaylistAutoRefreshAndHealthHubDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_sync,
                title = "▶ Manual Refresh Now",
                subtitle = "Last status: $lastStatus",
                badgeText = if (isAutoRefreshRunning) "RUNNING" else "SYNC"
            ) {
                triggerPlaylistRefreshNow(isScheduled = false)
                showPlaylistAutoRefreshAndHealthHubDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_trash,
                title = "⏹ Cancel Active / Scheduled Refresh",
                subtitle = "Stop active fetch and clear pending auto-refresh timer",
                badgeText = "CANCEL"
            ) {
                cancelAutoRefreshScheduler()
                showPlaylistAutoRefreshAndHealthHubDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_lock,
                title = "🛡️ Manage Channel Blacklist (${profileStore.getBlacklistedChannelIds(activeAccountScope).size})",
                subtitle = "View or unblock blacklisted channels separately from Hide/Unhide",
                badgeText = "BLACKLIST"
            ) { showChannelBlacklistManagerDialog() },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_playlist,
                title = "🩺 Playlist Health & Smart Duplicate Detector",
                subtitle = "Inspect channel health, missing logos, backup streams & duplicate channels",
                badgeText = "HEALTH"
            ) { showPlaylistHealthAndDuplicatesDialog() }
        )
        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_playlist,
            title = "Playlist Auto-Refresh, Blacklist & Health",
            subtitle = "Last Refresh: $lastStatus",
            badgeText = if (hours == 0) "MANUAL" else "${hours}h AUTO",
            options = options,
            closeLabel = "Back"
        )
    }

    private fun showAppearanceAndLayoutHubDialog() {
        val options = listOf(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_theme,
                title = "4D Themes, UI Density & Overscan",
                subtitle = "Configure AMOLED themes, Standard/Compact/Large density, clock & overscan",
                badgeText = "THEME"
            ) { showAppearanceDensityAndOverscanDialog() },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_home,
                title = "Customize Home Screen Rows",
                subtitle = "Show, hide, or reorder Home Hub rows per profile",
                badgeText = "HOME ROWS"
            ) { showHomeRowCustomizationDialog() },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_channels,
                title = "Customize Navigation / Sidebar Icons",
                subtitle = "Show, hide, or reorder navigation buttons (Home & Settings stay accessible)",
                badgeText = "SIDEBAR"
            ) { showSidebarCustomizationDialog() }
        )
        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_theme,
            title = "Appearance, Home Rows & Sidebar",
            subtitle = "Customize layout per profile",
            badgeText = "LAYOUT",
            options = options,
            closeLabel = "Back"
        )
    }

    private fun showHomeRowCustomizationDialog() {
        val order = profileStore.getHomeRowOrder(activeAccountScope)
        val hidden = profileStore.getHiddenHomeRows(activeAccountScope)
        val options = ArrayList<GlassModalOption>(order.size * 2 + 1)
        for (rowId in order) {
            val visible = !hidden.contains(rowId)
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_home,
                    title = "${if (visible) "👁️" else "🙈"} $rowId",
                    subtitle = "Tap to toggle visibility • Use Move Up below to reorder",
                    badgeText = if (visible) "VISIBLE" else "HIDDEN",
                    isHighlighted = visible
                ) {
                    profileStore.toggleHomeRowVisible(rowId, activeAccountScope)
                    showHomeRowCustomizationDialog()
                }
            )
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_rocket,
                    title = "↑ Move '$rowId' Up",
                    subtitle = "Move this Home row higher in Cinematic Home Hub",
                    badgeText = "MOVE UP"
                ) {
                    profileStore.moveHomeRow(rowId, -1, activeAccountScope)
                    showHomeRowCustomizationDialog()
                }
            )
        }
        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_sync,
                title = "Reset Home Rows to Default",
                subtitle = "Restore default order and show all Home Hub rows",
                badgeText = "RESET"
            ) {
                profileStore.resetHomeRows(activeAccountScope)
                showHomeRowCustomizationDialog()
            }
        )
        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_home,
            title = "Customize Home Screen Rows",
            subtitle = "Changes apply immediately per profile",
            badgeText = "${order.size - hidden.size}/${order.size}",
            options = options,
            closeLabel = "Back"
        )
    }

    private fun applySidebarCustomization() {
        if (!::profileStore.isInitialized) return
        val buttonMap = mapOf(
            "CHANNELS" to findViewById<View?>(R.id.btnToggleDrawer),
            "LIVE_TV" to findViewById<View?>(R.id.btnSectionLiveTv),
            "MOVIES" to findViewById<View?>(R.id.btnSectionMovies),
            "SERIES" to findViewById<View?>(R.id.btnSectionSeries),
            "SEARCH" to findViewById<View?>(R.id.btnUnifiedSearch),
            "ACCOUNTS" to findViewById<View?>(R.id.btnProfiles),
            "XTREAM" to findViewById<View?>(R.id.btnXtreamLogin),
            "PLAYLIST" to findViewById<View?>(R.id.btnM3uLoad),
            "SYNC" to findViewById<View?>(R.id.btnRefreshChannels),
            "AUDIO_HD" to findViewById<View?>(R.id.btnAudioQuality),
            "STUDIO_4D" to findViewById<View?>(R.id.btnThemeToggle),
            "EPG" to findViewById<View?>(R.id.btnEpg),
            "SLEEP" to findViewById<View?>(R.id.btnSleepTimer),
            "ASPECT" to findViewById<View?>(R.id.btnAspectToggle)
        )
        val hidden = profileStore.getHiddenSidebarItems(activeAccountScope)
        val order = profileStore.getSidebarOrder(activeAccountScope)
        val container = findViewById<View?>(R.id.btnHomeHub)?.parent as? ViewGroup
        if (container != null) {
            for (key in order) {
                val v = buttonMap[key] ?: continue
                v.visibility = if (hidden.contains(key)) View.GONE else View.VISIBLE
                if (v.parent === container) {
                    container.removeView(v)
                    container.addView(v)
                }
            }
            findViewById<View?>(R.id.btnSettings)?.let { sBtn ->
                sBtn.visibility = View.VISIBLE
                if (sBtn.parent === container) {
                    container.removeView(sBtn)
                    container.addView(sBtn)
                }
            }
        }
    }

    private fun showSidebarCustomizationDialog() {
        val order = profileStore.getSidebarOrder(activeAccountScope)
        val hidden = profileStore.getHiddenSidebarItems(activeAccountScope)
        val options = ArrayList<GlassModalOption>(order.size * 2 + 1)
        for (key in order) {
            val visible = !hidden.contains(key)
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_channels,
                    title = "${if (visible) "👁️" else "🙈"} Nav Icon: $key",
                    subtitle = "Tap to show/hide in navigation bar (Home & Settings stay visible)",
                    badgeText = if (visible) "SHOWN" else "HIDDEN",
                    isHighlighted = visible
                ) {
                    profileStore.toggleSidebarItemVisible(key, activeAccountScope)
                    applySidebarCustomization()
                    showSidebarCustomizationDialog()
                }
            )
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_rocket,
                    title = "← Move '$key' Left",
                    subtitle = "Move this navigation icon earlier in the bar",
                    badgeText = "MOVE"
                ) {
                    profileStore.moveSidebarItem(key, -1, activeAccountScope)
                    applySidebarCustomization()
                    showSidebarCustomizationDialog()
                }
            )
        }
        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_sync,
                title = "Reset Navigation Bar to Default",
                subtitle = "Restore default icon order and show all buttons",
                badgeText = "RESET"
            ) {
                profileStore.resetSidebarCustomization(activeAccountScope)
                applySidebarCustomization()
                showSidebarCustomizationDialog()
            }
        )
        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_channels,
            title = "Customize Navigation / Sidebar",
            subtitle = "Per-profile visibility & order",
            badgeText = "${order.size - hidden.size}/${order.size}",
            options = options,
            closeLabel = "Back"
        )
    }

    private fun cancelPendingDelayedSubtitles() {
        subtitleCueGeneration++
        tvDelayedSubtitleOverlay?.visibility = View.GONE
    }

    private fun showSearchableSettingsDialog() {
        show4dGlassFormModal(
            headerIconRes = R.drawable.ic_3d_search,
            title = "Search All 24 Settings Categories",
            subtitle = "Type any keyword (e.g. delay, subtitle, refresh, blacklist, home, sidebar, privacy, backup, hdr)",
            badgeText = "24 CATEGORIES",
            fields = listOf(
                GlassFormFieldSpec(
                    label = "SETTING KEYWORD",
                    hint = "e.g. audio, subtitle, refresh, remote, privacy...",
                    iconRes = R.drawable.ic_3d_search,
                    initialValue = ""
                )
            ),
            positiveLabel = "Find Setting",
            positiveBgRes = R.drawable.bg_btn_3d_cyan
        ) { vals ->
            val q = vals.firstOrNull().orEmpty().trim().lowercase(Locale.ROOT)
            val catalog = listOf(
                Triple("General & Startup", "startup wizard boot resume screensaver", { showAboutAndUpdateCenterDialog() }),
                Triple("Player & Background Playback", "player playback seek speed lock external osd", { showPlaybackAndBackgroundSettingsDialog() }),
                Triple("Audio, Delay & Passthrough", "audio delay passthrough offload boost track", { showAudioAndQualityDialog() }),
                Triple("Subtitles & Delay", "subtitle caption delay sync", { showAudioAndQualityDialog() }),
                Triple("Video & HDR Format", "video quality resolution hdr 4k aspect", { showAudioAndQualityDialog() }),
                Triple("Live TV & Blacklist", "live tv channel sort hide blacklist preview", { showLiveChannelManagementModal() }),
                Triple("Movies & VOD", "movies vod poster watchlist", { switchToEntertainmentSection(EntertainmentSection.MOVIES) }),
                Triple("Series & Auto-Next", "series seasons episodes auto next", { switchToEntertainmentSection(EntertainmentSection.SERIES) }),
                Triple("EPG TV Guide", "epg guide xmltv reminder timeline", { showEpgGuideHubDialog() }),
                Triple("Playlists & WorkManager Auto-Refresh", "playlist refresh schedule interval duplicate health", { showPlaylistAutoRefreshAndHealthHubDialog() }),
                Triple("Network & Connectivity", "network dns buffer timeout recovery", { showRecoveryAndDiagnosticsCenterDialog() }),
                Triple("Performance & 512MB Guard", "performance ram memory low adaptive benchmark", { showPerformanceModeDialog() }),
                Triple("Remote Control Shortcuts", "remote key red green yellow blue long press ok", { showRemoteShortcutsSettingsDialog() }),
                Triple("Interface, 4D Themes & Overscan", "interface theme amoled density overscan clock", { showAppearanceDensityAndOverscanDialog() }),
                Triple("Home Screen Rows", "home rows customize reorder hide", { showHomeRowCustomizationDialog() }),
                Triple("Navigation / Sidebar Icons", "sidebar navigation bar icons reorder hide", { showSidebarCustomizationDialog() }),
                Triple("Profiles & Multi-Account", "profiles account isolation xtream m3u", { showProfilesDialog() }),
                Triple("Parental Controls & PIN", "parental pin lock category", { showParentalPinSettingsDialog() }),
                Triple("Privacy & History", "privacy clear search watch history credentials", { showPrivacyControlsDialog() }),
                Triple("Storage & Cache Manager", "storage cache sxb2 epg image clear", { showStorageAndCacheManagerDialog() }),
                Triple("Backup & Restore (SXBK_V20 / AES-256)", "backup restore password export import reset", { showBackupAndRestoreDialog() }),
                Triple("Accessibility & Viewing Comfort", "accessibility contrast reduced motion", { showAppearanceDensityAndOverscanDialog() }),
                Triple("App Health & Diagnostics", "health diagnostics telemetry capabilities", { showAppHealthDashboardDialog() }),
                Triple("About & Legal Disclaimer", "about version legal disclaimer", { showAboutAndUpdateCenterDialog() })
            )
            val matches = if (q.isEmpty()) catalog else catalog.filter {
                it.first.lowercase(Locale.ROOT).contains(q) || it.second.contains(q)
            }
            val opts = matches.map { (title, tags, action) ->
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_settings,
                    title = title,
                    subtitle = "Matches: $tags",
                    badgeText = "OPEN"
                ) { action() }
            }
            show4dGlassListModal(
                headerIconRes = R.drawable.ic_3d_search,
                title = "Settings Search Results (${opts.size})",
                subtitle = if (q.isEmpty()) "All 24 Settings Categories" else "Filter: '$q'",
                badgeText = "${opts.size} FOUND",
                options = opts,
                closeLabel = "Back"
            )
        }
    }

    private fun showAppHealthDashboardDialog() {
        val hours = profileStore.getAutoRefreshIntervalHours(activeAccountScope)
        val lastStatus = profileStore.getLastRefreshStatus(activeAccountScope)
        val nextMs = profileStore.getNextScheduledRefreshEpochMs(activeAccountScope)
        val nextLabel = if (nextMs > 0L) java.text.SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()).format(java.util.Date(nextMs)) else "Not scheduled"
        val hdrCaps = detectDisplayHdrTypes()
        val audioCaps = detectSupportedPassthroughCodecs().ifEmpty { listOf("PCM Stereo Only") }.joinToString(", ")
        val rt = Runtime.getRuntime()
        val usedMb = (rt.totalMemory() - rt.freeMemory()) / (1024L * 1024L)
        val maxMb = rt.maxMemory() / (1024L * 1024L)
        val options = listOf(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_rocket,
                title = "Engine: RAM PLAYER v21.0 (Build 210) • Media3 1.11.1",
                subtitle = "RAM Usage: ${usedMb}/${maxMb} MB • PCM Delay: +${audioDelayProcessor.getDelayMs()}ms • Sub Delay: +${profileStore.getSubtitleDelayMs(activeAccountScope)}ms",
                badgeText = "HEALTHY ✓",
                isHighlighted = true
            ) {},
            GlassModalOption(
                iconRes = R.drawable.ic_3d_playlist,
                title = "Catalogs: ${allChannels.size} Live • ${vodMoviesCatalog.size} Movies • ${seriesCatalogGroups.size} Series",
                subtitle = "EPG Channels: ${epgMap.size} • Blacklisted: ${profileStore.getBlacklistedChannelIds(activeAccountScope).size} • Hidden: ${profileStore.getHiddenChannelIds(activeAccountScope).size}",
                badgeText = "CATALOGS"
            ) {},
            GlassModalOption(
                iconRes = R.drawable.ic_3d_sync,
                title = "WorkManager Auto-Refresh: ${if (hours == 0) "OFF" else "Every ${hours}h"}",
                subtitle = "Last: $lastStatus • Next: $nextLabel",
                badgeText = if (hours == 0) "MANUAL" else "${hours}h"
            ) { showPlaylistAutoRefreshAndHealthHubDialog() },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_video_4k,
                title = "Verified Hardware Capabilities",
                subtitle = "TV HDR: $hdrCaps • Bitstream Audio: $audioCaps",
                badgeText = "HARDWARE"
            ) {}
        )
        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_ram_gauge,
            title = "RAM PLAYER App Health Dashboard",
            subtitle = "Real-time diagnostics with zero fabricated metrics",
            badgeText = "v21.0",
            options = options,
            closeLabel = "Back"
        )
    }

    private fun showPrivacyControlsDialog() {
        val options = listOf(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_trash,
                title = "Clear Unified Search History",
                subtitle = "Deletes all recent search queries on this device",
                badgeText = "CLEAR"
            ) {
                profileStore.clearSearchHistory()
                Toast.makeText(this, "Search history cleared", Toast.LENGTH_SHORT).show()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_trash,
                title = "Clear Watched History (Active Profile)",
                subtitle = "Clears watched episode/movie markers for active profile only",
                badgeText = "CLEAR"
            ) {
                profileStore.clearWatchedHistory(activeAccountScope)
                Toast.makeText(this, "Watched history cleared for active profile", Toast.LENGTH_SHORT).show()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_trash,
                title = "Clear Continue Watching (Active Profile)",
                subtitle = "Clears saved playback resume timestamps for active profile only",
                badgeText = "CLEAR"
            ) {
                profileStore.clearAllContinueWatching(activeAccountScope)
                Toast.makeText(this, "Continue Watching cleared for active profile", Toast.LENGTH_SHORT).show()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_accounts,
                title = "Manage Saved Profiles & Credentials",
                subtitle = "View, edit, or delete encrypted M3U/Xtream accounts (AES-256 protected)",
                badgeText = "ACCOUNTS"
            ) { showProfilesDialog() }
        )
        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_lock,
            title = "Privacy Controls & Data Management",
            subtitle = "Zero third-party telemetry • All data stays encrypted locally",
            badgeText = "PRIVACY",
            options = options,
            closeLabel = "Back"
        )
    }

    private fun showPasswordProtectedBackupExportDialog() {
        show4dGlassFormModal(
            headerIconRes = R.drawable.ic_3d_lock,
            title = "Encrypt Backup with Password (AES-256-GCM)",
            subtitle = "Protects profiles, favorites, blacklist, home/sidebar layout & all settings",
            badgeText = "AES-256",
            fields = listOf(
                GlassFormFieldSpec(
                    label = "BACKUP PASSWORD (MIN 4 CHARS)",
                    hint = "Enter encryption password",
                    iconRes = R.drawable.ic_3d_lock,
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                )
            ),
            positiveLabel = "Encrypt & Export",
            positiveBgRes = R.drawable.bg_btn_3d_emerald
        ) { vals ->
            val pwd = vals.firstOrNull().orEmpty().trim()
            if (pwd.length < 4) {
                Toast.makeText(this, "Password must be at least 4 characters", Toast.LENGTH_SHORT).show()
                return@show4dGlassFormModal
            }
            val plain = BackupRestoreEngine.exportVersionedBackupJson(
                profileStore = profileStore,
                accountScope = activeAccountScope,
                liveFavoriteIds = favoriteIds,
                includeCredentials = true
            )
            val encrypted = BackupRestoreEngine.encryptBackupWithPassword(plain, pwd)
            showBackupJsonPayloadDialog(encrypted, includesCredentials = true)
        }
    }

    // =========================================================================
    // RAM PLAYER v21.0 GENUINE RECYCLE BIN MANAGER (SOFT-DELETE & RESTORE)
    // =========================================================================

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        if (okHoldDeleteController.isOkKeyCode(keyCode) && okHoldDeleteController.isHolding()) {
            uiHandler.removeCallbacks(okHoldPollRunnable)
            okHoldDeleteOverlay?.visibility = View.GONE
            val outcome = okHoldDeleteController.onKeyUp(keyCode, SystemClock.elapsedRealtime())
            when (outcome) {
                OkLongHoldDeleteController.ReleaseOutcome.SHORT_TAP -> {
                    if (activePlaybackMode == ActivePlaybackMode.LIVE_TV &&
                        (exoPlayer?.playbackState == Player.STATE_IDLE || currentPlayingStreamUrl.isEmpty()) &&
                        allChannels.isNotEmpty()
                    ) {
                        startPlaybackForCurrentChannel(forceReload = true)
                    }
                    showZappingOsd()
                }
                OkLongHoldDeleteController.ReleaseOutcome.CONFIGURABLE_LONG_PRESS -> {
                    handleConfigurableLongPressOk()
                }
                OkLongHoldDeleteController.ReleaseOutcome.CANCELLED_EARLY -> {
                    Toast.makeText(this, "Channel delete cancelled (held < 5s)", Toast.LENGTH_SHORT).show()
                }
                OkLongHoldDeleteController.ReleaseOutcome.ALREADY_TRIGGERED,
                OkLongHoldDeleteController.ReleaseOutcome.IGNORED -> Unit
            }
            return true
        }
        return super.onKeyUp(keyCode, event)
    }

    private fun applyTrueEdgeToEdgeFullscreen() {
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                window.attributes = window.attributes.apply {
                    layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                }
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                window.attributes = window.attributes.apply {
                    layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                }
            }
            WindowCompat.setDecorFitsSystemWindows(window, false)
            val controller = WindowInsetsControllerCompat(window, window.decorView)
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            applyTrueEdgeToEdgeFullscreen()
        } else {
            cancelOkHoldDelete()
        }
    }

    private fun cancelOkHoldDelete() {
        okHoldDeleteController.cancel()
        uiHandler.removeCallbacks(okHoldPollRunnable)
        okHoldDeleteOverlay?.visibility = View.GONE
    }

    // =========================================================================
    // RAM PLAYER v21.0 — AUDIO TRACK INSPECTOR & BOUNDED AUTOMATIC RECOVERY
    // =========================================================================

    private fun inspectAndRecoverAudioTracks(player: ExoPlayer, allowAutoRecovery: Boolean) {
        val tracks = player.currentTracks
        val descriptors = ArrayList<AudioTrackDescriptor>(4)
        for (gIdx in tracks.groups.indices) {
            val group = tracks.groups[gIdx]
            if (group.type == C.TRACK_TYPE_AUDIO) {
                for (tIdx in 0 until group.length) {
                    val fmt = group.getTrackFormat(tIdx)
                    descriptors.add(
                        AudioTrackDescriptor(
                            groupIndex = gIdx,
                            trackIndex = tIdx,
                            language = fmt.language.orEmpty(),
                            label = fmt.label.orEmpty(),
                            mimeType = fmt.sampleMimeType.orEmpty(),
                            codecs = fmt.codecs.orEmpty(),
                            channelCount = fmt.channelCount,
                            sampleRateHz = fmt.sampleRate,
                            bitrateBps = fmt.bitrate,
                            isSupported = group.isTrackSupported(tIdx),
                            isSelected = group.isTrackSelected(tIdx)
                        )
                    )
                }
            }
        }

        val supportedOut = detectSupportedPassthroughCodecs()
        val outCap = if (supportedOut.isEmpty()) "PCM Stereo" else "PCM + ${supportedOut.joinToString("/")}"
        val snapshot = AudioTrackIntelligenceEngine.diagnoseAudioState(
            tracks = descriptors,
            decoderError = lastAudioDecoderError,
            outputError = lastAudioOutputError,
            outputCapability = outCap,
            recoveryStatus = audioRecoveryStatusLabel
        )
        lastAudioDiagnostics = snapshot
        updateLiveTelemetryBadge(player)

        if (!allowAutoRecovery) return
        val nowElapsed = SystemClock.elapsedRealtime()
        if (!AudioTrackIntelligenceEngine.shouldAttemptAudioRecovery(
                snapshot = snapshot,
                attemptsForChannel = audioRecoveryAttemptsForChannel,
                lastAttemptElapsedMs = lastAudioRecoveryElapsedMs,
                nowElapsedMs = nowElapsed
            )
        ) {
            return
        }

        audioRecoveryAttemptsForChannel++
        lastAudioRecoveryElapsedMs = nowElapsed

        val chId = allChannels.getOrNull(currentChannelIndex)?.id
        val preferredLang = if (::profileStore.isInitialized && chId != null) {
            profileStore.getPreferredAudioLanguage(chId) ?: profileStore.getGlobalPreferredAudioLanguage(activeAccountScope)
        } else "hi"

        val candidate = if (snapshot.failureReason == AudioFailureReason.DECODER_INIT_FAILED ||
            snapshot.failureReason == AudioFailureReason.OUTPUT_ROUTING_ERROR
        ) {
            AudioTrackIntelligenceEngine.findAlternativeSupportedTrack(descriptors, snapshot.selectedTrack)
                ?: AudioTrackIntelligenceEngine.selectBestAudioTrack(descriptors, preferredLang)
        } else {
            AudioTrackIntelligenceEngine.selectBestAudioTrack(descriptors, preferredLang)
        }

        if (candidate != null && candidate.groupIndex in tracks.groups.indices) {
            val targetGroup = tracks.groups[candidate.groupIndex]
            audioRecoveryStatusLabel = "Switched to ${candidate.shortCodecName()} (${candidate.language.ifBlank { "Track" }})"
            lastAudioDecoderError = null
            lastAudioOutputError = null
            val paramsBuilder = player.trackSelectionParameters.buildUpon()
                .setOverrideForType(TrackSelectionOverride(targetGroup.mediaTrackGroup, candidate.trackIndex))
            if (snapshot.failureReason == AudioFailureReason.OUTPUT_ROUTING_ERROR) {
                paramsBuilder.setAudioOffloadPreferences(
                    TrackSelectionParameters.AudioOffloadPreferences.Builder()
                        .setAudioOffloadMode(TrackSelectionParameters.AudioOffloadPreferences.AUDIO_OFFLOAD_MODE_DISABLED)
                        .build()
                )
            }
            player.trackSelectionParameters = paramsBuilder.build()
            updateLiveTelemetryBadge(player)
            return
        }

        if (snapshot.failureReason == AudioFailureReason.OUTPUT_ROUTING_ERROR ||
            snapshot.failureReason == AudioFailureReason.DECODER_INIT_FAILED
        ) {
            audioRecoveryStatusLabel = "Safe PCM Fallback (Attempt $audioRecoveryAttemptsForChannel/2)"
            audioDelayProcessor.setDelayMs(0)
            player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                .setAudioOffloadPreferences(
                    TrackSelectionParameters.AudioOffloadPreferences.Builder()
                        .setAudioOffloadMode(TrackSelectionParameters.AudioOffloadPreferences.AUDIO_OFFLOAD_MODE_DISABLED)
                        .build()
                )
                .build()
            updateLiveTelemetryBadge(player)
        }
    }

    // =========================================================================
    // RAM PLAYER v21.0 — COMPLETE CATEGORY DELETE & INDIVIDUAL CHANNEL DELETE
    // =========================================================================

    private fun reapplyDeletionFiltersToActiveCatalog() {
        val excludedCats = profileStore.getAllExcludedCategories(activeAccountScope)

        if (rawLoadedVodMovies.isNotEmpty()) {
            val filteredMovies = ChannelDeletionFilter.filterActiveChannels(
                rawChannels = rawLoadedVodMovies,
                deletedCategories = excludedCats,
                deletedChannelKeys = emptySet(),
                deletedChannelIds = emptySet()
            )
            val byId = HashMap<String, Int>(filteredMovies.size)
            for (i in filteredMovies.indices) byId[filteredMovies[i].id] = i
            vodMoviesCatalog = filteredMovies
            vodMovieIndexById = byId
            if (vodPosterGridPanel.visibility == View.VISIBLE && activeEntertainmentSection == EntertainmentSection.MOVIES) {
                val sidebarItems = buildVodSidebarCategories(EntertainmentSection.MOVIES)
                vodSidebarAdapter.submitCategories(sidebarItems, selectedVodCategory)
                renderVodPosterGrid()
            }
        }

        if (rawLoadedSeries.isNotEmpty()) {
            val filteredSeries = ChannelDeletionFilter.filterActiveChannels(
                rawChannels = rawLoadedSeries,
                deletedCategories = excludedCats,
                deletedChannelKeys = emptySet(),
                deletedChannelIds = emptySet()
            )
            seriesCatalogRaw = filteredSeries
            seriesCatalogGroups = MediaCatalogEngine.buildXtreamSeriesGroups(filteredSeries)
            if (vodPosterGridPanel.visibility == View.VISIBLE && activeEntertainmentSection == EntertainmentSection.SERIES) {
                val sidebarItems = buildVodSidebarCategories(EntertainmentSection.SERIES)
                vodSidebarAdapter.submitCategories(sidebarItems, selectedVodCategory)
                renderVodPosterGrid()
            }
        }

        if (rawLoadedLiveChannels.isEmpty()) return
        val currentChId = allChannels.getOrNull(currentChannelIndex)?.id
        val filtered = ChannelDeletionFilter.filterActiveChannels(
            rawChannels = rawLoadedLiveChannels,
            deletedCategories = excludedCats,
            deletedChannelKeys = profileStore.getDeletedChannelKeys(activeAccountScope),
            deletedChannelIds = profileStore.getDeletedChannelIds(activeAccountScope)
        )
        allChannels = filtered
        rebuildChannelIndicesSync(filtered)

        val visibleCats = ArrayList<String>().apply {
            add("All categories")
            addAll(filtered.map { it.category }.filter { it.isNotBlank() }.distinct().sorted())
        }
        suppressCategoryCallback = true
        selectedCategory = "All categories"
        categoryFilter.adapter = createGlassCategoryAdapter(visibleCats)
        categoryFilter.setSelection(0, false)
        suppressCategoryCallback = false

        if (filtered.isEmpty()) {
            currentChannelIndex = 0
            exoPlayer?.stop()
            currentPlayingStreamUrl = ""
            renderDrawerList()
            return
        }

        val preservedIdx = if (!currentChId.isNullOrBlank()) channelIndexById[currentChId] else null
        if (preservedIdx != null && preservedIdx in filtered.indices) {
            currentChannelIndex = preservedIdx
            updateOsdForCurrentChannel()
        } else {
            val nextIdx = currentChannelIndex.coerceIn(0, filtered.lastIndex)
            switchChannel(nextIdx, immediatePlayback = true)
        }
        renderDrawerList(scrollToActive = true)
    }

    private fun showDeleteCurrentChannelConfirmationDialog(channel: Channel) {
        if (okHoldDeleteDialogShowing) return
        okHoldDeleteDialogShowing = true
        AlertDialog.Builder(this, R.style.Theme_StreamX_GlassDialog)
            .setTitle("Delete Channel?")
            .setMessage("Channel #${channel.displayNumberFormatted()} — ${channel.name}\nCategory: ${channel.category}\n\nThis removes the channel from your active playlist, search, and zapping. You can restore it anytime from Recycle Bin.")
            .setPositiveButton("Delete Channel") { _, _ ->
                okHoldDeleteDialogShowing = false
                if (rawLoadedLiveChannels.isEmpty()) {
                    rawLoadedLiveChannels = allChannels
                }
                profileStore.softDeleteChannel(channel, activeAccountScope)
                reapplyDeletionFiltersToActiveCatalog()
                Toast.makeText(this, "🗑️ Deleted #${channel.displayNumberFormatted()} ${channel.name} (Restorable in Recycle Bin)", Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("Cancel") { _, _ ->
                okHoldDeleteDialogShowing = false
            }
            .setOnDismissListener {
                okHoldDeleteDialogShowing = false
            }
            .show()
    }

    private fun showCategoryManagerDialog() {
        val sourceList = if (rawLoadedLiveChannels.isNotEmpty()) rawLoadedLiveChannels else allChannels
        val countsByCat = ChannelDeletionFilter.countChannelsByCategory(sourceList)
        val deletedCats = profileStore.getDeletedCategories(activeAccountScope)
        val normDeleted = deletedCats.map { it.trim().lowercase(Locale.ROOT) }.toSet()

        val options = ArrayList<GlassModalOption>(countsByCat.size + deletedCats.size + 2)

        val undoCat = lastUndoDeletedCategory
        if (!undoCat.isNullOrBlank() && normDeleted.contains(undoCat.lowercase(Locale.ROOT))) {
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_sync,
                    title = "↩️ Undo Last Delete: '$undoCat'",
                    subtitle = "Immediately restore category '$undoCat' and all its channels",
                    badgeText = "UNDO",
                    isHighlighted = true
                ) {
                    profileStore.restoreDeletedCategory(undoCat, activeAccountScope)
                    lastUndoDeletedCategory = null
                    reapplyDeletionFiltersToActiveCatalog()
                    Toast.makeText(this, "↩️ Restored category '$undoCat'", Toast.LENGTH_SHORT).show()
                    showCategoryManagerDialog()
                }
            )
        }

        val activeCats = countsByCat.entries
            .filter { !normDeleted.contains(it.key.trim().lowercase(Locale.ROOT)) }
            .sortedBy { it.key.lowercase(Locale.ROOT) }

        for ((catName, count) in activeCats) {
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_category,
                    title = "$catName ($count channels)",
                    subtitle = "Tap to delete entire '$catName' category from active browsing, search & zapping",
                    badgeText = "DELETE"
                ) {
                    AlertDialog.Builder(this, R.style.Theme_StreamX_GlassDialog)
                        .setTitle("Delete Category '$catName'?")
                        .setMessage("Remove all $count channel(s) in '$catName' from your active interface, search, and zapping?\n\nYour original remote playlist is untouched and you can restore '$catName' anytime.")
                        .setPositiveButton("Delete Category") { _, _ ->
                            if (rawLoadedLiveChannels.isEmpty()) rawLoadedLiveChannels = allChannels
                            profileStore.softDeleteCategory(catName, count, activeAccountScope)
                            lastUndoDeletedCategory = catName
                            reapplyDeletionFiltersToActiveCatalog()
                            Toast.makeText(this, "🗑️ Deleted category '$catName' ($count ch)", Toast.LENGTH_LONG).show()
                            showCategoryManagerDialog()
                        }
                        .setNegativeButton("Cancel", null)
                        .show()
                }
            )
        }

        if (deletedCats.isNotEmpty()) {
            for (delCat in deletedCats.sorted()) {
                val origCount = countsByCat.entries.firstOrNull { it.key.equals(delCat, ignoreCase = true) }?.value ?: 0
                options.add(
                    GlassModalOption(
                        iconRes = R.drawable.ic_3d_trash,
                        title = "♻️ Restore Deleted Category: $delCat",
                        subtitle = if (origCount > 0) "Contains $origCount channel(s) — tap to restore" else "Tap to restore category",
                        badgeText = "RESTORE",
                        isHighlighted = true
                    ) {
                        profileStore.restoreDeletedCategory(delCat, activeAccountScope)
                        reapplyDeletionFiltersToActiveCatalog()
                        Toast.makeText(this, "♻️ Restored category '$delCat'", Toast.LENGTH_SHORT).show()
                        showCategoryManagerDialog()
                    }
                )
            }
        }

        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_category,
            title = "Category Manager (${activeCats.size} Active • ${deletedCats.size} Deleted)",
            subtitle = "Soft-delete unwanted M3U/Xtream categories (persists across restarts & refreshes)",
            badgeText = "${activeCats.size} CATS",
            options = options,
            closeLabel = "Done"
        )
    }

    private fun showPermanentCategoryDeleteDialog() {
        val liveSource = if (rawLoadedLiveChannels.isNotEmpty()) rawLoadedLiveChannels else allChannels
        val movieSource = if (rawLoadedVodMovies.isNotEmpty()) rawLoadedVodMovies else vodMoviesCatalog
        val seriesSource = if (rawLoadedSeries.isNotEmpty()) rawLoadedSeries else seriesCatalogRaw
        val excludedCats = profileStore.getAllExcludedCategories(activeAccountScope)
        val activeCategories = ChannelDeletionFilter.collectActiveCategoriesWithCounts(
            liveChannels = liveSource,
            movieChannels = movieSource,
            seriesChannels = seriesSource,
            excludedCategories = excludedCats
        )

        if (activeCategories.isEmpty()) {
            Toast.makeText(this, "No active categories available to delete.", Toast.LENGTH_SHORT).show()
            return
        }

        val selectedCategories = LinkedHashSet<String>()
        var currentFilterQuery = ""
        var dialogRef: AlertDialog? = null

        val rootCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_dialog_4d_glass)
            setPadding(dp(18), dp(16), dp(18), dp(16))
        }

        val permCount = profileStore.getPermanentlyDeletedCategories(activeAccountScope).size
        rootCard.addView(
            build4dModalHeader(
                iconRes = R.drawable.ic_3d_trash,
                title = "Permanent Category Delete",
                subtitle = "Select unwanted categories (UK, Pakistani, etc.) & delete permanently — never returns on refresh ($permCount already deleted)",
                badgeText = "${activeCategories.size} ACTIVE"
            )
        )

        val searchInput = EditText(this).apply {
            hint = "Search category (e.g. UK, Pakistan, Sports...)"
            setHintTextColor(Color.parseColor("#94A3B8"))
            setTextColor(Color.WHITE)
            textSize = 13f
            isSingleLine = true
            setBackgroundResource(R.drawable.bg_glass_input_4d)
            setPadding(dp(12), dp(9), dp(12), dp(9))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(10)
            }
        }
        rootCard.addView(searchInput)

        val tvSelectionStatus = TextView(this).apply {
            text = "0 selected • Tap or press OK on categories to select"
            textSize = 11.5f
            setTextColor(Color.parseColor("#CBD5E1"))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(8)
                bottomMargin = dp(6)
            }
        }
        rootCard.addView(tvSelectionStatus)

        val maxScrollHeight = (resources.displayMetrics.heightPixels * 0.46f).toInt().coerceAtLeast(dp(170))
        val scroll = ScrollView(this).apply {
            isFillViewport = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                maxScrollHeight
            ).apply {
                bottomMargin = dp(10)
            }
        }
        val listContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(listContainer)
        rootCard.addView(scroll)

        lateinit var btnDeleteSelected: Button
        lateinit var btnToggleVisible: Button

        fun visibleCategories(): List<Pair<String, Int>> {
            val q = currentFilterQuery.trim().lowercase(Locale.ROOT)
            if (q.isEmpty()) return activeCategories
            return activeCategories.filter { it.first.lowercase(Locale.ROOT).contains(q) }
        }

        fun updateActionButtons() {
            val count = selectedCategories.size
            btnDeleteSelected.text = if (count > 0) "Delete Selected ($count)" else "Delete Selected (0)"
            tvSelectionStatus.text = if (count > 0) {
                "$count category(s) selected for permanent deletion"
            } else {
                "0 selected • Tap or press OK on categories to select"
            }
            val visible = visibleCategories()
            val allVisibleSelected = visible.isNotEmpty() && visible.all { selectedCategories.contains(it.first) }
            btnToggleVisible.text = if (allVisibleSelected) "Clear Visible" else "Select Visible"
        }

        fun rebuildCategoryRows() {
            listContainer.removeAllViews()
            val visible = visibleCategories()
            if (visible.isEmpty()) {
                val emptyView = TextView(this).apply {
                    text = "No categories match '$currentFilterQuery'"
                    textSize = 13f
                    setTextColor(Color.parseColor("#94A3B8"))
                    setPadding(dp(12), dp(18), dp(12), dp(18))
                }
                listContainer.addView(emptyView)
                updateActionButtons()
                return
            }

            visible.forEachIndexed { idx, (catName, itemCount) ->
                val isChecked = selectedCategories.contains(catName)
                val rowCard = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    isFocusable = true
                    isClickable = true
                    isSelected = isChecked
                    setBackgroundResource(
                        if (isChecked) themes[currentThemeIndex].activeRowDrawableRes
                        else R.drawable.bg_dialog_item_4d
                    )
                    setPadding(dp(12), dp(10), dp(12), dp(10))
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply {
                        if (idx < visible.lastIndex) bottomMargin = dp(6)
                    }
                    attach4dFocusMicroInteraction(this, focusedScale = 1.02f)
                }

                val tvCheck = TextView(this).apply {
                    text = if (isChecked) "☑" else "☐"
                    textSize = 18f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(if (isChecked) Color.parseColor("#F87171") else Color.parseColor("#94A3B8"))
                    setPadding(dp(2), 0, dp(10), 0)
                }
                rowCard.addView(tvCheck)

                val textCol = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                        marginEnd = dp(8)
                    }
                }
                val tvCatTitle = TextView(this).apply {
                    text = catName
                    textSize = 13.5f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(Color.WHITE)
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                }
                val tvCatSub = TextView(this).apply {
                    text = "$itemCount item(s)"
                    textSize = 11f
                    setTextColor(Color.parseColor("#CBD5E1"))
                }
                textCol.addView(tvCatTitle)
                textCol.addView(tvCatSub)
                rowCard.addView(textCol)

                val tvBadge = TextView(this).apply {
                    text = if (isChecked) "SELECTED" else "KEEP"
                    textSize = 10f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(if (isChecked) Color.parseColor("#FCA5A5") else Color.parseColor("#38BDF8"))
                    setBackgroundResource(if (isChecked) R.drawable.bg_live_dot_pill else R.drawable.bg_badge_neon)
                    setPadding(dp(8), dp(3), dp(8), dp(3))
                }
                rowCard.addView(tvBadge)

                rowCard.setOnClickListener {
                    val nowSelected = if (selectedCategories.contains(catName)) {
                        selectedCategories.remove(catName)
                        false
                    } else {
                        selectedCategories.add(catName)
                        true
                    }
                    rowCard.isSelected = nowSelected
                    rowCard.setBackgroundResource(
                        if (nowSelected) themes[currentThemeIndex].activeRowDrawableRes
                        else R.drawable.bg_dialog_item_4d
                    )
                    tvCheck.text = if (nowSelected) "☑" else "☐"
                    tvCheck.setTextColor(if (nowSelected) Color.parseColor("#F87171") else Color.parseColor("#94A3B8"))
                    tvBadge.text = if (nowSelected) "SELECTED" else "KEEP"
                    tvBadge.setTextColor(if (nowSelected) Color.parseColor("#FCA5A5") else Color.parseColor("#38BDF8"))
                    tvBadge.setBackgroundResource(if (nowSelected) R.drawable.bg_live_dot_pill else R.drawable.bg_badge_neon)
                    updateActionButtons()
                }

                listContainer.addView(rowCard)
            }
            updateActionButtons()
        }

        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        btnToggleVisible = create4dActionCapsuleButton("Select Visible", R.drawable.bg_btn_3d_slate) {
            val visible = visibleCategories()
            val allVisibleSelected = visible.isNotEmpty() && visible.all { selectedCategories.contains(it.first) }
            if (allVisibleSelected) {
                visible.forEach { selectedCategories.remove(it.first) }
            } else {
                visible.forEach { selectedCategories.add(it.first) }
            }
            rebuildCategoryRows()
        }
        btnToggleVisible.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { marginEnd = dp(8) }
        footer.addView(btnToggleVisible)

        btnDeleteSelected = create4dActionCapsuleButton("Delete Selected (0)", R.drawable.bg_btn_3d_crimson) {
            if (selectedCategories.isEmpty()) {
                Toast.makeText(this, "Please select at least 1 category to delete.", Toast.LENGTH_SHORT).show()
                return@create4dActionCapsuleButton
            }
            val toDelete = selectedCategories.toList()
            val preview = toDelete.take(6).joinToString(", ") +
                if (toDelete.size > 6) " (+${toDelete.size - 6} more)" else ""
            AlertDialog.Builder(this, R.style.Theme_StreamX_GlassDialog)
                .setTitle("Permanently Delete ${toDelete.size} Category(s)?")
                .setMessage("Selected: $preview\n\nThese categories will be PERMANENTLY deleted from Live TV, Movies & Series and will NEVER come back even after refreshing your playlist.")
                .setPositiveButton("Permanent Delete") { _, _ ->
                    if (rawLoadedLiveChannels.isEmpty()) rawLoadedLiveChannels = allChannels
                    if (rawLoadedVodMovies.isEmpty()) rawLoadedVodMovies = vodMoviesCatalog
                    if (rawLoadedSeries.isEmpty()) rawLoadedSeries = seriesCatalogRaw
                    val deletedCount = profileStore.permanentlyDeleteCategories(toDelete, activeAccountScope)
                    reapplyDeletionFiltersToActiveCatalog()
                    dialogRef?.dismiss()
                    Toast.makeText(
                        this,
                        "🗑️ Permanently deleted ${if (deletedCount > 0) deletedCount else toDelete.size} category(s) — won't return on refresh",
                        Toast.LENGTH_LONG
                    ).show()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnDeleteSelected.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { marginEnd = dp(8) }
        footer.addView(btnDeleteSelected)

        footer.addView(
            create4dActionCapsuleButton("Close", R.drawable.bg_btn_3d_slate) {
                dialogRef?.dismiss()
            }
        )
        rootCard.addView(footer)

        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
            override fun afterTextChanged(s: Editable?) {
                currentFilterQuery = s?.toString() ?: ""
                rebuildCategoryRows()
            }
        })

        rebuildCategoryRows()
        dialogRef = present4dGlassDialog(rootCard, widthDp = 580)
        listContainer.getChildAt(0)?.post { listContainer.getChildAt(0)?.requestFocus() }
    }

    private fun showPlayerUserAgentProfileDialog() {
        val currentId = profileStore.getPlayerUserAgentProfile()
        val options = ArrayList<GlassModalOption>(NetworkClient.USER_AGENT_PRESETS.size + 1)

        val isAuto = currentId == NetworkClient.USER_AGENT_PROFILE_AUTO
        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_rocket,
                title = "⚡ Auto (8-Player Smart Fallback)",
                subtitle = "Automatically tries OTT Navigator → IPTV Smarters Pro → TiviMate → VLC → Kodi/Lavf → ExoPlayer → Chrome TV → Dalvik & caches winner per server",
                badgeText = if (isAuto) "ACTIVE ✓" else "RECOMMENDED",
                isHighlighted = isAuto
            ) {
                profileStore.setPlayerUserAgentProfile(NetworkClient.USER_AGENT_PROFILE_AUTO)
                NetworkClient.setPreferredUserAgentProfile(NetworkClient.USER_AGENT_PROFILE_AUTO)
                Toast.makeText(this, "🎭 Auto 8-Player Compatibility Fallback enabled", Toast.LENGTH_SHORT).show()
                if (currentPlayingStreamUrl.isNotBlank()) {
                    playSpecificStreamUrl(currentPlayingStreamUrl, forceReload = true)
                }
            }
        )

        for (preset in NetworkClient.USER_AGENT_PRESETS) {
            val active = currentId == preset.id
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_play,
                    title = "📡 ${preset.label}",
                    subtitle = preset.userAgent,
                    badgeText = if (active) "ACTIVE ✓" else "SELECT",
                    isHighlighted = active
                ) {
                    profileStore.setPlayerUserAgentProfile(preset.id)
                    NetworkClient.setPreferredUserAgentProfile(preset.id)
                    Toast.makeText(this, "🎭 User-Agent set to ${preset.label}", Toast.LENGTH_SHORT).show()
                    if (currentPlayingStreamUrl.isNotBlank()) {
                        playSpecificStreamUrl(currentPlayingStreamUrl, forceReload = true)
                    }
                }
            )
        }

        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_network,
            title = "Player Compatibility & User-Agent",
            subtitle = "Match OTT Navigator, IPTV Smarters Pro, TiviMate, VLC & Kodi stream access automatically",
            badgeText = "8 PLAYERS",
            options = options,
            closeLabel = "Close"
        )
    }

    // =========================================================================
    // RAM PLAYER v21.0 GENUINE RECYCLE BIN MANAGER (CHANNELS, CATEGORIES, GROUPS, PROFILES)
    // =========================================================================

    private fun showRecycleBinDialog() {
        val entries = profileStore.searchRecycleBinEntries(recycleBinSearchQuery, activeAccountScope)
        val df = java.text.SimpleDateFormat("dd MMM HH:mm", Locale.getDefault())
        val options = ArrayList<GlassModalOption>(entries.size + 5)

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_search,
                title = if (recycleBinSearchQuery.isBlank()) "🔍 Search Deleted Items" else "🔍 Filter: '$recycleBinSearchQuery' (Tap to change/clear)",
                subtitle = "Search by channel name, category, custom group, or profile",
                badgeText = if (recycleBinSearchQuery.isBlank()) "SEARCH" else "FILTERED"
            ) {
                show4dGlassFormModal(
                    headerIconRes = R.drawable.ic_3d_search,
                    title = "Search Recycle Bin",
                    subtitle = "Leave blank to show all deleted items",
                    badgeText = "SEARCH",
                    fields = listOf(
                        GlassFormFieldSpec(
                            label = "SEARCH QUERY",
                            hint = "e.g. UK, Sports, Star...",
                            iconRes = R.drawable.ic_3d_search,
                            initialValue = recycleBinSearchQuery
                        )
                    ),
                    positiveLabel = "Apply Filter",
                    positiveBgRes = R.drawable.bg_btn_3d_cyan
                ) { vals ->
                    recycleBinSearchQuery = vals.firstOrNull()?.trim().orEmpty()
                    showRecycleBinDialog()
                }
            }
        )

        if (entries.isEmpty()) {
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_trash,
                    title = if (recycleBinSearchQuery.isBlank()) "Recycle Bin is Empty" else "No matching deleted items",
                    subtitle = "Deleted channels, categories, custom groups & profiles appear here (profile-isolated)",
                    badgeText = "EMPTY"
                ) {}
            )
        } else {
            if (recycleBinSelectedIds.isNotEmpty()) {
                options.add(
                    GlassModalOption(
                        iconRes = R.drawable.ic_3d_sync,
                        title = "☑️ Restore Selected Items (${recycleBinSelectedIds.size})",
                        subtitle = "Restore only the checked items back to this profile",
                        badgeText = "RESTORE SEL",
                        isHighlighted = true
                    ) {
                        val count = profileStore.restoreSelectedRecycleBinEntries(HashSet(recycleBinSelectedIds), activeAccountScope)
                        recycleBinSelectedIds.clear()
                        reapplyDeletionFiltersToActiveCatalog()
                        Toast.makeText(this, "Restored $count selected item(s)", Toast.LENGTH_SHORT).show()
                        showRecycleBinDialog()
                    }
                )
            }
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_sync,
                    title = "♻️ Restore All Items (${entries.size})",
                    subtitle = "Restore all deleted channels, categories, custom groups & profiles for this profile",
                    badgeText = "RESTORE ALL",
                    isHighlighted = recycleBinSelectedIds.isEmpty()
                ) {
                    val count = profileStore.restoreAllRecycleBinEntries(activeAccountScope)
                    recycleBinSelectedIds.clear()
                    reapplyDeletionFiltersToActiveCatalog()
                    Toast.makeText(this, "Restored $count item(s) from Recycle Bin", Toast.LENGTH_SHORT).show()
                    showRecycleBinDialog()
                }
            )
            for (entry in entries) {
                val deletedAt = df.format(java.util.Date(entry.deletedAtEpochMs))
                val isChecked = recycleBinSelectedIds.contains(entry.id)
                val icon = when (entry.entityType) {
                    "PROFILE" -> R.drawable.ic_3d_accounts
                    "CHANNEL" -> R.drawable.ic_3d_live_tv
                    else -> R.drawable.ic_3d_category
                }
                options.add(
                    GlassModalOption(
                        iconRes = icon,
                        title = "${if (isChecked) "☑️ " else ""}${entry.displayName}",
                        subtitle = "${entry.entityType} • Deleted $deletedAt • Tap for Restore / Select / Permanent Delete",
                        badgeText = entry.entityType,
                        isHighlighted = isChecked
                    ) {
                        AlertDialog.Builder(this, R.style.Theme_StreamX_GlassDialog)
                            .setTitle(entry.displayName)
                            .setMessage("Type: ${entry.entityType}\nDeleted on: $deletedAt\n\nChoose an action:")
                            .setPositiveButton("Restore") { _, _ ->
                                val ok = profileStore.restoreRecycleBinEntry(entry.id, expectedAccountScope = activeAccountScope)
                                recycleBinSelectedIds.remove(entry.id)
                                if (ok) reapplyDeletionFiltersToActiveCatalog()
                                Toast.makeText(this, if (ok) "Restored ${entry.displayName}" else "Restore failed", Toast.LENGTH_SHORT).show()
                                showRecycleBinDialog()
                            }
                            .setNeutralButton(if (isChecked) "Unselect" else "Select for Batch") { _, _ ->
                                if (isChecked) recycleBinSelectedIds.remove(entry.id) else recycleBinSelectedIds.add(entry.id)
                                showRecycleBinDialog()
                            }
                            .setNegativeButton("Delete Permanently") { _, _ ->
                                profileStore.permanentlyDeleteRecycleBinEntry(entry.id)
                                recycleBinSelectedIds.remove(entry.id)
                                Toast.makeText(this, "Permanently deleted ${entry.displayName}", Toast.LENGTH_SHORT).show()
                                showRecycleBinDialog()
                            }
                            .show()
                    }
                )
            }
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_trash,
                    title = "🗑️ Empty Recycle Bin (${entries.size} Items)",
                    subtitle = "Permanently delete all items in Recycle Bin (confirmation required)",
                    badgeText = "EMPTY BIN"
                ) {
                    AlertDialog.Builder(this, R.style.Theme_StreamX_GlassDialog)
                        .setTitle("Empty Recycle Bin?")
                        .setMessage("This will permanently delete ${entries.size} item(s). This action cannot be undone.")
                        .setPositiveButton("Empty Permanently") { _, _ ->
                            profileStore.emptyRecycleBin(activeAccountScope)
                            recycleBinSelectedIds.clear()
                            Toast.makeText(this, "Recycle Bin emptied", Toast.LENGTH_SHORT).show()
                            showRecycleBinDialog()
                        }
                        .setNegativeButton("Cancel", null)
                        .show()
                }
            )
        }

        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_trash,
            title = "RAM PLAYER v21.0 Recycle Bin",
            subtitle = "Deleted channels, categories, custom groups & profiles (credentials encrypted)",
            badgeText = "${entries.size} ITEMS",
            options = options,
            closeLabel = "Back"
        )
    }
}
