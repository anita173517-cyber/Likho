package com.harindra.iptvpro.vod

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * RAM PLAYER v22.0 ULTIMATE — Engine Abstraction, Audio, Buffering & Recovery Unit Tests.
 */
class VodEngineV22Test {

    private class FakeVodPlayerEngine : VodPlayerEngine {
        override val engineName: String = "FakeTestEngine"
        var initialized = false
        var released = false
        private var playingState = false
        private var seekableState = true
        private var posMs = 0L
        private var durMs = 5_400_000L
        private var bufPct = 100f
        private var playSpeed = 1.0f
        private var volPct = 100
        private var audDelayMs = 0L
        private var subDelayMs = 0L
        var selectedAudioId = 1
        var selectedSubId = -1
        var selectedVideoId = 10
        var activeAspect = VodAspectRatioMode.FIT
        var dialoguePreset = VodDialoguePreset.NORMAL
        private var engineCallbacks: VodEngineCallbacks? = null

        override fun initialize(decoderMode: VodDecoderMode, bufferProfile: VodBufferProfile) {
            initialized = true
            released = false
        }

        override fun setCallbacks(callbacks: VodEngineCallbacks?) {
            engineCallbacks = callbacks
        }

        override fun loadMedia(streamUrl: String, resumePositionMs: Long, externalSubtitleUrl: String, headers: Map<String, String>): Boolean {
            if (!streamUrl.startsWith("http")) return false
            posMs = resumePositionMs.coerceAtLeast(0L)
            playingState = true
            engineCallbacks?.onOpening()
            engineCallbacks?.onPlaying()
            return true
        }

        override fun play() { playingState = true; engineCallbacks?.onPlaying() }
        override fun pause() { playingState = false; engineCallbacks?.onPaused() }
        override fun stop() { playingState = false }
        override fun isPlaying(): Boolean = playingState
        override fun isSeekable(): Boolean = seekableState
        override fun getPositionMs(): Long = posMs
        override fun getDurationMs(): Long = durMs
        override fun getBufferedPercent(): Float = bufPct
        override fun seekTo(positionMs: Long) { posMs = positionMs.coerceIn(0L, durMs) }
        override fun setPlaybackSpeed(rate: Float) { playSpeed = rate.coerceIn(0.5f, 2.0f) }
        override fun getPlaybackSpeed(): Float = playSpeed
        override fun setVolumePercent(percent: Int) { volPct = percent.coerceIn(0, 150) }
        override fun getVolumePercent(): Int = volPct
        override fun setAudioDelayMs(delayMs: Long) { audDelayMs = delayMs.coerceIn(-5000L, 5000L) }
        override fun getAudioDelayMs(): Long = audDelayMs
        override fun setSubtitleDelayMs(delayMs: Long) { subDelayMs = delayMs.coerceIn(-5000L, 5000L) }
        override fun getSubtitleDelayMs(): Long = subDelayMs
        override fun getAudioTracks(): List<VodEngineTrack> = listOf(
            VodEngineTrack(1, "English (AC3 5.1)", isSelected = selectedAudioId == 1),
            VodEngineTrack(2, "Hindi (E-AC3 5.1)", isSelected = selectedAudioId == 2)
        )
        override fun selectAudioTrack(trackId: Int): Boolean { selectedAudioId = trackId; return true }
        override fun getSubtitleTracks(): List<VodEngineTrack> = listOf(
            VodEngineTrack(-1, "Subtitles Off", isSelected = selectedSubId == -1, isOffOption = true),
            VodEngineTrack(3, "English SRT", isSelected = selectedSubId == 3)
        )
        override fun selectSubtitleTrack(trackId: Int): Boolean { selectedSubId = trackId; return true }
        override fun addExternalSubtitle(subtitleUrl: String): Boolean = subtitleUrl.startsWith("http")
        override fun getVideoTracks(): List<VodEngineTrack> = listOf(VodEngineTrack(10, "1080p HEVC", isSelected = true))
        override fun selectVideoTrack(trackId: Int): Boolean { selectedVideoId = trackId; return true }
        override fun getVideoInfo(): VodEngineVideoInfo = VodEngineVideoInfo(1920, 1080, 24f, "HEVC", 4_200_000, "HW")
        override fun setAspectRatio(mode: VodAspectRatioMode) { activeAspect = mode }
        override fun applyDialoguePreset(preset: VodDialoguePreset) { dialoguePreset = preset; volPct = preset.volumePercent }
        override fun release() { playingState = false; released = true }
    }

    @Test
    fun engineLifecycleTracksSeekDelayAndReleaseWork() {
        val engine = FakeVodPlayerEngine()
        engine.initialize(VodDecoderMode.AUTO_HW_FALLBACK, VodBufferProfile.ULTRA_ANTI_BUFFER)
        assertTrue(engine.initialized)

        assertFalse(engine.loadMedia("invalid-url", 0L))
        assertTrue(engine.loadMedia("https://cdn.example.com/movie.mkv", 120_000L))
        assertTrue(engine.isPlaying())
        assertEquals(120_000L, engine.getPositionMs())

        engine.seekTo(300_000L)
        assertEquals(300_000L, engine.getPositionMs())

        engine.setPlaybackSpeed(1.5f)
        assertEquals(1.5f, engine.getPlaybackSpeed(), 0.001f)

        // Positive and negative audio & subtitle delays
        engine.setAudioDelayMs(-250L)
        assertEquals(-250L, engine.getAudioDelayMs())
        engine.setSubtitleDelayMs(500L)
        assertEquals(500L, engine.getSubtitleDelayMs())

        // Tracks & external subtitle
        assertTrue(engine.selectAudioTrack(2))
        assertTrue(engine.selectSubtitleTrack(3))
        assertTrue(engine.addExternalSubtitle("https://cdn.example.com/sub.srt"))

        engine.release()
        assertTrue(engine.released)
        assertFalse(engine.isPlaying())
    }

    @Test
    fun audioControllerHandlesPreferredLanguageDelayAndDialoguePresets() {
        val prefs = VodPreferencesStore(InMemoryVodPreferencesBacking())
        prefs.setPreferredAudioLanguage("hindi")
        val engine = FakeVodPlayerEngine()
        val audio = VodAudioController(context = null, prefs = prefs)

        val matched = audio.applyPreferredAudioTrack(engine)
        assertNotNull(matched)
        assertEquals(2, matched!!.id)
        assertEquals(2, engine.selectedAudioId)

        assertEquals(100L, audio.adjustAudioDelayMs(engine, 100L))
        assertEquals(-150L, audio.adjustAudioDelayMs(engine, -250L))
        assertEquals("-150 ms", audio.formatAudioDelayLabel(-150L))
        assertEquals(0L, audio.resetAudioDelay(engine))

        val preset = audio.cycleDialoguePreset(engine)
        assertEquals(VodDialoguePreset.VOICE_CLARITY, preset)
        assertEquals(VodDialoguePreset.VOICE_CLARITY, engine.dialoguePreset)
    }

    @Test
    fun recoveryControllerPerformsHwToSwFallbackAndCapsRetries() {
        val rec = VodBufferingAndRecoveryController(maxTransientRetries = 3)
        assertTrue(rec.isInitialLoad())

        // Fatal 401 auth error must NOT retry
        val auth = rec.evaluateError("HTTP 401 unauthorized", VodDecoderMode.AUTO_HW_FALLBACK)
        assertEquals(VodRecoveryDecisionType.SHOW_FATAL_ERROR, auth.type)
        assertFalse(auth.canManualRetry)

        // Fatal 404 must NOT retry
        val notFound = rec.evaluateError("404 Not Found", VodDecoderMode.AUTO_HW_FALLBACK)
        assertEquals(VodRecoveryDecisionType.SHOW_FATAL_ERROR, notFound.type)

        // First pre-frame decode error triggers HW -> SW fallback
        val fallback = rec.evaluateError("decoder error", VodDecoderMode.AUTO_HW_FALLBACK)
        assertEquals(VodRecoveryDecisionType.FALLBACK_SOFTWARE_DECODER, fallback.type)
        assertTrue(rec.hasTriedSoftwareFallback())

        // Subsequent transient errors retry up to 3 times then stop cleanly
        assertEquals(VodRecoveryDecisionType.RETRY_WITH_BACKOFF, rec.evaluateError("timeout", VodDecoderMode.SOFTWARE_ONLY).type)
        assertEquals(VodRecoveryDecisionType.RETRY_WITH_BACKOFF, rec.evaluateError("timeout", VodDecoderMode.SOFTWARE_ONLY).type)
        assertEquals(VodRecoveryDecisionType.RETRY_WITH_BACKOFF, rec.evaluateError("timeout", VodDecoderMode.SOFTWARE_ONLY).type)
        val exhausted = rec.evaluateError("timeout", VodDecoderMode.SOFTWARE_ONLY)
        assertEquals(VodRecoveryDecisionType.SHOW_FATAL_ERROR, exhausted.type)
        assertTrue(exhausted.canManualRetry)
    }

    @Test
    fun v22PreferencesPersistDecoderBufferDelayAndDialoguePreset() {
        val prefs = VodPreferencesStore(InMemoryVodPreferencesBacking())
        prefs.setDecoderMode(VodDecoderMode.SOFTWARE_ONLY)
        prefs.setBufferProfile(VodBufferProfile.ULTRA_ANTI_BUFFER)
        prefs.setAudioDelayMs(-350L)
        prefs.setDialoguePreset(VodDialoguePreset.CINEMA_DIALOGUE)

        assertEquals(VodDecoderMode.SOFTWARE_ONLY, prefs.getDecoderMode())
        assertEquals(VodBufferProfile.ULTRA_ANTI_BUFFER, prefs.getBufferProfile())
        assertEquals(-350L, prefs.getAudioDelayMs())
        assertEquals(VodDialoguePreset.CINEMA_DIALOGUE, prefs.getDialoguePreset())
    }
}
